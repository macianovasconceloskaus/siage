// content-aulas.js - integrado (inject form + loop de registro)


function abrirFormularioAulas() {
  (async () => {
    const faLinkId = "font-awesome-css";
    if (!document.getElementById(faLinkId)) {
      const link = document.createElement("link");
      link.id = faLinkId;
      link.rel = "stylesheet";
      link.href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css";
      link.crossOrigin = "anonymous";
      link.referrerPolicy = "no-referrer";
      document.head.appendChild(link);
    }
    
    document.getElementById("registro-aulas-wrapper")?.remove();
  
    const wrapper = document.createElement("div");
    wrapper.id = "registro-aulas-wrapper";
    wrapper.style.position = "fixed";
    wrapper.style.top = "100px";
    wrapper.style.right = "20px";
    wrapper.style.zIndex = "999999";
    wrapper.style.maxWidth = "100%";
    wrapper.style.maxHeight = "90vh";
    // overflow controlado pelo CSS do wrapper (border-radius + hidden)
  
    const html = await fetch(chrome.runtime.getURL("form-aulas.html")).then((res) =>
      res.text()
    );
    wrapper.innerHTML = html;
  
    const cssText = await fetch(chrome.runtime.getURL("form-aulas.css")).then((res) =>
      res.text()
    );
    const style = document.createElement("style");
    style.textContent = cssText;
    wrapper.prepend(style);
  
    document.body.appendChild(wrapper);
  
    const popup = document.getElementById("registro-aulas-popup");
  
    // Torna popup arrastável
    popup.onmousedown = (e) => {
      if (e.target.tagName === "TEXTAREA" || e.target.tagName === "BUTTON" || e.target.tagName === "INPUT")
        return;
  
      const shiftX = e.clientX - wrapper.getBoundingClientRect().left;
      const shiftY = e.clientY - wrapper.getBoundingClientRect().top;
  
      const onMouseMove = (e) => {
        wrapper.style.left = `${e.pageX - shiftX}px`;
        wrapper.style.top = `${e.pageY - shiftY}px`;
        wrapper.style.right = "auto";
      };
  
      const onMouseUp = () => {
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
      };
  
      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    };
  
  
  /*function atualizarContadores() {
    const dados = JSON.parse(localStorage.getItem("registroAulasDados") || "{}");
    const total = Array.isArray(dados.dias) ? dados.dias.length : 0;
    const atual = parseInt(localStorage.getItem("registroAulasIndex") || "0", 10);
  
    document.getElementById("aulas-registradas").textContent = atual;
    document.getElementById("aulas-restantes").textContent = Math.max(total - atual, 0);
  }*/
  
  document.getElementById("toggle-senha")?.addEventListener("click", () => {
    const senhaInput = document.getElementById("senhaProfessor");
    const iconOlho = document.getElementById("icon-olho");
    if (senhaInput.type === "password") {
      senhaInput.type = "text";
      iconOlho.classList.remove("fa-eye-slash");
      iconOlho.classList.add("fa-eye");
    } else {
      senhaInput.type = "password";
      iconOlho.classList.remove("fa-eye");
      iconOlho.classList.add("fa-eye-slash");
    }
  });
  
  // Botão colar dados
  document.getElementById("colar-dados")?.addEventListener("click", async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (!text) return console.log("Nenhum texto na área de transferência!");
  
      const linhas = text.trim().split(/\r?\n/);
      if (linhas[0].toLowerCase().includes("data")) linhas.shift();
  
      const mesArr = [];
      const diasArr = [];
      const modoArr = [];
      const tipoArr = [];
      const conteudoArr = [];
      const metodologiaArr = [];
      const observacoesArr = [];
  
      const nomeMes = (n) => {
        const meses = [
          "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
          "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
        ];
        return meses[n - 1];
      };
  
      for (const linha of linhas) {
        const colunas = linha.split("\t");
        const dataParts = colunas[0].split("/"); // Ex: 24/03/2025
  
        const dia = dataParts[0];
        const mes = nomeMes(parseInt(dataParts[1], 10)); // 03 => "Março"
  
        mesArr.push(mes);
        diasArr.push(dia);
        modoArr.push(colunas[3] || "");
        tipoArr.push(colunas[4] || "");
        conteudoArr.push(colunas[5] || "");
        metodologiaArr.push(colunas[6] || "");
        observacoesArr.push(colunas[7] || "");
      }
  
      document.getElementById("mes").value = mesArr.join("\n");
      document.getElementById("dias").value = diasArr.join("\n");
      document.getElementById("modo").value = modoArr.join("\n");
      document.getElementById("tipo").value = tipoArr.join("\n");
      document.getElementById("conteudo").value = conteudoArr.join("\n");
      document.getElementById("metodologia").value = metodologiaArr.join("\n");
      document.getElementById("observacoes").value = observacoesArr.join("\n");
  
      console.log("Dados colados com sucesso!");
    } catch (err) {
      console.error("Erro ao colar dados:", err.message);
    }
  });
  
    document.getElementById("limpar-campos")?.addEventListener("click", () => {
      ["mes", "dias", "modo", "tipo", "conteudo", "metodologia", "observacoes", "senhaProfessor"]
        .forEach(id => {
          const el = document.getElementById(id);
          if (el) el.value = "";
        });
      console.log("Campos limpos!");
    });
  
    document.getElementById("fechar-formulario")?.addEventListener("click", () => {
      wrapper.remove();
    });
  
    document.getElementById("enviar-dados")?.addEventListener("click", () => {
      const campos = ["mes", "dias", "modo", "tipo", "conteudo", "metodologia", "observacoes"];
      const dados = Object.fromEntries(
        campos.map((id) => [
          id,
          document.getElementById(id).value.trim().split("\n"),
        ])
      );
  
      const senha = document.getElementById("senhaProfessor").value.trim();
      localStorage.setItem("registroAulasDados", JSON.stringify(dados));
      localStorage.setItem("senhaProfessor", senha);
      console.log("Dados e senha salvos!");
      chrome.runtime.sendMessage({ acao: "executarContent" });
  
    });
  
  })();
}


// Loop e funções de registro (do pacote funcional enviado por você)
let lastUrl = location.href;
new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    // Se voltou para a lista, executa o próximo registro
    if (
      location.href.includes("/registro-aula") &&
      !location.href.includes("/registro-aula/registrar")
    ) {
      setTimeout(() => {
        iniciarRegistro();
      }, 1000); // Aguarda 1s para garantir que o DOM está pronto
    }
    // Se está no formulário, preenche
    if (location.href.includes("/registro-aula/registrar")) {
      preencherFormulario();
    }
  }
}).observe(document, { subtree: true, childList: true });

async function waitForElement(selector, timeout = 5000, interval = 500) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const el = document.querySelector(selector);
    if (el) return el;
    await new Promise((r) => setTimeout(r, interval));
  }
  return null;
}

async function waitForElementToDisappear(
  selector,
  timeout = 5000,
  interval = 500
) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const el = document.querySelector(selector);
    const visible = el && el.offsetParent !== null;
    if (!el || !visible) return true;
    await new Promise((res) => setTimeout(res, interval));
  }
  console.warn(`Elemento '${selector}' não desapareceu após ${timeout}ms.`);
  return false;
}

function atualizarContadores() {
  const dados = JSON.parse(localStorage.getItem("registroAulasDados") || "{}");
  const total = Array.isArray(dados.dias) ? dados.dias.length : 0;
  const atual = parseInt(localStorage.getItem("registroAulasIndex") || "0", 10);

  const aulasRegistradas = document.getElementById("aulas-registradas");
  const aulasRestantes = document.getElementById("aulas-restantes");

  if (aulasRegistradas) aulasRegistradas.textContent = atual;
  if (aulasRestantes) aulasRestantes.textContent = Math.max(total - atual, 0);
}


async function iniciarRegistro() {
  const delay = (ms) => new Promise((res) => setTimeout(res, ms));
  const dados = JSON.parse(localStorage.getItem("registroAulasDados") || "{}");
  const senha = localStorage.getItem("senhaProfessor");

  if (!dados || !senha) {
    console.warn("Dados ou senha não encontrados.");
    return;
  }

  let indexAtual = parseInt(localStorage.getItem("registroAulasIndex") || "0", 10);
  const dias = dados.dias || [];
  if (indexAtual >= dias.length) {
    alert("Registro de aulas finalizado!");
    localStorage.removeItem("registroAulasIndex");
    localStorage.removeItem("registroAulasDados");
    localStorage.removeItem("senhaProfessor");
    return;
  }

  const url = window.location.href;
  const paginaLista =
    url.includes("/registro-aula") && !url.includes("/registro-aula/registrar");

  if (paginaLista) {
    // 1. Clicar no botão Registrar Aula
    const botaoRegistrarAula = document.querySelector("button.btn.btn-primary-dark");
    if (!botaoRegistrarAula) {
      console.warn("Botão 'Registrar Aula' não encontrado.");
      return;
    }
    console.log("Clicando no botão 'Registrar Aula' para abrir o modal...");
    botaoRegistrarAula.click();

    // 2. Aguardar modal aparecer
    const modal = await waitForElement(".modal-content");
    if (!modal) {
      console.warn("Modal de seleção mês/dia não apareceu.");
      return;
    }
    console.log("Modal apareceu.");

    // 2.1 Esperar o loading sumir
    await waitForElementToDisappear("app-loading-custom, ngx-loading");
    console.log("Loading finalizado.");

    // 3. Selecionar mês no input autocomplete
    const inputMes = modal.querySelector("input[placeholder='Selecione']");
    if (!inputMes) {
      console.warn("Input mês não encontrado.");
      return;
    }

    const mesAlvo = dados.mes[indexAtual].toLowerCase();

    // Focar e limpar input
    inputMes.focus();
    inputMes.value = "";
    inputMes.dispatchEvent(new Event("input", { bubbles: true }));
    await waitForElement(`#${inputMes.getAttribute("aria-controls")}`);

    // Digitar o mês
    inputMes.value = mesAlvo;
    inputMes.dispatchEvent(new Event("input", { bubbles: true }));
    console.log(`Digitado no mês: ${mesAlvo}`);

    // 4. Esperar dropdown com opções aparecer
    const idDropdown = inputMes.getAttribute("aria-controls");
    if (!idDropdown) {
      console.warn("Dropdown id não encontrado no input mês.");
      return;
    }

    const dropdownSelector = `#${idDropdown}`;
    const dropdown = await waitForElement(dropdownSelector);
    if (!dropdown) {
      console.warn("Dropdown de meses não apareceu.");
      return;
    }

    // 5. Encontrar a opção correta na lista
    const opcoes = Array.from(dropdown.querySelectorAll("li"));
    const opcaoMes = opcoes.find(
      (li) => li.textContent.trim().toLowerCase() === mesAlvo
    );
    if (!opcaoMes) {
      console.warn(`Opção de mês '${mesAlvo}' não encontrada no dropdown.`);
      return;
    }

    opcaoMes.click();
    console.log(`Mês selecionado: ${mesAlvo}`);

    // 6. Esperar o calendário carregar dias
    await waitForElementToDisappear("app-loading-custom, ngx-loading");
    console.log("Segundo loading finalizado.");

    // Aguardar extra para garantir DOM atualizado (opcional)
    await waitForElement("#input-password");

    // 7. Selecionar o dia
    const diaAlvo = dados.dias[indexAtual].padStart(2, "0");
    const diaSelector = ".calendario-dia";
    const diasElemento = Array.from(modal.querySelectorAll(diaSelector));

    const diaDiv = diasElemento.find(
      (div) => div.innerText.trim().padStart(2, "0") === diaAlvo
    );

    if (!diaDiv) {
      console.warn(`Dia '${diaAlvo}' não encontrado no calendário.`);
      console.log(
        "Dias encontrados:",
        diasElemento.map((div) => div.innerText)
      );
      return;
    }

    // Clique com segurança
    const evt = new MouseEvent("click", { bubbles: true, cancelable: true });
    diaDiv.dispatchEvent(evt);
    console.log(`Dia selecionado: ${diaAlvo}`);

    await delay(500);

    // 8. Clicar no botão "Registrar" dentro do modal
    const botaoRegistrar =
      modal.querySelector("button.btn.btn-primary") ||
      modal.querySelector("button:contains('Registrar')");
    if (!botaoRegistrar) {
      console.warn("Botão 'Registrar' não encontrado no modal.");
      return;
    }

    botaoRegistrar.click();
    console.log("Clicado no botão 'Registrar' para abrir o formulário.");
  }
}

// Chama iniciarRegistro ao carregar a página
iniciarRegistro();

// Função separada para preencher o formulário
async function preencherFormulario() {
  console.log("Preenchendo formulário...");
  const delay = (ms) => new Promise((res) => setTimeout(res, ms));
  const dados = JSON.parse(localStorage.getItem("registroAulasDados") || "{}");
  const senha = localStorage.getItem("senhaProfessor");
  let indexAtual = parseInt(localStorage.getItem("registroAulasIndex") || "0", 10);

  console.log(dados, senha, indexAtual);

  if (!dados || !senha || indexAtual >= (dados.dias || []).length) {
    console.warn("Dados insuficientes para preenchimento.");
    return;
  }

  // Aguarde o campo do período aparecer
  /*const periodoInput = await waitForElement(
    "#autocomplete-periodo input[placeholder='Selecione']",
    10000
  );
  if (periodoInput) {
    periodoInput.focus();
    periodoInput.value = dados.periodo[indexAtual] || "";
    periodoInput.dispatchEvent(new Event("input", { bubbles: true }));
    await delay(500);
    periodoInput.dispatchEvent(
      new KeyboardEvent("keydown", { key: "ArrowDown" })
    );
    periodoInput.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter" }));
    console.log("Período preenchido.");
  }*/

  // Modo de Aula (radio)
  const modoAula = (dados.modoAula?.[indexAtual] || "").toUpperCase();
  console.log(`Modo de Aula: ${modoAula}`);
  const modoRadio = document.querySelector(`#option-${modoAula}`);
  if (modoRadio) {
    modoRadio.click();
    console.log(`Modo de Aula selecionado: ${modoAula}`);
    await delay(300);
  }
  // Tipo de Aula (radio)
  const tipoAula = (dados.tipoAula?.[indexAtual] || "AVULSO")
    .toUpperCase()
    .replaceAll(" ", "_");
  console.log(`Tipo de Aula: ${tipoAula}`);

  // Busca todos os labels de tipo de aula
  const labelsTipoAula = Array.from(
    document.querySelectorAll("label[for^='option-']")
  );

  const labelTipoAula = labelsTipoAula.find(
    (label) =>
      label.textContent.trim().toLowerCase() ===
      (dados.tipoAula?.[indexAtual] || "Avulso").trim().toLowerCase()
  );

  if (labelTipoAula) {
    labelTipoAula.click();
    console.log(
      `Tipo de Aula selecionado: ${labelTipoAula.textContent.trim()}`
    );
    await delay(300);
  } else {
    console.warn(
      `Label para tipo de aula '${dados.tipoAula[indexAtual]}' não encontrado.`
    );
  }

  // Se tipo AVULSO, preencher campos adicionais
  if (tipoAula === "AVULSO") {
    // Objetos de Conhecimento
    const objetosInput = await waitForElement("#textarea-objetosConhecimento");
    if (objetosInput) {
      objetosInput.value = dados.conteudo?.[indexAtual] || "";
      objetosInput.dispatchEvent(new Event("input", { bubbles: true }));
      console.log("Objetos de Conhecimento preenchidos.");
    }

    // Metodologia
    const metodologiaInput = await waitForElement("#metodologia input[placeholder='Selecione']", 10000);
    if (metodologiaInput) {
      metodologiaInput.focus();
      metodologiaInput.value = dados.metodologia?.[indexAtual] || "";
      metodologiaInput.dispatchEvent(new Event("input", { bubbles: true }));
      await delay(500);

      // Aguarda o dropdown de opções aparecer
      const listaId = metodologiaInput.getAttribute("aria-controls");
      const listaSelector = `#${listaId}`;
      const lista = await waitForElement(listaSelector, 5000);

      if (lista) {
        // Busca a opção correta pelo texto
        const textoMetodologia = (dados.metodologia?.[indexAtual] || "").trim().toLowerCase();
        const opcoes = Array.from(lista.querySelectorAll("li"));
        const opcao = opcoes.find(li =>
          li.textContent.trim().toLowerCase() === textoMetodologia
        );
        if (opcao) {
          opcao.click();
          console.log("Metodologia selecionada e chip adicionado.");
        } else {
          console.warn("Opção de metodologia não encontrada no dropdown.");
        }
      } else {
        console.warn("Dropdown de metodologia não apareceu.");
      }
    }

    const obsInput = document.querySelector("#observacoes");
    if (obsInput) {
      obsInput.value = dados.observacoes?.[indexAtual] || "";
      obsInput.dispatchEvent(new Event("input", { bubbles: true }));
      console.log("Observações preenchidas.");
    }
  }

  // Botão salvar
  const botaoSalvar = document.querySelector("#btn-submit");
  if (botaoSalvar) {
    botaoSalvar.click();
    console.log("Formulário enviado!");
    await delay(800); // Aguarde o modal de senha aparecer
  }

  // Aguarda o modal de senha aparecer
  const senhaModalInput = await waitForElement("#input-password");
  if (senhaModalInput) {
    senhaModalInput.value = senha;
    senhaModalInput.dispatchEvent(new Event("input", { bubbles: true }));
    console.log("Senha do modal preenchida.");

    // Aguarda o botão "Confirmar" aparecer e clica
    const botoesConfirmar = Array.from(document.querySelectorAll("button.btn-primary"));
    const botaoConfirmar = botoesConfirmar.find(btn =>
      btn.textContent.replace(/\s/g, "").toLowerCase().includes("confirmar")
    );

    if (botaoConfirmar) {
      botaoConfirmar.click();
      console.log("Botão Confirmar clicado.");
    } else {
      console.warn("Botão Confirmar não encontrado.");
    }
  }

  indexAtual++;
  console.log("indexAtual: ", indexAtual)
  localStorage.setItem("registroAulasIndex", indexAtual.toString());
  atualizarContadores();
}


// Expose iniciarRegistro for background execution if needed
if (typeof window !== 'undefined') {
  window.iniciarRegistro = typeof iniciarRegistro === 'function' ? iniciarRegistro : (function(){console.warn('iniciarRegistro não está definido');});
  window.abrirFormularioAulas = abrirFormularioAulas;
}

console.log('[content-aulas] Módulo carregado.');
