// content-frequencia.js - Modulo de Registro de Frequencia
// Interface visual: form-frequencia.html/css (design moderno)
// Automacao: Data -> Periodo (auto) -> Tempo -> Salvar -> Proxima data

// isUIFrequenciaOpen ja declarado em content-utils.js

// ============================================================
// PARTE 1: ABRIR FORMULARIO (interface bonita form-frequencia)
// ============================================================

window.abrirFormularioFrequencia = function() {
  console.log('[FREQ] Abrindo formulario de frequencia...');

  if (isUIFrequenciaOpen) {
    const existing = document.getElementById('registro-frequencia-wrapper');
    if (existing) { existing.style.zIndex = 999999; existing.style.pointerEvents = 'auto'; return; }
  }

  document.getElementById("registro-frequencia-wrapper")?.remove();

  const wrapper = document.createElement("div");
  wrapper.id = "registro-frequencia-wrapper";
  wrapper.style.cssText = `
    position: fixed; top: 80px; right: 20px; z-index: 999999;
    max-width: 100%; max-height: 90vh;
  `;

  Promise.all([
    fetch(chrome.runtime.getURL("form-frequencia.html")).then(r => r.text()),
    fetch(chrome.runtime.getURL("form-frequencia.css")).then(r => r.text())
  ]).then(([html, css]) => {
    const style = document.createElement("style");
    style.textContent = css;
    wrapper.prepend(style);
    wrapper.innerHTML += html;
    document.body.appendChild(wrapper);
    inicializarEventosFrequencia();
  });
};

// ============================================================
// PARTE 2: EVENTOS DO FORMULARIO
// ============================================================

function inicializarEventosFrequencia() {
  const wrapper = document.getElementById("registro-frequencia-wrapper");
  if (!wrapper) return;
  const popup = document.getElementById("registro-frequencia-popup");

  // Arrastavel
  popup.onmousedown = (e) => {
    if (['TEXTAREA','INPUT','BUTTON','I'].includes(e.target.tagName)) return;
    const shiftX = e.clientX - wrapper.getBoundingClientRect().left;
    const shiftY = e.clientY - wrapper.getBoundingClientRect().top;
    const onMove = (ev) => {
      wrapper.style.left = `${ev.pageX - shiftX}px`;
      wrapper.style.top = `${ev.pageY - shiftY}px`;
      wrapper.style.right = "auto";
    };
    const onUp = () => { document.removeEventListener("mousemove", onMove); document.removeEventListener("mouseup", onUp); };
    document.addEventListener("mousemove", onMove);
    document.addEventListener("mouseup", onUp);
  };

  // Toggle senha
  document.getElementById("toggle-senha-freq")?.addEventListener("click", () => {
    const input = document.getElementById("freq-senha");
    const icon = document.getElementById("icon-olho-freq");
    if (input.type === "password") {
      input.type = "text"; icon.classList.remove("fa-eye-slash"); icon.classList.add("fa-eye");
    } else {
      input.type = "password"; icon.classList.remove("fa-eye"); icon.classList.add("fa-eye-slash");
    }
  });

  // Colar do Excel (formato: DATA <tab> TEMPO)
  document.getElementById("colar-dados-freq")?.addEventListener("click", async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (!text) return;
      const linhas = text.trim().split(/\r?\n/);
      if (linhas[0].toLowerCase().includes("data")) linhas.shift();
      const datasArr = [], temposArr = [];
      for (const linha of linhas) {
        const partes = linha.split("\t");
        datasArr.push(partes[0]?.trim() || "");
        temposArr.push(partes[1]?.trim() || "");
      }
      document.getElementById("freq-datas").value = datasArr.join("\n");
      document.getElementById("freq-tempos").value = temposArr.join("\n");
      console.log("[FREQ] Dados colados:", datasArr.length, "registros");
    } catch (err) {
      console.error("[FREQ] Erro ao colar:", err.message);
      alert("Erro ao acessar clipboard. Cole manualmente.");
    }
  });

  // Limpar
  document.getElementById("limpar-campos-freq")?.addEventListener("click", () => {
    ["freq-datas", "freq-tempos", "freq-senha"].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = "";
    });
    localStorage.removeItem("registroFrequenciaDados");
    localStorage.removeItem("registroFrequenciaIndex");
    localStorage.removeItem("senhaProfessorFrequencia");
    localStorage.removeItem("registroFrequenciaErros");
    localStorage.removeItem("registroFrequenciaErrosConsec");
    desativarDetectorErroAuth();
    atualizarContadoresFrequencia();
    console.log("[FREQ] Campos limpos.");
  });

  // Iniciar Registro
  document.getElementById("enviar-dados-freq")?.addEventListener("click", () => {
    const datas = document.getElementById("freq-datas").value.trim().split("\n").filter(l => l.trim());
    const tempos = document.getElementById("freq-tempos").value.trim().split("\n").filter(l => l.trim());
    const senha = document.getElementById("freq-senha").value.trim();

    if (datas.length === 0) { alert("Preencha pelo menos uma data."); return; }
    if (datas.length !== tempos.length) { alert(`Inconsistencia: ${datas.length} datas e ${tempos.length} tempos.`); return; }
    if (!senha) { alert("Digite a senha de confirmacao."); return; }

    const dados = { datas, tempos };
    localStorage.setItem("registroFrequenciaDados", JSON.stringify(dados));
    localStorage.setItem("registroFrequenciaIndex", "0");
    localStorage.setItem("senhaProfessorFrequencia", senha);
    localStorage.setItem("registroFrequenciaErros", "[]");
    localStorage.setItem("registroFrequenciaErrosConsec", "0");

    _senhaCache = senha;
    ativarDetectorErroAuth();

    console.log("[FREQ] Dados salvos:", dados);
    atualizarContadoresFrequencia();
    iniciarRegistroFrequencia();
  });

  // Fechar
  document.getElementById("fechar-formulario-freq")?.addEventListener("click", () => {
    wrapper.remove();
    isUIFrequenciaOpen = false;
  });

  isUIFrequenciaOpen = true;
}

function atualizarContadoresFrequencia() {
  const dados = JSON.parse(localStorage.getItem("registroFrequenciaDados") || "{}");
  const total = Array.isArray(dados.datas) ? dados.datas.length : 0;
  const atual = parseInt(localStorage.getItem("registroFrequenciaIndex") || "0", 10);
  const elReg = document.getElementById("freq-registradas");
  const elRest = document.getElementById("freq-restantes");
  if (elReg) elReg.textContent = atual;
  if (elRest) elRest.textContent = Math.max(total - atual, 0);
}

// ============================================================
// PARTE 3: LOOP PRINCIPAL DE REGISTRO
// ============================================================

async function iniciarRegistroFrequencia() {
  const delay = (ms) => new Promise(r => setTimeout(r, ms));
  const dadosRaw = localStorage.getItem("registroFrequenciaDados");
  const senha = localStorage.getItem("senhaProfessorFrequencia");

  if (!dadosRaw || !senha) { console.log("[FREQ LOOP] Sem dados/senha."); return; }

  const dados = JSON.parse(dadosRaw);
  let idx = parseInt(localStorage.getItem("registroFrequenciaIndex") || "0", 10);
  const datas = dados.datas || [];
  let erros = JSON.parse(localStorage.getItem("registroFrequenciaErros") || "[]");
  let errosConsec = parseInt(localStorage.getItem("registroFrequenciaErrosConsec") || "0", 10);

  // Terminou?
  if (idx >= datas.length) {
    mostrarResumoFinal(datas.length, erros);
    desativarDetectorErroAuth();
    return;
  }

  // Pagina correta?
  if (!window.location.href.includes("/frequencia/cadastrar")) {
    console.warn("[FREQ LOOP] Nao estamos na tela de frequencia.", window.location.href);
    return;
  }

  console.log(`[FREQ LOOP] === ${idx + 1}/${datas.length}: ${dados.datas[idx]} | Tempo: ${dados.tempos[idx]} ===`);

  const sucesso = await preencherUmaData(dados.datas[idx], dados.tempos[idx], senha);

  if (!sucesso) {
    erros.push(`${dados.datas[idx]} (tempo: ${dados.tempos[idx]})`);
    localStorage.setItem("registroFrequenciaErros", JSON.stringify(erros));
    errosConsec++;
    localStorage.setItem("registroFrequenciaErrosConsec", String(errosConsec));
    console.warn(`[FREQ LOOP] ERRO em ${dados.datas[idx]}. Consecutivos: ${errosConsec}`);
    if (errosConsec >= 5) {
      alert("5 erros consecutivos! Parando por seguranca.\n" + erros.slice(-5).map(e => "  - " + e).join("\n"));
      desativarDetectorErroAuth(); return;
    }
  } else {
    if (errosConsec > 0) { localStorage.setItem("registroFrequenciaErrosConsec", "0"); errosConsec = 0; }
  }

  idx++;
  localStorage.setItem("registroFrequenciaIndex", idx.toString());
  atualizarContadoresFrequencia();

  if (idx >= datas.length) {
    mostrarResumoFinal(datas.length, erros);
    desativarDetectorErroAuth();
    return;
  }
}

// ============================================================
// PARTE 4: PREENCHER UMA UNICA DATA
// ============================================================

async function preencherUmaData(dataStr, tempoStr, senha) {
  const delay = (ms) => new Promise(r => setTimeout(r, ms));
  console.log(`[FREQ FORM] Data: ${dataStr} | Tempos: ${tempoStr}`);

  // 1. PREENCHER DATA
  const campoData = await waitForElement('input[placeholder="dd/mm/aaaa"]', 10000);
  if (!campoData) { console.error("[FREQ FORM] Campo DATA nao encontrado"); return false; }

  const dataOk = await preencherDataNoCalendar(campoData, dataStr);
  if (!dataOk) { console.error(`[FREQ FORM] Falha ao preencher data ${dataStr}`); return false; }

  // 2. AGUARDAR PERIODO
  await delay(3000);
  const campoPeriodo = await waitForElement('#autocomplete-periodo input[placeholder="Selecione"]', 5000);
  if (campoPeriodo && campoPeriodo.value) console.log(`[FREQ FORM] Periodo: ${campoPeriodo.value}`);

  // 3. SELECIONAR TEMPO(S)
  const temposNumeros = tempoStr.split(/[,;]/)
    .map(t => parseInt(t.replace(/[^0-9]/g, ''), 10))
    .filter(n => !isNaN(n) && n >= 1 && n <= 9);
  if (temposNumeros.length === 0) { console.warn("[FREQ FORM] Tempo invalido:", tempoStr); return false; }

  const multiselect = await waitForElement('#mutiselect-tempo .ui-multiselect', 5000);
  if (!multiselect) { console.error("[FREQ FORM] Multiselect nao encontrado"); return false; }

  multiselect.click(); await delay(1000);

  for (const numTempo of temposNumeros) {
    const labelTexto = `${numTempo}º Tempo`;
    const itens = document.querySelectorAll('.ui-multiselect-panel .ui-multiselect-items li, .ui-multiselect-items li');
    let encontrado = false;
    for (const item of itens) {
      const texto = item.textContent.trim();
      if (texto.includes(`${numTempo}º`) || texto.includes(`${numTempo} `)) {
        const chk = item.querySelector('.ui-chkbox-box') || item.querySelector('input') || item;
        const jaSel = item.classList.contains('ui-state-highlight');
        if (!jaSel) { chk.click(); console.log(`[FREQ FORM] ✓ ${labelTexto}`); }
        else { console.log(`[FREQ FORM] ✓ ${labelTexto} (ja selecionado)`); }
        encontrado = true; await delay(300); break;
      }
    }
    if (!encontrado) console.warn(`[FREQ FORM] ✗ ${labelTexto} nao encontrado`);
  }
  document.body.click(); await delay(800);

  // 4. AGUARDAR TABELA
  await delay(2000);
  console.log("[FREQ FORM] Tabela carregada (alunos presentes)");

  // 5. SALVAR
  const btnSalvar = await waitForElement('#btn-submit', 5000);
  if (!btnSalvar) { console.error("[FREQ FORM] Botao SALVAR nao encontrado"); return false; }
  btnSalvar.scrollIntoView({ behavior: 'smooth', block: 'center' });
  await delay(500);
  btnSalvar.click();
  console.log("[FREQ FORM] ✓ SALVAR clicado");

  // 6. SENHA + CONFIRMAR
  await delay(1500);
  const senhaInput = await waitForElement('#input-password', 8000);
  if (senhaInput) {
    senhaInput.value = senha;
    senhaInput.dispatchEvent(new Event('input', { bubbles: true }));
    await delay(500);
    const botoes = Array.from(document.querySelectorAll('button.btn-primary'));
    const btnConfirmar = botoes.find(btn => btn.textContent.replace(/\s/g, '').toLowerCase().includes('confirmar'));
    if (btnConfirmar) { btnConfirmar.click(); console.log("[FREQ FORM] ✓ CONFIRMAR clicado"); }
  } else {
    console.log("[FREQ FORM] Modal de senha nao apareceu");
  }

  console.log("[FREQ FORM] ✓ Registro concluido");
  return true;
}

// ============================================================
// PARTE 5: NAVEGACAO NO CALENDARIO
// ============================================================

async function preencherDataNoCalendar(inputEl, dataStr) {
  const delay = (ms) => new Promise(r => setTimeout(r, ms));
  const [diaStr, mesStr, anoStr] = dataStr.split('/');
  const diaAlvo = parseInt(diaStr, 10);
  const mesAlvo = parseInt(mesStr, 10);
  const anoAlvo = parseInt(anoStr, 10);
  const mesAlvo0 = mesAlvo - 1;

  console.log(`[FREQ CALENDAR] Alvo: ${diaAlvo}/${mesAlvo}/${anoAlvo}`);

  // Passo 1: Abrir calendario
  inputEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
  await delay(500);

  let btnCalendario = document.querySelector('button.ui-datepicker-trigger, button.ui-calendar-button');
  if (!btnCalendario) {
    for (const btn of document.querySelectorAll('button')) {
      if (btn.querySelector('.pi-calendar')) { btnCalendario = btn; break; }
    }
  }
  if (!btnCalendario) { console.warn("[FREQ CALENDAR] Botao calendario nao encontrado"); return false; }

  btnCalendario.click();
  await delay(1200);

  let painel = document.querySelector('.ui-datepicker');
  if (!painel) { console.warn("[FREQ CALENDAR] Painel nao abriu"); return false; }

  // Passo 2: Ler estado inicial
  const mesesPt = ['janeiro','fevereiro','marco','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
  const mesesPtAbrev = ['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'];

  function lerMes(p) {
    const span = p.querySelector('.ui-datepicker-month');
    if (!span) return -1;
    const t = span.textContent.trim().toLowerCase();
    for (let i = 0; i < 12; i++) {
      if (t.includes(mesesPt[i]) || t.includes(mesesPtAbrev[i])) return i;
    }
    return -1;
  }

  let mesInicial = lerMes(painel);
  const anoSelect = painel.querySelector('select.ui-datepicker-year');
  let anoInicial = anoSelect ? parseInt(anoSelect.value, 10) : -1;

  console.log(`[FREQ CALENDAR] Inicial: mes=${mesInicial + 1}, ano=${anoInicial}`);
  if (mesInicial < 0 || anoInicial < 0) { console.warn("[FREQ CALENDAR] Nao leu mes/ano"); return false; }

  // Passo 3: Mudar ANO via select
  if (anoSelect && anoInicial !== anoAlvo) {
    console.log(`[FREQ CALENDAR] >>> ANO: ${anoInicial} -> ${anoAlvo}`);
    anoSelect.value = String(anoAlvo);
    anoSelect.dispatchEvent(new Event('change', { bubbles: true }));
    await delay(1200);
    painel = document.querySelector('.ui-datepicker');
    mesInicial = lerMes(painel);
    console.log(`[FREQ CALENDAR] Apos ano: mes=${mesInicial + 1}`);
  }

  // Passo 4: Mudar MES (contagem fixa, SEM ler DOM entre clicks)
  let mesesDiff = mesAlvo0 - mesInicial;
  if (mesesDiff !== 0) {
    const direcao = mesesDiff > 0 ? 'NEXT' : 'PREV';
    const totalClicks = Math.abs(mesesDiff);
    console.log(`[FREQ CALENDAR] >>> MES: ${mesInicial + 1} -> ${mesAlvo} (${totalClicks} clicks ${direcao})`);

    for (let i = 0; i < totalClicks; i++) {
      painel = document.querySelector('.ui-datepicker');
      if (!painel) { console.warn(`[FREQ CALENDAR] Painel sumiu no click ${i + 1}`); return false; }
      const btn = direcao === 'NEXT' ? painel.querySelector('.ui-datepicker-next') : painel.querySelector('.ui-datepicker-prev');
      if (!btn) { console.warn(`[FREQ CALENDAR] Seta ${direcao} nao encontrada`); return false; }
      btn.click();
      await delay(800);
    }
    console.log(`[FREQ CALENDAR] ${totalClicks} clicks concluidos`);
    await delay(1000);
  }

  // Passo 5: Verificar mes final
  painel = document.querySelector('.ui-datepicker');
  if (!painel) { console.warn("[FREQ CALENDAR] Painel sumiu"); return false; }

  const mesFinal = lerMes(painel);
  console.log(`[FREQ CALENDAR] Final: mes=${mesFinal + 1} (esperado: ${mesAlvo})`);
  if (mesFinal !== mesAlvo0) { console.warn("[FREQ CALENDAR] Mes ERRADO"); return false; }

  // Passo 6: Clicar no DIA
  const celulas = painel.querySelectorAll('.ui-datepicker-calendar td');
  for (const td of celulas) {
    if (td.classList.contains('ui-datepicker-other-month')) continue;
    if (td.classList.contains('ui-state-disabled')) continue;
    const link = td.querySelector('a.ui-state-default, span.ui-state-default');
    if (!link) continue;
    const numDia = parseInt(link.textContent.trim(), 10);
    if (numDia === diaAlvo) {
      link.scrollIntoView({ block: 'center' });
      await delay(200);
      link.click();
      console.log(`[FREQ CALENDAR] ✓ Dia ${diaAlvo} clicado`);
      await delay(800);
      if (inputEl.value && inputEl.value.includes(diaStr.padStart(2, '0'))) {
        console.log(`[FREQ CALENDAR] ✓✓✓ DATA OK: "${inputEl.value}"`);
        return true;
      }
      return false;
    }
  }

  console.warn(`[FREQ CALENDAR] Dia ${diaAlvo} nao encontrado`);
  return false;
}

// ============================================================
// PARTE 6: OBSERVADOR DE URL
// ============================================================

let lastUrlFreq = location.href;
new MutationObserver(() => {
  if (location.href !== lastUrlFreq) {
    lastUrlFreq = location.href;

    const temDados = localStorage.getItem("registroFrequenciaDados");
    if (!temDados) return;

    const idxObs = parseInt(localStorage.getItem("registroFrequenciaIndex") || "0", 10);
    const dadosObs = JSON.parse(temDados);

    // Terminou?
    if (dadosObs.datas && idxObs >= dadosObs.datas.length) {
      const errosObs = JSON.parse(localStorage.getItem("registroFrequenciaErros") || "[]");
      setTimeout(() => mostrarResumoFinal(dadosObs.datas.length, errosObs), 1000);
      return;
    }

    if (location.href.includes('/frequencia/cadastrar')) {
      console.log("[FREQ OBSERVER] Na tela de cadastro. Continuando...");
      setTimeout(() => iniciarRegistroFrequencia(), 2500);
      return;
    }

    if (location.href.includes('/frequencia') && !location.href.includes('/cadastrar')) {
      console.log("[FREQ OBSERVER] Na listagem. Clicando em Registrar Frequencia...");
      setTimeout(() => clicarRegistrarFrequencia(), 2000);
      return;
    }
  }
}).observe(document, { subtree: true, childList: true });

async function clicarRegistrarFrequencia() {
  await new Promise(r => setTimeout(r, 1500));
  const todosBotoes = document.querySelectorAll('button');
  let btn = null;
  for (const b of todosBotoes) {
    const texto = b.textContent.toLowerCase().replace(/\s/g, '');
    const routerlink = b.getAttribute('routerlink');
    if ((texto.includes('registrarfrequencia') || texto.includes('registrarfrequência')) && routerlink === 'cadastrar') {
      btn = b; break;
    }
  }
  if (!btn) {
    for (const b of todosBotoes) {
      if (b.classList.contains('btn-primary-dark') && b.querySelector('.bi-person-check-fill')) { btn = b; break; }
    }
  }
  if (!btn) {
    for (const b of todosBotoes) {
      if (b.textContent.toLowerCase().includes('registrar') && b.textContent.toLowerCase().includes('frequen')) { btn = b; break; }
    }
  }
  if (btn) {
    btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await new Promise(r => setTimeout(r, 500));
    btn.click();
    console.log("[FREQ REGISTRAR] ✓ Registrar Frequencia clicado");
  } else {
    console.warn("[FREQ REGISTRAR] Botao nao encontrado");
  }
}

// ============================================================
// PARTE 7: MODAL DE RESUMO FINAL
// ============================================================

function mostrarResumoFinal(totalDatas, erros) {
  console.log("[FREQ RESUMO] >>> CHAMANDO RESUMO FINAL <<<");
  const sucessos = totalDatas - erros.length;

  const existente = document.getElementById('freq-resumo-modal');
  if (existente) existente.remove();

  const overlay = document.createElement('div');
  overlay.id = 'freq-resumo-modal';
  overlay.style.cssText = `
    position: fixed; top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.5); z-index: 2147483647;
    display: flex; align-items: center; justify-content: center;
    font-family: 'Segoe UI', Arial, sans-serif;
  `;

  let errosHtml = '';
  if (erros.length > 0) {
    errosHtml = `
      <div style="margin-top: 16px; text-align: left; max-height: 200px; overflow-y: auto;">
        <p style="color: #dc3545; font-weight: 600; margin: 0 0 8px 0; font-size: 0.95em;">
          ✗ ${erros.length} data(s) com erro:
        </p>
        <ul style="margin: 0; padding-left: 20px; color: #555; font-size: 0.9em;">
          ${erros.map(e => `<li style="margin-bottom: 4px;">${e}</li>`).join('')}
        </ul>
      </div>`;
  }

  overlay.innerHTML = `
    <div style="background: white; border-radius: 16px; padding: 32px; max-width: 420px; width: 90%;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3); text-align: center;
                animation: freqFadeIn 0.3s ease;">
      <div style="font-size: 3em; margin-bottom: 8px;">${erros.length > 0 ? '⚠️' : '✅'}</div>
      <h2 style="margin: 0 0 8px 0; color: #333; font-size: 1.4em;">
        ${erros.length > 0 ? 'Registro Concluido!' : 'Tudo Certo!'}
      </h2>
      <p style="color: #666; margin: 0 0 16px 0; font-size: 0.95em;">
        ${erros.length > 0 ? 'Algumas datas foram registradas com sucesso.' : 'Todas as frequencias foram lancadas com sucesso!'}
      </p>
      <div style="display: flex; gap: 16px; justify-content: center; margin: 20px 0;">
        <div style="background: #d4edda; border-radius: 12px; padding: 12px 20px;">
          <div style="font-size: 1.6em; font-weight: 700; color: #155724;">${sucessos}</div>
          <div style="font-size: 0.8em; color: #155724;">✓ OK</div>
        </div>
        ${erros.length > 0 ? `
        <div style="background: #f8d7da; border-radius: 12px; padding: 12px 20px;">
          <div style="font-size: 1.6em; font-weight: 700; color: #721c24;">${erros.length}</div>
          <div style="font-size: 0.8em; color: #721c24;">✗ Erro</div>
        </div>` : ''}
      </div>
      ${errosHtml}
      <button id="freq-btn-ok" style="margin-top: 20px; background: linear-gradient(135deg, #28a745, #20c997);
        color: white; border: none; border-radius: 10px; padding: 12px 36px;
        font-size: 1.1em; font-weight: 600; cursor: pointer;
        transition: transform 0.15s, filter 0.2s;">OK</button>
    </div>
    <style>@keyframes freqFadeIn { from { opacity: 0; transform: scale(0.9); } to { opacity: 1; transform: scale(1); } }</style>
  `;

  document.body.appendChild(overlay);
  overlay.querySelector('#freq-btn-ok').addEventListener('click', () => {
    localStorage.removeItem('registroFrequenciaDados');
    localStorage.removeItem('registroFrequenciaIndex');
    localStorage.removeItem('senhaProfessorFrequencia');
    localStorage.removeItem('registroFrequenciaErros');
    localStorage.removeItem('registroFrequenciaErrosConsec');
    overlay.remove();
    const wrapper = document.getElementById('registro-frequencia-wrapper');
    if (wrapper) { wrapper.remove(); isUIFrequenciaOpen = false; }
    desativarDetectorErroAuth();
    console.log("[FREQ RESUMO] Modal fechado. Dados limpos.");
  });
}

// ============================================================
// PARTE 8: DETECTOR DE ERRO DE AUTENTICACAO
// ============================================================

let _senhaCache = null;

const observerErroAuth = new MutationObserver(() => {
  const modalErro = document.querySelector('.swal2-container, .swal2-popup');
  if (!modalErro) return;
  const btnOk = modalErro.querySelector('.swal2-confirm, .swal2-confirm.btn-primary');
  if (!btnOk) return;
  const texto = btnOk.textContent.trim().toLowerCase();
  if (texto !== 'ok') return;
  const modalTexto = modalErro.textContent.toLowerCase();
  const ehErro = modalTexto.includes('erro') || modalTexto.includes('falha') ||
                 modalTexto.includes('invalid') || modalTexto.includes('nao foi possivel') ||
                 modalTexto.includes('tente novamente') || modalTexto.includes('senha');
  if (!ehErro) return;

  console.log("[FREQ ERRO AUTH] Modal de erro detectado! Clicando OK...");
  btnOk.click();
  console.log("[FREQ ERRO AUTH] OK clicado! Aguardando senha reaparecer...");
  setTimeout(() => tentarConfirmarSenhaNovamente(), 1500);
});

async function tentarConfirmarSenhaNovamente() {
  const senha = _senhaCache || localStorage.getItem("senhaProfessorFrequencia");
  if (!senha) { console.warn("[FREQ ERRO AUTH] Sem senha em cache"); return; }

  for (let tentativa = 0; tentativa < 10; tentativa++) {
    const senhaInput = document.querySelector('#input-password');
    if (senhaInput && senhaInput.offsetParent !== null) {
      console.log("[FREQ ERRO AUTH] Modal de senha reapareceu! Reenviando...");
      senhaInput.value = senha;
      senhaInput.dispatchEvent(new Event('input', { bubbles: true }));
      await new Promise(r => setTimeout(r, 500));
      const botoes = Array.from(document.querySelectorAll('button.btn-primary'));
      const btnConfirmar = botoes.find(btn => btn.textContent.replace(/\s/g, '').toLowerCase().includes('confirmar'));
      if (btnConfirmar && !btnConfirmar.disabled) {
        btnConfirmar.click();
        console.log("[FREQ ERRO AUTH] ✓ Confirmar re-clicado!");
        return;
      }
    }
    await new Promise(r => setTimeout(r, 800));
  }
  console.warn("[FREQ ERRO AUTH] Modal de senha nao reapareceu");
}

function ativarDetectorErroAuth() {
  const temDados = localStorage.getItem("registroFrequenciaDados");
  const senha = localStorage.getItem("senhaProfessorFrequencia");
  if (temDados && senha) {
    _senhaCache = senha;
    observerErroAuth.observe(document.body, { childList: true, subtree: true });
    console.log("[FREQ ERRO AUTH] Detector ATIVADO");
  }
}

function desativarDetectorErroAuth() {
  observerErroAuth.disconnect();
  _senhaCache = null;
  console.log("[FREQ ERRO AUTH] Detector DESATIVADO");
}

// ============================================================
// PARTE 9: UTILITARIOS
// ============================================================

async function waitForElement(selector, timeout = 5000, interval = 200) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const el = document.querySelector(selector);
    if (el && el.isConnected && el.offsetParent !== null) return el;
    await new Promise(r => setTimeout(r, interval));
  }
  console.warn(`[waitForElement] Nao encontrado: ${selector}`);
  return null;
}

if (typeof window !== 'undefined') {
  window.iniciarRegistroFrequencia = iniciarRegistroFrequencia;
  window.preencherUmaData = preencherUmaData;
}

console.log('[content-frequencia] Modulo v2.1 carregado - Interface visual form-frequencia');
