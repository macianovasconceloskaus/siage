// popup.js
document.addEventListener('DOMContentLoaded', function() {
  const abrirAulasBtn = document.getElementById('abrirAulas');
  const abrirNotasBtn = document.getElementById('abrirNotas');
  const abrirFrequenciaBtn = document.getElementById('abrirFrequencia');
  const closePopupBtn = document.getElementById('close-popup-btn');

  abrirAulasBtn.addEventListener('click', () => {
    sendMessageToContentScript('openAulasForm');
    window.close();
  });

  abrirNotasBtn.addEventListener('click', () => {
    sendMessageToContentScript('openNotasForm');
    window.close();
  });

  abrirFrequenciaBtn.addEventListener('click', () => {
    sendMessageToContentScript('openFrequenciaForm');
    window.close();
  });

  closePopupBtn.addEventListener('click', () => {
    window.close();
  });

  function sendMessageToContentScript(action) {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      const activeTab = tabs[0];
      if (activeTab) {
        const siageUrlRegex = /^(https?:\/\/(professor\.see\.pb\.gov\.br|.*\.siage\.educacao\.ba\.gov\.br))(\/.*)?$/;
        if (siageUrlRegex.test(activeTab.url)) {
          // Scripts já estão injetados via manifest.json, apenas envia a mensagem
          chrome.tabs.sendMessage(activeTab.id, {action: action}, function(response) {
            if (chrome.runtime.lastError) {
              console.error('Erro ao enviar mensagem para content script:', chrome.runtime.lastError.message);
              alert('Erro ao comunicar com a página do SIAGE. Recarregue a página e tente novamente. (Detalhes no console)');
            } else {
              console.log('Mensagem enviada para content script. Resposta:', response);
            }
          });
        } else {
          alert('Esta extensão só funciona em páginas do SIAGE (professor.see.pb.gov.br ou siage.educacao.ba.gov.br).');
        }
      } else {
        console.error('Nenhuma aba ativa encontrada.');
        alert('Nenhuma aba ativa encontrada. Certifique-se de que está em uma página web.');
      }
    });
  }
});
