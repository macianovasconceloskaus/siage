// content-aulas.js - integrado (inject form + loop de registro)
// CORRECOES DE SEGURANCA:
// 1. sessionStorage em vez de localStorage (dados somem ao fechar aba)
// 2. Verificacao de URL antes de cada iteracao (evita envio para turma errada)
// 3. Botao flutuante "Parar Envio" para interromper manualmente
// 4. Cleanup completo ao terminar ou ao parar

// ============================================================================
// CONSTANTES PARA CHAVES DO SESSION STORAGE
// ============================================================================
// BUG 1 FIX: Prefixo 'aulas_' para evitar conflito com frequencias (prefixo 'freq_')
const STORAGE_DADOS = "aulas_registroDados";
const STORAGE_INDEX = "aulas_registroIndex";
const STORAGE_SENHA = "aulas_senhaProfessor";
const STORAGE_URL   = "aulas_urlOrigem";

// ============================================================================
// FLAG GLOBAL PARA CONTROLE DE PARADA DE ENVIO (BUG 3)
// ============================================================================
let ENVIO_PARADO = false; // Flag para parar o envio imediatamente

// ============================================================================
// BOTAO FLUTUANTE "PARAR ENVIO"
// ============================================================================
let botaoPararEnvio = null;

/**
 * Cria e exibe o botao flutuante "Parar Envio" no canto inferior direito.
 * So aparece quando ha um envio em andamento.
 */
function criarBotaoPararEnvio() {
  console.log("[content-aulas] >>> CRIANDO BOTAO PARAR ENVIO <<<");
  // Remove botao anterior se existir
  removerBotaoPararEnvio();

  botaoPararEnvio = document.createElement("div");
  botaoPararEnvio.id = "btn-parar-envio-aulas";
  botaoPararEnvio.innerHTML = `
    <button style="
      background: #dc3545;
      color: #fff;
      border: none;
      border-radius: 8px;
      padding: 12px 20px;
      font-size: 14px;
      font-weight: bold;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(220,53,69,0.4);
      display: flex;
      align-items: center;
      gap: 8px;
      font-family: sans-serif;
    ">
      <span style="font-size: 16px;">&#9632;</span> Parar Envio
    </button>
  `;
  botaoPararEnvio.style.position = "fixed";
  botaoPararEnvio.style.bottom = "20px";
  botaoPararEnvio.style.right = "20px";
  botaoPararEnvio.style.zIndex = "2147483647"; // z-index maximo possivel

  botaoPararEnvio.querySelector("button").addEventListener("click", pararEnvioImediatamente);

  document.body.appendChild(botaoPararEnvio);
  console.log("[content-aulas] Botao 'Parar Envio' exibido.");
}

/**
 * Remove o botao flutuante da tela.
 */
function removerBotaoPararEnvio() {
  const existente = document.getElementById("btn-parar-envio-aulas");
  if (existente) {
    existente.remove();
    console.log("[content-aulas] Botao 'Parar Envio' removido.");
  }
  botaoPararEnvio = null;
}

/**
 * Mostra notificacao toast no estilo glassmorphism
 */
function mostrarToastAulas(mensagem, tipo) {
  const cores = {
    sucesso: { bg: 'rgba(212,237,218,0.95)', cor: '#155724', borda: 'rgba(195,230,203,0.8)' },
    erro:    { bg: 'rgba(248,215,218,0.95)', cor: '#721c24', borda: 'rgba(245,198,203,0.8)' },
    aviso:   { bg: 'rgba(255,243,205,0.95)', cor: '#856404', borda: 'rgba(255,234,167,0.8)' },
    info:    { bg: 'rgba(209,236,241,0.95)', cor: '#0c5460', borda: 'rgba(190,230,239,0.8)' }
  };
  const estilo = cores[tipo] || cores.info;

  const div = document.createElement('div');
  div.style.cssText = `
    position: fixed; top: 20px; right: 20px; z-index: 2147483647;
    background: ${estilo.bg}; backdrop-filter: blur(15px);
    color: ${estilo.cor}; border: 1px solid ${estilo.borda};
    border-radius: 16px; padding: 16px 24px;
    font-family: 'Segoe UI', Arial, sans-serif; font-size: 0.92em; font-weight: 500;
    box-shadow: 0 8px 32px rgba(0,0,0,0.12);
    max-width: 400px; animation: slideInToast 0.3s ease;
  `;
  div.textContent = mensagem;

  const cssAnims = document.createElement('style');
  cssAnims.textContent = `@keyframes slideInToast { from { opacity:0; transform: translateX(100px); } to { opacity:1; transform: translateX(0); } }`;
  div.appendChild(cssAnims);

  document.body.appendChild(div);
  setTimeout(() => div.remove(), 5000);
}

/**
 * Para o envio imediatamente, limpa todos os dados e remove o botao.
 * BUG 3: Agora seta flag global ENVIO_PARADO para interromper loops ativos.
 */
function pararEnvioImediatamente() {
  console.warn("[content-aulas] Envio interrompido pelo usuario via botao 'Parar Envio'.");
  ENVIO_PARADO = true;
  limparTodosOsDados();
  removerBotaoPararEnvio();
  mostrarToastAulas("Envio de aulas interrompido pelo usuario.", "aviso");
  setTimeout(() => { ENVIO_PARADO = false; }, 5000); // Reseta apos 5s para permitir reuso
}

/**
 * Limpa todos os dados do sessionStorage relacionados ao registro de aulas.
 */
function limparTodosOsDados() {
  sessionStorage.removeItem(STORAGE_DADOS);
  sessionStorage.removeItem(STORAGE_INDEX);
  sessionStorage.removeItem(STORAGE_SENHA);
  sessionStorage.removeItem(STORAGE_URL);
  console.log("[content-aulas] Todos os dados do sessionStorage foram limpos.");
}

// ============================================================================
// VERIFICACAO DE CONTEXTO (UUID DA TURMA)
// ============================================================================

/**
 * Extrai o UUID da turma da URL do SIAGE.
 * Ex: /turma/4c53b74c-a749-4b73-951a-483d6251241d/registro-aula
 * @returns {string|null} O UUID da turma ou null se nao encontrar.
 */
function extrairUuidTurma(url) {
  try {
    const match = url.match(/\/turma\/([a-f0-9-]{36})/i);
    return match ? match[1] : null;
  } catch (e) {
    return null;
  }
}

/**
 * Verifica se o professor ainda esta na mesma turma do SIAGE.
 * Compara apenas o UUID da turma na URL - ignora mudancas de subpagina
 * (ex: /registro-aula -> /registro-aula/registrar e a mesma turma).
 * Se o UUID mudou, significa que navegou para outra turma -> interrompe.
 * @returns {boolean} true se mesma turma, false se mudou.
 */
function verificarContextoUrl() {
  const urlOrigem = sessionStorage.getItem(STORAGE_URL);
  if (!urlOrigem) return true; // Sem URL salva = sem envio ativo, permite

  const uuidOrigem = extrairUuidTurma(urlOrigem);
  const uuidAtual  = extrairUuidTurma(window.location.href);

  // Se nao conseguiu extrair UUID de uma das URLs, permite continuar
  if (!uuidOrigem || !uuidAtual) return true;

  // Mesma turma = continua (mesmo UUID)
  if (uuidOrigem === uuidAtual) return true;

  // UUID diferente = professor navegou para outra turma
  console.warn(`[content-aulas] Turma mudou! Origem: ${uuidOrigem} | Atual: ${uuidAtual}`);
  console.warn("[content-aulas] Envio interrompido - voce navegou para outra turma.");
  limparTodosOsDados();
  removerBotaoPararEnvio();
  mostrarToastAulas("Envio interrompido: voce navegou para outra turma.", "erro");
  return false;
}

// ============================================================================
// FORMULARIO DE REGISTRO DE AULAS (POPUP)
// ============================================================================

function abrirFormularioAulas() {
  (async () => {
    const faLinkId = "font-awesome-css";
    if (!document.getElementById(faLinkId)) {
      const link = document.createElement("link");
      link.id = faLinkId;
      link.rel = "stylesheet";
      link.href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css";
      link.crossOrigin = "anonymous";
      link.referrerPolicy = "no-referrer";
      document.head.appendChild(link);
    }

    document.getElementById("registro-aulas-wrapper")?.remove();

    const wrapper = document.createElement("div");
    wrapper.id = "registro-aulas-wrapper";
    wrapper.style.position = "fixed";
    wrapper.style.top = "100px";
    wrapper.style.right = "20px";
    wrapper.style.zIndex = "999999";
    wrapper.style.maxWidth = "100%";
    wrapper.style.maxHeight = "90vh";
    // overflow controlado pelo CSS do wrapper (border-radius + hidden)

    const html = await fetch(chrome.runtime.getURL("form-aulas.html")).then((res) =>
      res.text()
    );
    wrapper.innerHTML = html;

    const cssText = await fetch(chrome.runtime.getURL("form-aulas.css")).then((res) =>
      res.text()
    );
    const style = document.createElement("style");
    style.textContent = cssText;
    wrapper.prepend(style);

    document.body.appendChild(wrapper);

    const popup = document.getElementById("registro-aulas-popup");

    // Torna popup arrastavel
    popup.onmousedown = (e) => {
      if (e.target.tagName === "TEXTAREA" || e.target.tagName === "BUTTON" || e.target.tagName === "INPUT")
        return;

      const shiftX = e.clientX - wrapper.getBoundingClientRect().left;
      const shiftY = e.clientY - wrapper.getBoundingClientRect().top;

      const onMouseMove = (e) => {
        wrapper.style.left = `${e.pageX - shiftX}px`;
        wrapper.style.top = `${e.pageY - shiftY}px`;
        wrapper.style.right = "auto";
      };

      const onMouseUp = () => {
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
      };

      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    };

    /*function atualizarContadores() {
      const dados = JSON.parse(sessionStorage.getItem("registroAulasDados") || "{}");
      const total = Array.isArray(dados.dias) ? dados.dias.length : 0;
      const atual = parseInt(sessionStorage.getItem("registroAulasIndex") || "0", 10);

      document.getElementById("aulas-registradas").textContent = atual;
      document.getElementById("aulas-restantes").textContent = Math.max(total - atual, 0);
    }*/

    document.getElementById("toggle-senha")?.addEventListener("click", () => {
      const senhaInput = document.getElementById("senhaProfessor");
      const iconOlho = document.getElementById("icon-olho");
      if (senhaInput.type === "password") {
        senhaInput.type = "text";
        iconOlho.classList.remove("fa-eye-slash");
        iconOlho.classList.add("fa-eye");
      } else {
        senhaInput.type = "password";
        iconOlho.classList.remove("fa-eye");
        iconOlho.classList.add("fa-eye-slash");
      }
    });

    // Botao colar dados
    document.getElementById("colar-dados")?.addEventListener("click", async () => {
      try {
        const text = await navigator.clipboard.readText();
        if (!text) return console.log("Nenhum texto na area de transferencia!");

        const linhas = text.trim().split(/\r?\n/);
        if (linhas[0].toLowerCase().includes("data")) linhas.shift();

        const mesArr = [];
        const diasArr = [];
        const modoArr = [];
        const tipoArr = [];
        const conteudoArr = [];
        const metodologiaArr = [];
        const observacoesArr = [];

        const nomeMes = (n) => {
          const meses = [
            "Janeiro", "Fevereiro", "Marco", "Abril", "Maio", "Junho",
            "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
          ];
          return meses[n - 1];
        };

        for (const linha of linhas) {
          const colunas = linha.split("\t");
          const dataParts = colunas[0].split("/"); // Ex: 24/03/2025

          const dia = dataParts[0];
          const mes = nomeMes(parseInt(dataParts[1], 10)); // 03 => "Marco"

          mesArr.push(mes);
          diasArr.push(dia);
          modoArr.push(colunas[3] || "");
          tipoArr.push(colunas[4] || "");
          conteudoArr.push(colunas[5] || "");
          metodologiaArr.push(colunas[6] || "");
          observacoesArr.push(colunas[7] || "");
        }

        document.getElementById("mes").value = mesArr.join("\n");
        document.getElementById("dias").value = diasArr.join("\n");
        document.getElementById("modo").value = modoArr.join("\n");
        document.getElementById("tipo").value = tipoArr.join("\n");
        document.getElementById("conteudo").value = conteudoArr.join("\n");
        document.getElementById("metodologia").value = metodologiaArr.join("\n");
        document.getElementById("observacoes").value = observacoesArr.join("\n");

        console.log("Dados colados com sucesso!");
      } catch (err) {
        console.error("Erro ao colar dados:", err.message);
      }
    });

    document.getElementById("limpar-campos")?.addEventListener("click", () => {
      ["mes", "dias", "modo", "tipo", "conteudo", "metodologia", "observacoes", "senhaProfessor"]
        .forEach(id => {
          const el = document.getElementById(id);
          if (el) el.value = "";
        });
      console.log("Campos limpos!");
    });

    document.getElementById("fechar-formulario")?.addEventListener("click", () => {
      wrapper.remove();
    });

    document.getElementById("enviar-dados")?.addEventListener("click", () => {
      const campos = ["mes", "dias", "modo", "tipo", "conteudo", "metodologia", "observacoes"];
      const dados = Object.fromEntries(
        campos.map((id) => [
          id,
          document.getElementById(id).value.trim().split("\n"),
        ])
      );

      const senha = document.getElementById("senhaProfessor").value.trim();

      // Salva dados no sessionStorage (dados somem ao fechar a aba)
      sessionStorage.setItem(STORAGE_DADOS, JSON.stringify(dados));
      sessionStorage.setItem(STORAGE_SENHA, senha);
      sessionStorage.setItem(STORAGE_INDEX, "0");
      // Salva UUID da turma atual para verificar se professor mudou de turma
      sessionStorage.setItem(STORAGE_URL, window.location.href);

      console.log("[content-aulas] Dados, senha e UUID da turma salvos no sessionStorage!");
      console.log(`[content-aulas] Turma atual: ${extrairUuidTurma(window.location.href) || 'N/A'}`);

      // >>> CORRECAO 3: exibe o botao flutuante "Parar Envio" <<<
      criarBotaoPararEnvio();

      chrome.runtime.sendMessage({ acao: "executarContent" });
    });

  })();
}


// ============================================================================
// LOOP E FUNCOES DE REGISTRO
// ============================================================================

let lastUrl = location.href;
new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;

    // >>> CORRECAO 2: verifica se a URL ainda eh a mesma antes de continuar <<<
    // Se nao ha dados no sessionStorage, nao ha nada a fazer
    if (!sessionStorage.getItem(STORAGE_DADOS)) return;

    // Se mudou de turma, a verificacao sera feita dentro das funcoes
    // Aqui apenas prosseguimos se o contexto ainda for valido


    // Se voltou para a lista, executa o proximo registro
    if (
      location.href.includes("/registro-aula") &&
      !location.href.includes("/registro-aula/registrar")
    ) {
      setTimeout(() => {
        iniciarRegistro();
      }, 1000); // Aguarda 1s para garantir que o DOM esta pronto
    }
    // Se esta no formulario, preenche
    if (location.href.includes("/registro-aula/registrar")) {
      preencherFormulario();
    }
  }
}).observe(document, { subtree: true, childList: true });

async function waitForElement(selector, timeout = 5000, interval = 500) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const el = document.querySelector(selector);
    if (el) return el;
    await new Promise((r) => setTimeout(r, interval));
  }
  return null;
}

async function waitForElementToDisappear(
  selector,
  timeout = 5000,
  interval = 500
) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const el = document.querySelector(selector);
    const visible = el && el.offsetParent !== null;
    if (!el || !visible) return true;
    await new Promise((res) => setTimeout(res, interval));
  }
  console.warn(`Elemento '${selector}' nao desapareceu apos ${timeout}ms.`);
  return false;
}

function atualizarContadores() {
  // >>> CORRECAO 1: sessionStorage em vez de localStorage <<<
  const dados = JSON.parse(sessionStorage.getItem(STORAGE_DADOS) || "{}");
  const total = Array.isArray(dados.dias) ? dados.dias.length : 0;
  const atual = parseInt(sessionStorage.getItem(STORAGE_INDEX) || "0", 10);

  const aulasRegistradas = document.getElementById("aulas-registradas");
  const aulasRestantes = document.getElementById("aulas-restantes");

  if (aulasRegistradas) aulasRegistradas.textContent = atual;
  if (aulasRestantes) aulasRestantes.textContent = Math.max(total - atual, 0);
}


async function iniciarRegistro() {
  // BUG 3: Verifica se o envio foi interrompido pelo usuario
  if (ENVIO_PARADO) {
    console.log("[content-aulas] Envio esta parado. Ignorando chamada.");
    return;
  }

  const delay = (ms) => new Promise((res) => setTimeout(res, ms));

  // Verifica se professor ainda esta na mesma turma
  if (!verificarContextoUrl()) return;

  const dados = JSON.parse(sessionStorage.getItem(STORAGE_DADOS) || "{}");
  const senha = sessionStorage.getItem(STORAGE_SENHA);

  if (!dados || !senha) {
    console.warn("[content-aulas] Dados ou senha nao encontrados no sessionStorage.");
    return;
  }

  // Garante que o botao flutuante esteja visivel
  criarBotaoPararEnvio();

  // Verifica novamente antes de comecar o loop
  if (!verificarContextoUrl()) return;

  let indexAtual = parseInt(sessionStorage.getItem(STORAGE_INDEX) || "0", 10);
  const dias = dados.dias || [];

  if (indexAtual >= dias.length) {
    console.log("[content-aulas] Todas as aulas foram registradas com sucesso!");
    mostrarToastAulas("Registro de aulas finalizado! Todas as aulas foram enviadas.", "sucesso");
    limparTodosOsDados();
    removerBotaoPararEnvio();

    // ============================================================
    // AUTO-FREQUENCIA: Navega automaticamente para pagina de frequencia
    // ============================================================
    const uuidTurma = extrairUuidTurma(window.location.href);
    if (uuidTurma) {
      const urlFrequencia = `https://professor.see.pb.gov.br/diario/minhas-turmas/listagem-turmas/turma/${uuidTurma}/frequencia/cadastrar`;
      console.log(`[content-aulas] Navegando automaticamente para frequencia: ${urlFrequencia}`);
      mostrarToastAulas("Aulas concluidas! Navegando para Frequencia...", "info");
      setTimeout(() => {
        window.location.href = urlFrequencia;
      }, 3000);
    }
    return;
  }

  const url = window.location.href;
  const paginaLista =
    url.includes("/registro-aula") && !url.includes("/registro-aula/registrar");

  if (paginaLista) {
    // 1. Clicar no botao Registrar Aula
    const botaoRegistrarAula = document.querySelector("button.btn.btn-primary-dark");
    if (!botaoRegistrarAula) {
      console.warn("Botao 'Registrar Aula' nao encontrado.");
      return;
    }
    console.log("Clicando no botao 'Registrar Aula' para abrir o modal...");
    botaoRegistrarAula.click();

    // 2. Aguardar modal aparecer
    const modal = await waitForElement(".modal-content");
    if (!modal) {
      console.warn("Modal de selecao mes/dia nao apareceu.");
      return;
    }
    console.log("Modal apareceu.");

    // 2.1 Esperar o loading sumir
    await waitForElementToDisappear("app-loading-custom, ngx-loading");
    console.log("Loading finalizado.");

    // >>> CORRECAO 2: verifica URL entre etapas <<<


    // 3. Selecionar mes no autocomplete PrimeNG (BUG 3 FIX: metodo robusto com dropdown)
    await delay(500);
    const inputMes = modal.querySelector("input[placeholder='Selecione']");
    if (!inputMes) {
      console.warn("Input mes nao encontrado.");
      return;
    }

    const mesAlvo = dados.mes[indexAtual].toLowerCase();
    console.log(`[content-aulas] Selecionando mes: ${mesAlvo}`);

    // Metodo 1: Clicar no icone do dropdown e selecionar da lista
    let mesSelecionado = false;

    // Tenta clicar no icone dropdown (pi-caret-down)
    const dropdownIcon = modal.querySelector(".pi-caret-down") ||
                         modal.querySelector("[class*='dropdown']") ||
                         inputMes.parentElement.querySelector("button") ||
                         inputMes.parentElement.querySelector("[class*='caret']");

    if (dropdownIcon) {
      dropdownIcon.click();
      await delay(800);

      // Procura a opcao do mes na lista aberta
      const opcoes = Array.from(modal.querySelectorAll("li[role='option'], .ui-autocomplete-list-item, .p-autocomplete-item, li"));
      const opcaoMes = opcoes.find(li => {
        const text = (li.innerText || li.textContent || '').trim().toLowerCase();
        return text === mesAlvo;
      });

      if (opcaoMes) {
        opcaoMes.click();
        console.log(`Mes selecionado via dropdown: ${mesAlvo}`);
        mesSelecionado = true;
      }
    }

    // Metodo 2 (fallback): Digitar e usar keyboard
    if (!mesSelecionado) {
      inputMes.focus();
      inputMes.value = "";
      inputMes.dispatchEvent(new Event("input", { bubbles: true }));
      await delay(500);

      for (const char of mesAlvo) {
        inputMes.value += char;
        inputMes.dispatchEvent(new Event("input", { bubbles: true }));
        await delay(100);
      }
      await delay(500);

      inputMes.dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowDown", bubbles: true }));
      await delay(300);
      inputMes.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
      console.log(`Mes selecionado via keyboard: ${mesAlvo}`);
    }

    // 5. Esperar o calendario carregar dias
    await waitForElementToDisappear("app-loading-custom, ngx-loading");
    console.log("Segundo loading finalizado.");

    // >>> CORRECAO 2: verifica URL entre etapas <<<


    // Aguardar extra para garantir DOM atualizado (opcional)
    await waitForElement("#input-password");

    // 6. Selecionar o dia (BUG 2: melhorado com multiplos seletores e logica robusta)
    await delay(1000); // Aguarda calendario renderizar
    const diaAlvo = dados.dias[indexAtual].padStart(2, "0");
    console.log(`[content-aulas] Procurando dia: ${diaAlvo}`);

    // Tenta encontrar o dia no calendario (varios seletores possiveis)
    const diaSeletores = [
      `.calendario-dia:not(.registrado)`, // dias nao registrados
      `.calendario-dia`,
      `[class*="calendario-dia"]`,
    ];

    let diaDiv = null;
    for (const sel of diaSeletores) {
      const diasEl = Array.from(modal.querySelectorAll(sel));
      diaDiv = diasEl.find(div => {
        const text = div.innerText || div.textContent || '';
        return text.trim().padStart(2, '0') === diaAlvo;
      });
      if (diaDiv) break;
    }

    if (!diaDiv) {
      console.warn(`Dia '${diaAlvo}' nao encontrado no calendario.`);
      return;
    }

    // Clique com seguranca
    const evt = new MouseEvent("click", { bubbles: true, cancelable: true });
    diaDiv.dispatchEvent(evt);
    console.log(`Dia selecionado: ${diaAlvo}`);

    await delay(500);

    // 8. Clicar no botao "Registrar" dentro do modal
    // BUG 2 FIX: Usa Array.find em vez de seletor jQuery :contains() invalido no querySelector nativo
    const botaoRegistrar =
      modal.querySelector("button.btn.btn-primary") ||
      Array.from(modal.querySelectorAll("button")).find(btn =>
        btn.textContent.trim().includes("Registrar")
      );
    if (!botaoRegistrar) {
      console.warn("Botao 'Registrar' nao encontrado no modal.");
      return;
    }

    botaoRegistrar.click();
    console.log("Clicado no botao 'Registrar' para abrir o formulario.");
  }
}

// Chama iniciarRegistro ao carregar a pagina
iniciarRegistro();

// ============================================================================
// FUNCAO PARA PREENCHER O FORMULARIO
// ============================================================================

async function preencherFormulario() {
  // BUG 3: Verifica se o envio foi interrompido pelo usuario
  if (ENVIO_PARADO) {
    console.log("[content-aulas] Envio parado. Abortando preenchimento.");
    return;
  }

  console.log("Preenchendo formulario...");
  const delay = (ms) => new Promise((res) => setTimeout(res, ms));

  // Verifica se professor ainda esta na mesma turma
  if (!verificarContextoUrl()) return;

  const dados = JSON.parse(sessionStorage.getItem(STORAGE_DADOS) || "{}");
  const senha = sessionStorage.getItem(STORAGE_SENHA);
  let indexAtual = parseInt(sessionStorage.getItem(STORAGE_INDEX) || "0", 10);

  console.log(dados, senha, indexAtual);

  if (!dados || !senha || indexAtual >= (dados.dias || []).length) {
    console.warn("[content-aulas] Dados insuficientes para preenchimento.");
    return;
  }

  // Garante que o botao flutuante esteja visivel
  criarBotaoPararEnvio();

  // Aguarde o campo do periodo aparecer
  /*const periodoInput = await waitForElement(
    "#autocomplete-periodo input[placeholder='Selecione']",
    10000
  );
  if (periodoInput) {
    periodoInput.focus();
    periodoInput.value = dados.periodo[indexAtual] || "";
    periodoInput.dispatchEvent(new Event("input", { bubbles: true }));
    await delay(500);
    periodoInput.dispatchEvent(
      new KeyboardEvent("keydown", { key: "ArrowDown" })
    );
    periodoInput.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter" }));
    console.log("Periodo preenchido.");
  }*/

  // Modo de Aula (radio)
  const modoAula = (dados.modoAula?.[indexAtual] || "").toUpperCase();
  console.log(`Modo de Aula: ${modoAula}`);
  const modoRadio = document.querySelector(`#option-${modoAula}`);
  if (modoRadio) {
    modoRadio.click();
    console.log(`Modo de Aula selecionado: ${modoAula}`);
    await delay(800); // Delay visual para usuario ver
  }
  // Tipo de Aula (radio)
  const tipoAula = (dados.tipoAula?.[indexAtual] || "AVULSO")
    .toUpperCase()
    .replaceAll(" ", "_");
  console.log(`Tipo de Aula: ${tipoAula}`);

  // Busca todos os labels de tipo de aula
  const labelsTipoAula = Array.from(
    document.querySelectorAll("label[for^='option-']")
  );

  const labelTipoAula = labelsTipoAula.find(
    (label) =>
      label.textContent.trim().toLowerCase() ===
      (dados.tipoAula?.[indexAtual] || "Avulso").trim().toLowerCase()
  );

  if (labelTipoAula) {
    labelTipoAula.click();
    console.log(
      `Tipo de Aula selecionado: ${labelTipoAula.textContent.trim()}`
    );
    await delay(800); // Delay visual para usuario ver
  } else {
    console.warn(
      `Label para tipo de aula '${dados.tipoAula[indexAtual]}' nao encontrado.`
    );
  }

  // Se tipo AVULSO, preencher campos adicionais
  if (tipoAula === "AVULSO") {
    // Objetos de Conhecimento
    const objetosInput = await waitForElement("#textarea-objetosConhecimento");
    if (objetosInput) {
      objetosInput.value = dados.conteudo?.[indexAtual] || "";
      objetosInput.dispatchEvent(new Event("input", { bubbles: true }));
      console.log("Objetos de Conhecimento preenchidos.");
      await delay(500); // Delay visual
    }

    // Metodologia
    const metodologiaInput = await waitForElement("#metodologia input[placeholder='Selecione']", 10000);
    if (metodologiaInput) {
      metodologiaInput.focus();
      metodologiaInput.value = dados.metodologia?.[indexAtual] || "";
      metodologiaInput.dispatchEvent(new Event("input", { bubbles: true }));
      await delay(500);

      // Aguarda o dropdown de opcoes aparecer
      const listaId = metodologiaInput.getAttribute("aria-controls");
      const listaSelector = `#${listaId}`;
      const lista = await waitForElement(listaSelector, 5000);

      if (lista) {
        // Busca a opcao correta pelo texto
        const textoMetodologia = (dados.metodologia?.[indexAtual] || "").trim().toLowerCase();
        const opcoes = Array.from(lista.querySelectorAll("li"));
        const opcao = opcoes.find(li =>
          li.textContent.trim().toLowerCase() === textoMetodologia
        );
        if (opcao) {
          opcao.click();
          console.log("Metodologia selecionada e chip adicionado.");
        } else {
          console.warn("Opcao de metodologia nao encontrada no dropdown.");
        }
      } else {
        console.warn("Dropdown de metodologia nao apareceu.");
      }
    }

    const obsInput = document.querySelector("#observacoes");
    if (obsInput) {
      obsInput.value = dados.observacoes?.[indexAtual] || "";
      obsInput.dispatchEvent(new Event("input", { bubbles: true }));
      console.log("Observacoes preenchidas.");
    }
  }

  // Verifica se professor ainda esta na mesma turma antes de salvar
  if (!verificarContextoUrl()) return;

  // Botao salvar
  const botaoSalvar = document.querySelector("#btn-submit");
  if (botaoSalvar) {
    botaoSalvar.click();
    console.log("Formulario enviado!");
    await delay(800); // Aguarde o modal de senha aparecer
  }

  // Aguarda o modal de senha aparecer
  const senhaModalInput = await waitForElement("#input-password");
  if (senhaModalInput) {
    senhaModalInput.value = senha;
    senhaModalInput.dispatchEvent(new Event("input", { bubbles: true }));
    console.log("Senha do modal preenchida.");

    // Aguarda o botao "Confirmar" aparecer e clica
    const botoesConfirmar = Array.from(document.querySelectorAll("button.btn-primary"));
    const botaoConfirmar = botoesConfirmar.find(btn =>
      btn.textContent.replace(/\s/g, "").toLowerCase().includes("confirmar")
    );

    if (botaoConfirmar) {
      botaoConfirmar.click();
      console.log("Botao Confirmar clicado.");
    } else {
      console.warn("Botao Confirmar nao encontrado.");
    }
  }

  indexAtual++;
  console.log("indexAtual: ", indexAtual);

  // >>> CORRECAO 1: sessionStorage em vez de localStorage <<<
  sessionStorage.setItem(STORAGE_INDEX, indexAtual.toString());
  atualizarContadores();

  // BUG 1 + 4: se era a ultima aula, limpa tudo; senao, continua para a proxima aula
  const totalAulas = Array.isArray(dados.dias) ? dados.dias.length : 0;
  if (indexAtual >= totalAulas) {
    // Ultima aula - limpa tudo e fecha o popup
    console.log("[content-aulas] Ultima aula processada. Limpando dados...");
    setTimeout(() => {
      limparTodosOsDados();
      removerBotaoPararEnvio();
      // BUG 4: Fecha o popup do formulario
      document.getElementById("registro-aulas-wrapper")?.remove();
      mostrarToastAulas("Registro de aulas concluido! Todas as aulas foram enviadas.", "sucesso");
    }, 2000); // Aguarda 2s para garantir que o salvamento foi processado
  } else {
    // Ainda tem aulas - inicia proxima apos delay (BUG 1: continuacao do fluxo)
    console.log(`[content-aulas] Aula ${indexAtual}/${totalAulas} concluida. Iniciando proxima em 3s...`);
    setTimeout(() => {
      if (!window.ENVIO_PARADO) {
        iniciarRegistro();
      }
    }, 3000);
  }
}


// ============================================================================
// EXPOSE FUNCTIONS PARA EXECUCAO PELO BACKGROUND
// ============================================================================
// ============================================================
// DETECTOR SWEETALERT2: Auto-clica "Sim" em "Aula ja registrada"
// ============================================================

const swalObserverAulas = new MutationObserver(() => {
  const swalPopup = document.querySelector('.swal2-popup.swal2-icon-warning, .swal2-popup');
  if (!swalPopup || swalPopup.style.display === 'none') return;

  const content = swalPopup.querySelector('.swal2-html-container')?.textContent || '';

  // Detecta modal de "aula ja registrada"
  if (content.includes('Ja foi realizado um cadastro') &&
      content.includes('Deseja realizar um novo registro')) {
    console.log('[content-aulas] Modal "Aula ja registrada" detectado. Clicando Sim...');
    const btnSim = swalPopup.querySelector('.swal2-confirm');
    if (btnSim) {
      setTimeout(() => {
        btnSim.click();
        console.log('[content-aulas] Clicado "Sim" no modal de aula ja registrada.');
      }, 800);
    }
  }
});
swalObserverAulas.observe(document.body, { childList: true, subtree: true });
console.log('[content-aulas] Detector SweetAlert2 ativado.');

if (typeof window !== 'undefined') {
  window.iniciarRegistro = typeof iniciarRegistro === 'function' ? iniciarRegistro : (function(){console.warn('iniciarRegistro nao esta definido');});
  window.abrirFormularioAulas = abrirFormularioAulas;
  window.pararEnvioImediatamente = pararEnvioImediatamente; // >>> CORRECAO 3: expoe a funcao de parar <<<
}

console.log('[content-aulas] Modulo carregado (com correcoes de seguranca v2).');
