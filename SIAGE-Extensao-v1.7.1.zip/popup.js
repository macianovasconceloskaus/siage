// popup.js - v1.7 Com integracao ao Painel Web via API Key

document.addEventListener('DOMContentLoaded', function() {

  // ============================================================
  // NAVEGACAO POR ABAS
  // ============================================================
  const tabs = document.querySelectorAll('.tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('ativa'));
      tab.classList.add('ativa');
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('ativa'));
      document.getElementById('tab-' + tab.dataset.tab).classList.add('ativa');
    });
  });

  // ============================================================
  // BOTOES DE ACAO (Aulas, Notas, Frequencia)
  // ============================================================
  document.getElementById('abrirAulas').addEventListener('click', () => {
    sendMessageToContentScript('openAulasForm');
  });

  document.getElementById('abrirNotas').addEventListener('click', () => {
    sendMessageToContentScript('openNotasForm');
  });

  document.getElementById('abrirFrequencia').addEventListener('click', () => {
    sendMessageToContentScript('openFrequenciaForm');
  });

  function sendMessageToContentScript(action) {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      const activeTab = tabs[0];
      if (!activeTab) {
        alert('Nenhuma aba ativa encontrada.');
        return;
      }

      const siageUrlRegex = /^(https?:\/\/(professor\.see\.pb\.gov\.br|.*\.siage\.educacao\.ba\.gov\.br))(\/.*)?$/;
      if (!siageUrlRegex.test(activeTab.url)) {
        alert('Esta extensao funciona apenas em paginas do SIAGE (professor.see.pb.gov.br ou siage.educacao.ba.gov.br).\n\nVoce esta em: ' + activeTab.url);
        return;
      }

      chrome.tabs.sendMessage(activeTab.id, {action: action}, function(response) {
        if (chrome.runtime.lastError) {
          console.error('[POPUP] Erro:', chrome.runtime.lastError.message);
          alert('Erro ao comunicar com a pagina do SIAGE.\n\nSolucao:\n1. Recarregue a pagina do SIAGE (F5)\n2. Tente novamente\n\nErro: ' + chrome.runtime.lastError.message);
        } else {
          console.log('[POPUP] Mensagem entregue com sucesso:', response);
        }
        // Fecha o popup APOS processar a resposta
        window.close();
      });
    });
  }

  // ============================================================
  // CONFIGURACAO - Carregar valores salvos
  // ============================================================
  const inputUrl = document.getElementById('painelUrl');
  const inputApiKey = document.getElementById('apiKey');
  const statusDiv = document.getElementById('statusMsg');
  const configStatusDiv = document.getElementById('configStatus');

  // Carregar configuracao salva
  chrome.storage.local.get(['siagePainelUrl', 'siageApiKey'], function(result) {
    if (result.siagePainelUrl) {
      inputUrl.value = result.siagePainelUrl;
    }
    if (result.siageApiKey) {
      inputApiKey.value = result.siageApiKey;
      mostrarStatusConfiguracao(true);
    } else {
      mostrarStatusConfiguracao(false);
    }
  });

  function mostrarStatusConfiguracao(configurado) {
    if (configurado) {
      configStatusDiv.innerHTML = `
        <div class="config-ok">
          <span class="icon">&#9989;</span>
          <span><strong>Painel configurado!</strong><br>A extensao pode buscar dados automaticamente.</span>
        </div>`;
    } else {
      configStatusDiv.innerHTML = `
        <div class="status-msg info" style="display:block; margin-bottom:12px;">
          &#9888; <strong>Configure o painel</strong> para buscar aulas automaticamente.
        </div>`;
    }
  }

  function mostrarStatus(mensagem, tipo) {
    statusDiv.textContent = mensagem;
    statusDiv.className = 'status-msg ' + tipo;
  }

  // ============================================================
  // BOTAO TESTAR CONEXAO
  // ============================================================
  document.getElementById('btnTestar').addEventListener('click', async () => {
    const url = inputUrl.value.trim().replace(/\/$/, '');
    const apiKey = inputApiKey.value.trim();

    if (!url) { mostrarStatus('Informe a URL do painel.', 'erro'); return; }
    if (!apiKey) { mostrarStatus('Informe a API Key.', 'erro'); return; }

    mostrarStatus('Testando conexao...', 'info');

    try {
      const response = await fetch(url + '/api/aulas.php', {
        method: 'GET',
        headers: {
          'X-API-Key': apiKey,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
          mostrarStatus('API Key invalida. Verifique no painel web.', 'erro');
        } else {
          mostrarStatus('Erro ' + response.status + ' no servidor.', 'erro');
        }
        return;
      }

      const data = await response.json();
      if (data.status === 'ok') {
        mostrarStatus(
          'Conexao OK! Usuario: ' + (data.usuario || 'Desconhecido') +
          ' | Aulas: ' + (data.total || 0),
          'ok'
        );
      } else if (data.erro) {
        mostrarStatus('Erro: ' + data.erro, 'erro');
      } else {
        mostrarStatus('Resposta inesperada do servidor.', 'erro');
      }
    } catch (err) {
      console.error('[POPUP] Erro ao testar conexao:', err);
      mostrarStatus(
        'Falha na conexao. Verifique a URL e sua internet.',
        'erro'
      );
    }
  });

  // ============================================================
  // BOTAO SALVAR CONFIGURACAO
  // ============================================================
  document.getElementById('btnSalvarConfig').addEventListener('click', () => {
    const url = inputUrl.value.trim().replace(/\/$/, '');
    const apiKey = inputApiKey.value.trim();

    if (!url) { mostrarStatus('Informe a URL do painel.', 'erro'); return; }
    if (!apiKey) { mostrarStatus('Informe a API Key.', 'erro'); return; }

    chrome.storage.local.set({
      siagePainelUrl: url,
      siageApiKey: apiKey
    }, function() {
      mostrarStatus('Configuracao salva com sucesso!', 'ok');
      mostrarStatusConfiguracao(true);
      console.log('[POPUP] Configuracao salva - URL:', url);
    });
  });

});
