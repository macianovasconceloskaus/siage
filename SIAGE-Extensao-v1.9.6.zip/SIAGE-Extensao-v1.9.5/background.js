
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.acao === "executarContent") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0]?.id;
      if (tabId) {
        // Execute a small snippet in the page context to call window.iniciarRegistro()
        chrome.scripting.executeScript({
          target: { tabId: tabId },
          func: () => {
            try {
              if (window.iniciarRegistro && typeof window.iniciarRegistro === 'function') {
                window.iniciarRegistro();
              } else {
                console.warn('iniciarRegistro não encontrado no contexto da página.');
              }
            } catch (e) {
              console.error('Erro ao chamar iniciarRegistro:', e);
            }
          }
        });
      }
    });
  }
});
