// content-executar-tudo.js - Orquestrador da funcionalidade "Executar Tudo"
// Integra os modulos de Aulas e Frequencia em um unico fluxo automatico:
// 1. Registra todas as aulas -> 2. Navega para frequencia -> 3. Registra todas as frequencias
//
// CORRECOES DE SEGURANCA:
// - sessionStorage em vez de localStorage (dados somem ao fechar a aba)
// - Verificacao de URL antes de cada iteracao (evita envio para turma errada)
// - Botao flutuante "Parar Tudo" para interromper manualmente
// - Cleanup completo ao terminar ou ao parar

// ============================================================================
// CONSTANTES PARA CHAVES DO SESSION STORAGE (AULAS)
// ============================================================================
const AULAS_STORAGE_DADOS = "aulas_registroDados";
const AULAS_STORAGE_INDEX = "aulas_registroIndex";
const AULAS_STORAGE_SENHA = "aulas_senhaProfessor";
const AULAS_STORAGE_URL   = "aulas_urlOrigem";

// ============================================================================
// CONSTANTES PARA CHAVES DO SESSION STORAGE (FREQUENCIA)
// ============================================================================
const FREQ_STORAGE_DADOS = "freq_registroDados";
const FREQ_STORAGE_INDEX = "freq_registroIndex";
const FREQ_STORAGE_SENHA = "freq_senhaProfessor";
const FREQ_STORAGE_ERROS = "freq_registroErros";
const FREQ_STORAGE_ERROS_CONSEC = "freq_errosConsecutivos";

// ============================================================================
// VARIAVEIS GLOBAIS DE CONTROLE
// ============================================================================
let isUIExecutarTudoOpen = false;
let ENVIO_PARADO_TUDO = false;          // Flag para parar tudo imediatamente
let botaoPararTudo = null;              // Referencia ao botao flutuante
let observadorProgresso = null;         // ID do setInterval de progresso
let wrapperExecutarTudo = null;         // Referencia ao wrapper do formulario

// ============================================================================
// UTILITARIOS
// ============================================================================

/**
 * Extrai o UUID da turma da URL do SIAGE.
 * Ex: /turma/4c53b74c-a749-4b73-951a-483d6251241d/registro-aula
 */
function extrairUuidTurma(url) {
  try {
    const match = url.match(/\/turma\/([a-f0-9-]{36})/i);
    return match ? match[1] : null;
  } catch (e) {
    return null;
  }
}

// ============================================================================
// TOAST DE NOTIFICACOES
// ============================================================================

/**
 * Mostra notificacao toast no estilo glassmorphism
 */
function mostrarToastTudo(mensagem, tipo) {
  const cores = {
    sucesso: { bg: 'rgba(212,237,218,0.95)', cor: '#155724', borda: 'rgba(195,230,203,0.8)' },
    erro:    { bg: 'rgba(248,215,218,0.95)', cor: '#721c24', borda: 'rgba(245,198,203,0.8)' },
    aviso:   { bg: 'rgba(255,243,205,0.95)', cor: '#856404', borda: 'rgba(255,234,167,0.8)' },
    info:    { bg: 'rgba(209,236,241,0.95)', cor: '#0c5460', borda: 'rgba(190,230,239,0.8)' }
  };
  const estilo = cores[tipo] || cores.info;

  const div = document.createElement('div');
  div.style.cssText = `
    position: fixed; top: 20px; right: 20px; z-index: 2147483647;
    background: ${estilo.bg}; backdrop-filter: blur(15px);
    color: ${estilo.cor}; border: 1px solid ${estilo.borda};
    border-radius: 16px; padding: 16px 24px;
    font-family: 'Segoe UI', Arial, sans-serif; font-size: 0.92em; font-weight: 500;
    box-shadow: 0 8px 32px rgba(0,0,0,0.12);
    max-width: 400px; animation: slideInToastTudo 0.3s ease;
  `;
  div.textContent = mensagem;

  const cssAnims = document.createElement('style');
  cssAnims.textContent = `@keyframes slideInToastTudo { from { opacity:0; transform: translateX(100px); } to { opacity:1; transform: translateX(0); } }`;
  div.appendChild(cssAnims);

  document.body.appendChild(div);
  setTimeout(() => div.remove(), 5000);
}

// ============================================================================
// BOTAO FLUTUANTE "PARAR TUDO"
// ============================================================================

/**
 * NAO cria botao proprio - usa o botao "Parar Envio" do content-aulas.js.
 * A flag ENVIO_PARADO do content-aulas.js ja para tanto aulas quanto frequencias.
 */
function criarBotaoPararTudo() {
  console.log("[EXECUTAR-TUDO] Usando botao 'Parar Envio' do content-aulas.js. Nenhum botao adicional criado.");
  // NAO cria botao - o content-aulas.js ja cria o btn-parar-envio-aulas
}

/**
 * Remove o botao flutuante da tela.
 */
function removerBotaoPararTudo() {
  const existente = document.getElementById("btn-parar-tudo");
  if (existente) {
    existente.remove();
    console.log("[EXECUTAR-TUDO] Botao 'Parar Tudo' removido.");
  }
  botaoPararTudo = null;
}

/**
 * Para TUDO imediatamente: aulas e frequencias.
 * Limpa todos os dados do sessionStorage e remove o botao.
 */
function pararTudoImediatamente() {
  console.warn("[EXECUTAR-TUDO] >>> EXECUCAO TOTAL INTERROMPIDA PELO USUARIO <<<");
  ENVIO_PARADO_TUDO = true;

  // Limpa sessionStorage de aulas
  sessionStorage.removeItem(AULAS_STORAGE_DADOS);
  sessionStorage.removeItem(AULAS_STORAGE_INDEX);
  sessionStorage.removeItem(AULAS_STORAGE_SENHA);
  sessionStorage.removeItem(AULAS_STORAGE_URL);

  // Limpa sessionStorage de frequencia
  sessionStorage.removeItem(FREQ_STORAGE_DADOS);
  sessionStorage.removeItem(FREQ_STORAGE_INDEX);
  sessionStorage.removeItem(FREQ_STORAGE_SENHA);
  sessionStorage.removeItem(FREQ_STORAGE_ERROS);
  sessionStorage.removeItem(FREQ_STORAGE_ERROS_CONSEC);

  // Para o observador de progresso
  if (observadorProgresso) {
    clearInterval(observadorProgresso);
    observadorProgresso = null;
  }

  removerBotaoPararTudo();
  mostrarToastTudo("Execucao interrompida. Todos os dados foram limpos.", "aviso");

  // Reseta a flag apos 5s para permitir reuso
  setTimeout(() => { ENVIO_PARADO_TUDO = false; }, 5000);
}

// ============================================================================
// ABERTURA DO FORMULARIO UNIFICADO
// ============================================================================

/**
 * Abre o formulario unificado "Executar Tudo" que integra aulas e frequencias.
 * Injeta o HTML e CSS, torna arrastavel e liga todos os event listeners.
 */
window.abrirFormularioExecutarTudo = function() {
  console.log("[EXECUTAR-TUDO] Abrindo formulario unificado...");

  // Injeta Font Awesome se ainda nao existir
  const faLinkId = "font-awesome-css-executar-tudo";
  if (!document.getElementById(faLinkId)) {
    const link = document.createElement("link");
    link.id = faLinkId;
    link.rel = "stylesheet";
    link.href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css";
    link.crossOrigin = "anonymous";
    link.referrerPolicy = "no-referrer";
    document.head.appendChild(link);
  }

  // Remove wrapper anterior se existir
  document.getElementById("executar-tudo-wrapper")?.remove();

  wrapperExecutarTudo = document.createElement("div");
  wrapperExecutarTudo.id = "executar-tudo-wrapper";
  wrapperExecutarTudo.style.cssText = `
    position: fixed; top: 60px; right: 20px; z-index: 999999;
    max-width: 100%; max-height: 95vh;
  `;

  Promise.all([
    fetch(chrome.runtime.getURL("form-executar-tudo.html")).then(r => r.text()),
    fetch(chrome.runtime.getURL("form-executar-tudo.css")).then(r => r.text())
  ]).then(([html, css]) => {
    const style = document.createElement("style");
    style.textContent = css;
    wrapperExecutarTudo.prepend(style);
    wrapperExecutarTudo.innerHTML += html;
    document.body.appendChild(wrapperExecutarTudo);

    inicializarEventosExecutarTudo();
    isUIExecutarTudoOpen = true;
    console.log("[EXECUTAR-TUDO] Formulario aberto com sucesso.");
  }).catch(err => {
    console.error("[EXECUTAR-TUDO] Erro ao carregar formulario:", err);
    mostrarToastTudo("Erro ao carregar formulario. Verifique os arquivos da extensao.", "erro");
  });
};

// ============================================================================
// EVENTOS DO FORMULARIO
// ============================================================================

function inicializarEventosExecutarTudo() {
  const wrapper = document.getElementById("executar-tudo-wrapper");
  if (!wrapper) return;

  const popup = document.getElementById("executar-tudo-popup");

  // --- Arrastavel ---
  if (popup) {
    popup.onmousedown = (e) => {
      if (['TEXTAREA','INPUT','BUTTON','I','SELECT'].includes(e.target.tagName)) return;
      if (e.target.closest('button')) return;
      const shiftX = e.clientX - wrapper.getBoundingClientRect().left;
      const shiftY = e.clientY - wrapper.getBoundingClientRect().top;
      const onMove = (ev) => {
        wrapper.style.left = `${ev.pageX - shiftX}px`;
        wrapper.style.top = `${ev.pageY - shiftY}px`;
        wrapper.style.right = "auto";
      };
      const onUp = () => {
        document.removeEventListener("mousemove", onMove);
        document.removeEventListener("mouseup", onUp);
      };
      document.addEventListener("mousemove", onMove);
      document.addEventListener("mouseup", onUp);
    };
  }

  // --- Colar Dados do Painel (1 clique = aulas + frequencias) ---
  document.getElementById("colar-clipboard-tudo")?.addEventListener("click", async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (!text || !text.trim()) {
        mostrarFeedbackColar("Nada copiado. Va no Painel Web, clique \"Copiar Tudo\" e depois volte aqui.", "erro");
        return;
      }

      // ===== MODO TUDO: detecta marcador ---SIAGE-FREQ--- (1 clique so) =====
      const marcador = "---SIAGE-FREQ---";
      if (text.includes(marcador)) {
        const partes = text.split(marcador);
        const linhasAulas = partes[0].trim().split(/\r?\n/).filter(l => l.trim());
        const linhasFreq = partes[1].trim().split(/\r?\n/).filter(l => l.trim());

        const okAulas = colarAulasPainel(linhasAulas);
        const okFreq = colarFrequenciasPainel(linhasFreq);

        if (okAulas && okFreq) {
          mostrarFeedbackColar("&#9989; " + okAulas + " aulas e " + okFreq + " frequencias coladas! Digite a senha e clique EXECUTAR TUDO.", "aulas");
          mostrarToastTudo(okAulas + " aulas + " + okFreq + " frequencias prontos!", "sucesso");
        }
        return;
      }

      // ===== MODO SEPARADO: detecta pelo numero de colunas (fallback) =====
      const linhas = text.trim().split(/\r?\n/).filter(l => l.trim());
      if (linhas.length === 0) { mostrarFeedbackColar("Dados vazios.", "erro"); return; }

      let primeiraLinha = linhas[0];
      if (primeiraLinha.toLowerCase().includes("data")) primeiraLinha = linhas[1] || "";
      const numColunas = primeiraLinha.split("\t").length;
      console.log(`[EXECUTAR-TUDO] Colar: ${numColunas} colunas, ${linhas.length} linhas`);

      // AULAS: 6+ colunas
      if (numColunas >= 6) {
        const ok = colarAulasPainel(linhas);
        if (ok) mostrarFeedbackColar("&#9989; " + ok + " aulas coladas! Agora copie as FREQUENCIAS do painel e clique de novo.", "aulas");
        return;
      }

      // FREQUENCIAS: 2-3 colunas
      if (numColunas >= 2 && numColunas <= 3) {
        const col2 = (primeiraLinha.split("\t")[1] || "").trim();
        if (/[a-zA-Z\u00C0-\u00FF]/.test(col2)) {
          mostrarFeedbackColar("&#10071; Voce copiou os DADOS DE AULAS. Va no painel e clique \"Copiar Frequencias\".", "erro");
          return;
        }
        const ok = colarFrequenciasPainel(linhas);
        if (ok) mostrarFeedbackColar("&#9989; " + ok + " frequencias coladas! Verifique os tempos.", "freq");
        return;
      }

      mostrarFeedbackColar("Formato nao reconhecido. Use \"Copiar Tudo\" no painel (modo rapido).", "erro");
    } catch (err) {
      console.error("[EXECUTAR-TUDO] Erro ao colar:", err);
      mostrarFeedbackColar("Erro. Cole os dados manualmente nos campos.", "erro");
    }
  });

// ============================================================================
// COLAR AULAS DO PAINEL (logica identica ao content-sync.js)
// Formato: data\tdia\tqtd\tmodo\ttipo\tconteudo\tmetodologia\tobs
// ============================================================================
function colarAulasPainel(linhas) {
  const nomeMes = (n) => {
    const m = ['Janeiro','Fevereiro','Marco','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
    return m[n - 1] || '';
  };
  const mesArr = [], diasArr = [], modoArr = [], tipoArr = [];
  const conteudoArr = [], metodologiaArr = [], obsArr = [];

  for (const linha of linhas) {
    const c = linha.split('\t');
    if (c.length < 6) continue;
    const dataStr = c[0]?.trim() || '';
    let dia = '', mes = '';
    if (dataStr.includes('/')) {
      const p = dataStr.split('/');
      dia = p[0]; mes = nomeMes(parseInt(p[1], 10));
    }
    mesArr.push(mes); diasArr.push(dia);
    modoArr.push(c[3]?.trim() || 'Aula');
    tipoArr.push(c[4]?.trim() || 'Avulso');
    conteudoArr.push(c[5]?.trim() || 'Aula realizada de acordo com o plano competente.');
    metodologiaArr.push(c[6]?.trim() || 'Aula dialogada');
    obsArr.push(c[7]?.trim() || '');
  }
  if (mesArr.length === 0) { mostrarFeedbackColar("Nenhuma aula valida encontrada.", "erro"); return 0; }

  document.getElementById("mes").value = mesArr.join('\n');
  document.getElementById("dias").value = diasArr.join('\n');
  document.getElementById("modo").value = modoArr.join('\n');
  document.getElementById("tipo").value = tipoArr.join('\n');
  document.getElementById("conteudo").value = conteudoArr.join('\n');
  document.getElementById("metodologia").value = metodologiaArr.join('\n');
  document.getElementById("observacoes").value = obsArr.join('\n');

  const elReg = document.getElementById('aulas-registradas');
  const elRest = document.getElementById('aulas-restantes');
  if (elReg) elReg.textContent = '0';
  if (elRest) elRest.textContent = mesArr.length;
  return mesArr.length;
}

// ============================================================================
// COLAR FREQUENCIAS DO PAINEL (logica identica ao content-sync.js)
// Formato: data\ttempos
// ============================================================================
function colarFrequenciasPainel(linhas) {
  const datas = [], tempos = [];
  for (const linha of linhas) {
    const c = linha.split('\t');
    if (!c[0]?.trim()) continue;
    datas.push(c[0].trim());
    tempos.push(c[1]?.trim() || '1,2');
  }
  if (datas.length === 0) { mostrarFeedbackColar("Nenhuma frequencia valida encontrada.", "erro"); return 0; }

  const elD = document.getElementById('freq-datas');
  const elT = document.getElementById('freq-tempos');
  if (elD) elD.value = datas.join('\n');
  if (elT) elT.value = tempos.join('\n');

  const elReg = document.getElementById('freq-registradas');
  const elRest = document.getElementById('freq-restantes');
  if (elReg) elReg.textContent = '0';
  if (elRest) elRest.textContent = datas.length;
  return datas.length;
}

// ============================================================================
// FEEDBACK VISUAL
// ============================================================================
function mostrarFeedbackColar(mensagem, tipo) {
  const el = document.getElementById("colar-feedback");
  if (!el) return;
  el.innerHTML = mensagem;
  el.className = "colar-feedback visible " + (tipo || "");
  setTimeout(() => el.classList.remove("visible"), 8000);
}

  // --- Limpar campos de AULAS ---
  document.getElementById("limpar-campos-aulas-tudo")?.addEventListener("click", () => {
    ["mes", "dias", "modo", "tipo", "conteudo", "metodologia", "observacoes"]
      .forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = "";
      });
    console.log("[EXECUTAR-TUDO] Campos de aulas limpos.");
  });

  // --- Limpar campos de FREQUENCIA ---
  document.getElementById("limpar-campos-freq-tudo")?.addEventListener("click", () => {
    ["freq-datas", "freq-tempos"].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = "";
    });
    console.log("[EXECUTAR-TUDO] Campos de frequencia limpos.");
  });

  // --- Toggle senha ---
  document.getElementById("toggle-senha-tudo")?.addEventListener("click", () => {
    const input = document.getElementById("senha-tudo");
    const icon = document.getElementById("icon-olho-tudo");
    if (input.type === "password") {
      input.type = "text";
      icon.classList.remove("fa-eye-slash");
      icon.classList.add("fa-eye");
    } else {
      input.type = "password";
      icon.classList.remove("fa-eye");
      icon.classList.add("fa-eye-slash");
    }
  });

  // --- Fechar formulario ---
  document.getElementById("fechar-formulario-tudo")?.addEventListener("click", () => {
    wrapper.remove();
    isUIExecutarTudoOpen = false;
    wrapperExecutarTudo = null;
  });

  // --- BOTAO PRINCIPAL: EXECUTAR TUDO ---
  document.getElementById("executar-tudo-btn")?.addEventListener("click", iniciarFluxoExecutarTudo);
}

// ============================================================================
// FLUXO PRINCIPAL: EXECUTAR TUDO
// ============================================================================

/**
 * Valida os dados, salva no sessionStorage e inicia o fluxo automatico.
 * Fluxo: Aulas (todas) -> navega para frequencia -> Frequencias (todas)
 */
function iniciarFluxoExecutarTudo() {
  console.log("[EXECUTAR-TUDO] >>> INICIANDO FLUXO EXECUTAR TUDO <<<");

  // Reset da flag de parada
  ENVIO_PARADO_TUDO = false;

  // ========================================================================
  // 1. VALIDACAO
  // ========================================================================

  const elMes = document.getElementById("mes");
  const elDias = document.getElementById("dias");
  const elFreqDatas = document.getElementById("freq-datas");
  const elFreqTempos = document.getElementById("freq-tempos");
  const elSenha = document.getElementById("senha-tudo");

  const mes = elMes?.value?.trim() || "";
  const dias = elDias?.value?.trim() || "";
  const freqDatas = elFreqDatas?.value?.trim() || "";
  const freqTempos = elFreqTempos?.value?.trim() || "";
  const senha = elSenha?.value?.trim() || "";

  // Validar dados de aulas
  if (!mes || !dias) {
    mostrarToastTudo("Preencha os dados de AULAS (Mes e Dias).", "erro");
    return;
  }

  // Validar dados de frequencia
  if (!freqDatas || !freqTempos) {
    mostrarToastTudo("Preencha os dados de FREQUENCIA (Datas e Tempos).", "erro");
    return;
  }

  // Validar senha
  if (!senha) {
    mostrarToastTudo("Digite a senha do professor.", "erro");
    return;
  }

  // Validar consistencia de aulas
  const camposAulas = ["mes", "dias", "modo", "tipo", "conteudo", "metodologia", "observacoes"];
  const valoresAulas = camposAulas.map(id => document.getElementById(id)?.value?.trim().split("\n").filter(l => l.trim()) || []);
  const maxAulas = Math.max(...valoresAulas.map(v => v.length));
  const minAulas = Math.min(...valoresAulas.map(v => v.length));
  if (maxAulas !== minAulas && minAulas > 0) {
    mostrarToastTudo(`Aviso: Inconsistencia nos dados de aulas (max=${maxAulas}, min=${minAulas}). Verifique as linhas.`, "aviso");
    // Nao bloqueia - prossegue com cuidado
  }

  // Validar consistencia de frequencias
  const datasArr = freqDatas.split("\n").filter(l => l.trim());
  const temposArr = freqTempos.split("\n").filter(l => l.trim());
  if (datasArr.length !== temposArr.length) {
    mostrarToastTudo(`Inconsistencia: ${datasArr.length} datas e ${temposArr.length} tempos. Devem ter a mesma quantidade.`, "erro");
    return;
  }

  console.log(`[EXECUTAR-TUDO] Validacao OK: ${maxAulas || minAulas} aulas, ${datasArr.length} frequencias.`);

  // ========================================================================
  // 2. SALVAR DADOS DE AULAS no sessionStorage
  // ========================================================================

  const campos = ["mes", "dias", "modo", "tipo", "conteudo", "metodologia", "observacoes"];
  const chaves = ["mes", "dias", "modo", "tipo", "conteudo", "metodologia", "observacoes"];
  const dadosAulas = {};
  campos.forEach((id, idx) => {
    const el = document.getElementById(id);
    dadosAulas[chaves[idx]] = el?.value?.trim().split("\n") || [];
  });

  sessionStorage.setItem(AULAS_STORAGE_DADOS, JSON.stringify(dadosAulas));
  sessionStorage.setItem(AULAS_STORAGE_SENHA, senha);
  sessionStorage.setItem(AULAS_STORAGE_INDEX, "0");
  sessionStorage.setItem(AULAS_STORAGE_URL, window.location.href);

  console.log("[EXECUTAR-TUDO] Dados de AULAS salvos no sessionStorage.");
  console.log(`[EXECUTAR-TUDO]   Total aulas: ${dadosAulas.dias?.length || 0}`);
  console.log(`[EXECUTAR-TUDO]   Turma (UUID): ${extrairUuidTurma(window.location.href) || 'N/A'}`);

  // ========================================================================
  // 3. SALVAR DADOS DE FREQUENCIA no sessionStorage
  // ========================================================================

  const dadosFreq = {
    datas: freqDatas.split("\n").filter(l => l.trim()),
    tempos: freqTempos.split("\n").filter(l => l.trim())
  };

  sessionStorage.setItem(FREQ_STORAGE_DADOS, JSON.stringify(dadosFreq));
  sessionStorage.setItem(FREQ_STORAGE_SENHA, senha);
  sessionStorage.setItem(FREQ_STORAGE_INDEX, "0");
  sessionStorage.setItem(FREQ_STORAGE_ERROS, "[]");
  sessionStorage.setItem(FREQ_STORAGE_ERROS_CONSEC, "0");

  console.log("[EXECUTAR-TUDO] Dados de FREQUENCIA salvos no sessionStorage.");
  console.log(`[EXECUTAR-TUDO]   Total frequencias: ${dadosFreq.datas.length}`);

  // ========================================================================
  // 4. INICIAR FLUXO
  // ========================================================================

  // Criar botao "Parar Tudo"
  criarBotaoPararTudo();

  // Iniciar observador de progresso
  iniciarObservadorProgresso(dadosAulas.dias?.length || 0, dadosFreq.datas.length);

  // Iniciar registro de aulas (o modulo de aulas ja existe)
  // As aulas terminam -> navegam automaticamente para frequencia ->
  // content-frequencia.js detecta a URL e inicia sozinho
  if (window.iniciarRegistro) {
    console.log("[EXECUTAR-TUDO] Chamando window.iniciarRegistro() para iniciar aulas...");
    mostrarToastTudo(`Iniciando: ${dadosAulas.dias?.length || 0} aulas + ${dadosFreq.datas.length} frequencias. Aguarde...`, "info");

    // Fecha o formulario para nao atrapalhar
    const wrapper = document.getElementById("executar-tudo-wrapper");
    if (wrapper) {
      wrapper.remove();
      isUIExecutarTudoOpen = false;
    }

    // Dispara a mensagem para iniciar (mesmo fluxo do botao original)
    chrome.runtime.sendMessage({ acao: "executarContent" });
  } else {
    console.error("[EXECUTAR-TUDO] window.iniciarRegistro nao encontrado!");
    mostrarToastTudo("Erro: Modulo de aulas nao carregado. Recarregue a pagina.", "erro");
    pararTudoImediatamente();
  }
}

// ============================================================================
// OBSERVADOR DE PROGRESSO
// ============================================================================

/**
 * Inicia um setInterval que monitora o progresso de aulas e frequencias
 * lendo os contadores do sessionStorage. Quando ambos terminam,
 * mostra toast de sucesso e faz cleanup.
 */
function iniciarObservadorProgresso(totalAulas, totalFreq) {
  console.log(`[EXECUTAR-TUDO] Observador de progresso iniciado. Aulas: ${totalAulas}, Freq: ${totalFreq}`);

  if (observadorProgresso) {
    clearInterval(observadorProgresso);
  }

  let aulasConcluidas = false;
  let freqConcluidas = false;

  observadorProgresso = setInterval(() => {
    // Verifica se foi parado
    if (ENVIO_PARADO_TUDO) {
      clearInterval(observadorProgresso);
      observadorProgresso = null;
      return;
    }

    // --- Progresso de AULAS ---
    const idxAulas = parseInt(sessionStorage.getItem(AULAS_STORAGE_INDEX) || "0", 10);
    const dadosAulasRaw = sessionStorage.getItem(AULAS_STORAGE_DADOS);

    if (!dadosAulasRaw) {
      // Aulas limpou do sessionStorage = provavelmente terminou
      aulasConcluidas = true;
    } else {
      const dadosAulas = JSON.parse(dadosAulasRaw);
      const totalAulasAtual = dadosAulas.dias?.length || totalAulas;
      aulasConcluidas = idxAulas >= totalAulasAtual;
    }

    // --- Progresso de FREQUENCIA ---
    const idxFreq = parseInt(sessionStorage.getItem(FREQ_STORAGE_INDEX) || "0", 10);
    const dadosFreqRaw = sessionStorage.getItem(FREQ_STORAGE_DADOS);

    if (!dadosFreqRaw) {
      // Frequencia limpou do sessionStorage = provavelmente terminou
      freqConcluidas = true;
    } else {
      const dadosFreq = JSON.parse(dadosFreqRaw);
      const totalFreqAtual = dadosFreq.datas?.length || totalFreq;
      freqConcluidas = idxFreq >= totalFreqAtual;
    }

    console.log(`[EXECUTAR-TUDO] Progresso -> Aulas: ${idxAulas}/${totalAulas} (concluido=${aulasConcluidas}) | Freq: ${idxFreq}/${totalFreq} (concluido=${freqConcluidas})`);

    // --- Ambos concluidos? ---
    if (aulasConcluidas && freqConcluidas) {
      console.log("[EXECUTAR-TUDO] >>> AULAS E FREQUENCIAS CONCLUIDAS! <<<");

      clearInterval(observadorProgresso);
      observadorProgresso = null;

      removerBotaoPararTudo();

      mostrarToastTudo(
        `Concluido com sucesso! ${totalAulas} aulas e ${totalFreq} frequencias registradas.`,
        "sucesso"
      );

      return;
    }

  }, 1000); // Verifica a cada 1 segundo
}

// ============================================================================
// EXPOSICAO GLOBAL
// ============================================================================
console.log("[EXECUTAR-TUDO] Modulo orquestrador carregado. Use window.abrirFormularioExecutarTudo() para abrir.");
