// content-frequencia.js - Modulo de Registro de Frequencia
// Interface visual: form-frequencia.html/css (design moderno)
// Automacao: Data -> Periodo (auto) -> Tempo -> Salvar -> Proxima data
//
// CORRECOES DE SEGURANCA (v3.0):
// - sessionStorage em vez de localStorage (dados morrem ao fechar a aba)
// - Verificacao de URL/contexto a cada iteracao (para se mudar de turma)
// - Botao flutuante "Parar Envio" para interrupcao manual imediata

// isUIFrequenciaOpen ja declarado em content-utils.js

// ============================================================
// VARIAVEIS DE CONTROLE DE CONTEXTO
// ============================================================
let _urlInicialFrequencia = null;   // URL da turma quando o envio comecou
let _senhaCache = null;             // Cache em memoria da senha (mais seguro)
let _envioAtivo = false;            // Flag que indica se ha envio em andamento

// ============================================================
// PARTE 1: ABRIR FORMULARIO (interface bonita form-frequencia)
// ============================================================

window.abrirFormularioFrequencia = function() {
  console.log('[FREQ] Abrindo formulario de frequencia...');

  if (isUIFrequenciaOpen) {
    const existing = document.getElementById('registro-frequencia-wrapper');
    if (existing) { existing.style.zIndex = 999999; existing.style.pointerEvents = 'auto'; return; }
  }

  document.getElementById("registro-frequencia-wrapper")?.remove();

  const wrapper = document.createElement("div");
  wrapper.id = "registro-frequencia-wrapper";
  wrapper.style.cssText = `
    position: fixed; top: 80px; right: 20px; z-index: 999999;
    max-width: 100%; max-height: 90vh;
  `;

  Promise.all([
    fetch(chrome.runtime.getURL("form-frequencia.html")).then(r => r.text()),
    fetch(chrome.runtime.getURL("form-frequencia.css")).then(r => r.text())
  ]).then(([html, css]) => {
    const style = document.createElement("style");
    style.textContent = css;
    wrapper.prepend(style);
    wrapper.innerHTML += html;
    document.body.appendChild(wrapper);
    inicializarEventosFrequencia();
  });
};

// ============================================================
// PARTE 2: EVENTOS DO FORMULARIO
// ============================================================

function inicializarEventosFrequencia() {
  const wrapper = document.getElementById("registro-frequencia-wrapper");
  if (!wrapper) return;
  const popup = document.getElementById("registro-frequencia-popup");

  // Arrastavel
  popup.onmousedown = (e) => {
    if (['TEXTAREA','INPUT','BUTTON','I'].includes(e.target.tagName)) return;
    const shiftX = e.clientX - wrapper.getBoundingClientRect().left;
    const shiftY = e.clientY - wrapper.getBoundingClientRect().top;
    const onMove = (ev) => {
      wrapper.style.left = `${ev.pageX - shiftX}px`;
      wrapper.style.top = `${ev.pageY - shiftY}px`;
      wrapper.style.right = "auto";
    };
    const onUp = () => { document.removeEventListener("mousemove", onMove); document.removeEventListener("mouseup", onUp); };
    document.addEventListener("mousemove", onMove);
    document.addEventListener("mouseup", onUp);
  };

  // Toggle senha
  document.getElementById("toggle-senha-freq")?.addEventListener("click", () => {
    const input = document.getElementById("freq-senha");
    const icon = document.getElementById("icon-olho-freq");
    if (input.type === "password") {
      input.type = "text"; icon.classList.remove("fa-eye-slash"); icon.classList.add("fa-eye");
    } else {
      input.type = "password"; icon.classList.remove("fa-eye"); icon.classList.add("fa-eye-slash");
    }
  });

  // Colar do Excel (formato: DATA <tab> TEMPO)
  document.getElementById("colar-dados-freq")?.addEventListener("click", async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (!text) return;
      const linhas = text.trim().split(/\r?\n/);
      if (linhas[0].toLowerCase().includes("data")) linhas.shift();
      const datasArr = [], temposArr = [];
      for (const linha of linhas) {
        const partes = linha.split("\t");
        datasArr.push(partes[0]?.trim() || "");
        temposArr.push(partes[1]?.trim() || "");
      }
      document.getElementById("freq-datas").value = datasArr.join("\n");
      document.getElementById("freq-tempos").value = temposArr.join("\n");
      console.log("[FREQ] Dados colados:", datasArr.length, "registros");
    } catch (err) {
      console.error("[FREQ] Erro ao colar:", err.message);
      alert("Erro ao acessar clipboard. Cole manualmente.");
    }
  });

  // Limpar
  document.getElementById("limpar-campos-freq")?.addEventListener("click", () => {
    ["freq-datas", "freq-tempos", "freq-senha"].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = "";
    });
    // Limpa sessionStorage (dados de registro nao persistem entre abas)
    sessionStorage.removeItem("freq_registroDados");
    sessionStorage.removeItem("freq_registroIndex");
    sessionStorage.removeItem("freq_senhaProfessor");
    sessionStorage.removeItem("freq_registroErros");
    sessionStorage.removeItem("freq_errosConsecutivos");
    desativarDetectorErroAuth();
    atualizarContadoresFrequencia();
    console.log("[FREQ] Campos limpos.");
  });

  // Iniciar Registro
  document.getElementById("enviar-dados-freq")?.addEventListener("click", () => {
    const datas = document.getElementById("freq-datas").value.trim().split("\n").filter(l => l.trim());
    const tempos = document.getElementById("freq-tempos").value.trim().split("\n").filter(l => l.trim());
    const senha = document.getElementById("freq-senha").value.trim();

    if (datas.length === 0) { alert("Preencha pelo menos uma data."); return; }
    if (datas.length !== tempos.length) { alert(`Inconsistencia: ${datas.length} datas e ${tempos.length} tempos.`); return; }
    if (!senha) { alert("Digite a senha de confirmacao."); return; }

    const dados = { datas, tempos };

    // Armazena a URL atual como contexto da turma - usado para detectar navegacao para outra turma
    _urlInicialFrequencia = window.location.href;

    // Salva dados no sessionStorage (morre ao fechar a aba - prev envio para turma errada)
    sessionStorage.setItem("freq_registroDados", JSON.stringify(dados));
    sessionStorage.setItem("freq_registroIndex", "0");
    sessionStorage.setItem("freq_senhaProfessor", senha);
    sessionStorage.setItem("freq_registroErros", "[]");
    sessionStorage.setItem("freq_errosConsecutivos", "0");

    // Tambem mantem a senha em memoria para acesso mais rapido
    _senhaCache = senha;

    ativarDetectorErroAuth();

    console.log("[FREQ] Dados salvos no sessionStorage:", dados);
    console.log("[FREQ] URL inicial (contexto turma):", _urlInicialFrequencia);
    atualizarContadoresFrequencia();
    iniciarRegistroFrequencia();
  });

  // Fechar
  document.getElementById("fechar-formulario-freq")?.addEventListener("click", () => {
    wrapper.remove();
    isUIFrequenciaOpen = false;
  });

  isUIFrequenciaOpen = true;
}

function atualizarContadoresFrequencia() {
  const dados = JSON.parse(sessionStorage.getItem("freq_registroDados") || "{}");
  const total = Array.isArray(dados.datas) ? dados.datas.length : 0;
  const atual = parseInt(sessionStorage.getItem("freq_registroIndex") || "0", 10);
  const elReg = document.getElementById("freq-registradas");
  const elRest = document.getElementById("freq-restantes");
  if (elReg) elReg.textContent = atual;
  if (elRest) elRest.textContent = Math.max(total - atual, 0);
}

// ============================================================
// PARTE 3: BOTAO FLOTUANTE "PARAR ENVIO"
// ============================================================

/**
 * Cria o botao flutuante "Parar Envio" no canto inferior direito.
 * So deve ser chamado quando ha um envio ativo em andamento.
 */
function criarBotaoPararEnvio() {
  // So cria o botao se houver envio de frequencias ativo (evita aparecer no contexto de aulas)
  if (!sessionStorage.getItem("freq_registroDados")) {
    return; // Nao ha envio de frequencias ativo
  }
  // Remove botao existente primeiro (evita duplicados)
  removerBotaoPararEnvio();

  const btn = document.createElement("div");
  btn.id = "freq-btn-parar-envio";
  btn.style.cssText = `
    position: fixed; bottom: 24px; right: 24px; z-index: 2147483646;
    background: linear-gradient(135deg, #dc3545, #c82333);
    color: white; border: none; border-radius: 50px;
    padding: 14px 28px; font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 1em; font-weight: 600; cursor: pointer;
    box-shadow: 0 4px 20px rgba(220, 53, 69, 0.4);
    display: flex; align-items: center; gap: 10px;
    transition: transform 0.15s, box-shadow 0.2s;
    user-select: none;
  `;
  btn.innerHTML = `
    <span style="font-size: 1.2em;">&#9632;</span>
    <span>Parar Envio</span>
  `;

  // Efeitos hover
  btn.onmouseenter = () => {
    btn.style.transform = "scale(1.05)";
    btn.style.boxShadow = "0 6px 28px rgba(220, 53, 69, 0.6)";
  };
  btn.onmouseleave = () => {
    btn.style.transform = "scale(1)";
    btn.style.boxShadow = "0 4px 20px rgba(220, 53, 69, 0.4)";
  };

  // Ao clicar: para o envio imediatamente
  btn.onclick = () => {
    console.log("[FREQ BOTAO] Usuario clicou em Parar Envio");
    pararEnvioFrequencia();
  };

  document.body.appendChild(btn);
  console.log("[FREQ BOTAO] Botao 'Parar Envio' criado");
}

/**
 * Remove o botao flutuante "Parar Envio" da tela.
 */
function removerBotaoPararEnvio() {
  const btn = document.getElementById("freq-btn-parar-envio");
  if (btn) {
    btn.remove();
    console.log("[FREQ BOTAO] Botao 'Parar Envio' removido");
  }
}

/**
 * Para o envio de frequencias imediatamente.
 * Limpa o sessionStorage, remove o botao flutuante e desativa detectores.
 */
function pararEnvioFrequencia() {
  console.log("[FREQ PARAR] >>> Interrompendo envio de frequencias <<<");

  // Limpa todos os dados do sessionStorage
  sessionStorage.removeItem("freq_registroDados");
  sessionStorage.removeItem("freq_registroIndex");
  sessionStorage.removeItem("freq_senhaProfessor");
  sessionStorage.removeItem("freq_registroErros");
  sessionStorage.removeItem("freq_errosConsecutivos");

  // Reseta variaveis de controle
  _senhaCache = null;
  _urlInicialFrequencia = null;
  _envioAtivo = false;

  // Remove UI
  removerBotaoPararEnvio();
  desativarDetectorErroAuth();
  atualizarContadoresFrequencia();

  console.log("[FREQ PARAR] Envio interrompido. Dados limpos do sessionStorage.");
}

// ============================================================
// PARTE 4: LOOP PRINCIPAL DE REGISTRO
// ============================================================

async function iniciarRegistroFrequencia() {
  const delay = (ms) => new Promise(r => setTimeout(r, ms));

  // --- VERIFICACAO 1: Ainda ha dados no sessionStorage? ---
  const dadosRaw = sessionStorage.getItem("freq_registroDados");
  const senha = sessionStorage.getItem("freq_senhaProfessor");

  if (!dadosRaw || !senha) {
    console.log("[FREQ LOOP] Sem dados/senha no sessionStorage. Parando.");
    pararEnvioFrequencia();
    return;
  }

  // --- VERIFICACAO 2: Ainda estamos na mesma pagina/turma? ---
  // Se o usuario navegou para outra turma, a URL mudou -> deve parar imediatamente
  if (_urlInicialFrequencia && window.location.href !== _urlInicialFrequencia) {
    console.warn("[FREQ LOOP] URL mudou! Usuario navegou para outra turma.");
    console.warn("[FREQ LOOP]   URL inicial:", _urlInicialFrequencia);
    console.warn("[FREQ LOOP]   URL atual:  ", window.location.href);
    alert("[Frequencia] Envio interrompido: voce navegou para outra turma.");
    pararEnvioFrequencia();
    return;
  }

  // --- VERIFICACAO 3: Ainda estamos na tela de cadastro de frequencia? ---
  if (!window.location.href.includes("/frequencia/cadastrar")) {
    console.warn("[FREQ LOOP] Nao estamos na tela de frequencia. Aguardando...", window.location.href);
    return;
  }

  const dados = JSON.parse(dadosRaw);
  let idx = parseInt(sessionStorage.getItem("freq_registroIndex") || "0", 10);
  const datas = dados.datas || [];
  let erros = JSON.parse(sessionStorage.getItem("freq_registroErros") || "[]");
  let errosConsec = parseInt(sessionStorage.getItem("freq_errosConsecutivos") || "0", 10);

  // Terminou?
  if (idx >= datas.length) {
    mostrarResumoFinal(datas.length, erros);
    desativarDetectorErroAuth();
    return;
  }

  // Marca que o envio esta ativo e mostra o botao de parar
  if (!_envioAtivo) {
    _envioAtivo = true;
    criarBotaoPararEnvio();
  }

  console.log(`[FREQ LOOP] === ${idx + 1}/${datas.length}: ${dados.datas[idx]} | Tempo: ${dados.tempos[idx]} ===`);

  const sucesso = await preencherUmaData(dados.datas[idx], dados.tempos[idx], senha);

  if (!sucesso) {
    erros.push(`${dados.datas[idx]} (tempo: ${dados.tempos[idx]})`);
    sessionStorage.setItem("freq_registroErros", JSON.stringify(erros));
    errosConsec++;
    sessionStorage.setItem("freq_errosConsecutivos", String(errosConsec));
    console.warn(`[FREQ LOOP] ERRO em ${dados.datas[idx]}. Consecutivos: ${errosConsec}`);
    if (errosConsec >= 5) {
      alert("5 erros consecutivos! Parando por seguranca.\n" + erros.slice(-5).map(e => "  - " + e).join("\n"));
      pararEnvioFrequencia();
      return;
    }
  } else {
    if (errosConsec > 0) {
      sessionStorage.setItem("freq_errosConsecutivos", "0");
      errosConsec = 0;
    }
  }

  idx++;
  sessionStorage.setItem("freq_registroIndex", idx.toString());
  atualizarContadoresFrequencia();

  if (idx >= datas.length) {
    mostrarResumoFinal(datas.length, erros);
    desativarDetectorErroAuth();
    return;
  }
}

// ============================================================
// PARTE 5: PREENCHER UMA UNICA DATA
// ============================================================

/**
 * Preenche a senha e clica Confirmar, tratando SweetAlert2 de erro de rede.
 * Se aparecer "An error occurred while sending the request", clica Ok e tenta novamente.
 */
async function confirmarComSenhaFreq(senha, senhaInput) {
  const delay = (ms) => new Promise(r => setTimeout(r, ms));
  const MAX_TENTATIVAS = 3;

  for (let tentativa = 1; tentativa <= MAX_TENTATIVAS; tentativa++) {
    senhaInput.value = senha;
    senhaInput.dispatchEvent(new Event('input', { bubbles: true }));
    await delay(500);
    console.log(`[FREQ-SENHA] Tentativa ${tentativa}/${MAX_TENTATIVAS}`);

    const botoes = Array.from(document.querySelectorAll('button.btn-primary'));
    const btnConfirmar = botoes.find(btn => btn.textContent.replace(/\s/g, '').toLowerCase().includes('confirmar'));
    if (btnConfirmar) { btnConfirmar.click(); console.log("[FREQ-SENHA] ✓ CONFIRMAR clicado"); }

    // Aguarda para ver se aparece SweetAlert de erro
    await delay(2500);

    // Verifica se apareceu SweetAlert2 de erro
    const swalErro = document.querySelector('.swal2-popup.swal2-modal.swal2-icon-error');
    const swalTitulo = document.querySelector('.swal2-popup .swal2-title');
    const temErro = swalErro || (swalTitulo && swalTitulo.textContent.toLowerCase().includes('error'));

    if (temErro) {
      const btnOk = document.querySelector('.swal2-popup .swal2-confirm');
      if (btnOk) {
        console.log('[FREQ-SENHA] SweetAlert de erro! Clicando Ok...');
        btnOk.click();
        await delay(1500);

        const novoInput = document.querySelector('#input-password');
        if (novoInput) { senhaInput = novoInput; continue; }
        else { console.warn('[FREQ-SENHA] Input senha nao reapareceu.'); return; }
      }
    }

    console.log('[FREQ-SENHA] ✓ Senha confirmada.');
    return;
  }

  console.warn(`[FREQ-SENHA] Falhou apos ${MAX_TENTATIVAS} tentativas.`);
}

/**
 * Verifica se o envio foi interrompido (sessionStorage limpo pelo botao Parar).
 */
function envioFoiParado() {
  return !sessionStorage.getItem("freq_registroDados");
}

async function preencherUmaData(dataStr, tempoStr, senha) {
  const delay = (ms) => new Promise(r => setTimeout(r, ms));
  console.log(`[FREQ FORM] Data: ${dataStr} | Tempos: ${tempoStr}`);

  // 1. PREENCHER DATA
  const campoData = await waitForElement('input[placeholder="dd/mm/aaaa"]', 10000);
  if (!campoData) { console.error("[FREQ FORM] Campo DATA nao encontrado"); return false; }

  const dataOk = await preencherDataNoCalendar(campoData, dataStr);
  if (!dataOk) { console.error(`[FREQ FORM] Falha ao preencher data ${dataStr}`); return false; }

  // Verifica se envio foi parado
  if (envioFoiParado()) { console.log('[FREQ FORM] Envio parado apos preencher data.'); return false; }

  // 2. AGUARDAR PERIODO
  await delay(3000);
  const campoPeriodo = await waitForElement('#autocomplete-periodo input[placeholder="Selecione"]', 5000);
  if (campoPeriodo && campoPeriodo.value) console.log(`[FREQ FORM] Periodo: ${campoPeriodo.value}`);

  // 3. SELECIONAR TEMPO(S)
  const temposNumeros = tempoStr.split(/[,;]/)
    .map(t => parseInt(t.replace(/[^0-9]/g, ''), 10))
    .filter(n => !isNaN(n) && n >= 1 && n <= 9);
  if (temposNumeros.length === 0) { console.warn("[FREQ FORM] Tempo invalido:", tempoStr); return false; }

  const multiselect = await waitForElement('#mutiselect-tempo .ui-multiselect', 5000);
  if (!multiselect) { console.error("[FREQ FORM] Multiselect nao encontrado"); return false; }

  multiselect.click(); await delay(1000);

  for (const numTempo of temposNumeros) {
    const labelTexto = `${numTempo}º Tempo`;
    const itens = document.querySelectorAll('.ui-multiselect-panel .ui-multiselect-items li, .ui-multiselect-items li');
    let encontrado = false;
    for (const item of itens) {
      const texto = item.textContent.trim();
      if (texto.includes(`${numTempo}º`) || texto.includes(`${numTempo} `)) {
        const chk = item.querySelector('.ui-chkbox-box') || item.querySelector('input') || item;
        const jaSel = item.classList.contains('ui-state-highlight');
        if (!jaSel) { chk.click(); console.log(`[FREQ FORM] ✓ ${labelTexto}`); }
        else { console.log(`[FREQ FORM] ✓ ${labelTexto} (ja selecionado)`); }
        encontrado = true; await delay(300); break;
      }
    }
    if (!encontrado) console.warn(`[FREQ FORM] ✗ ${labelTexto} nao encontrado`);
  }
  document.body.click(); await delay(800);

  // Verifica se envio foi parado
  if (envioFoiParado()) { console.log('[FREQ FORM] Envio parado apos selecionar tempos.'); return false; }

  // 4. AGUARDAR TABELA
  await delay(2000);
  console.log("[FREQ FORM] Tabela carregada (alunos presentes)");

  // 5. SALVAR
  const btnSalvar = await waitForElement('#btn-submit', 5000);
  if (!btnSalvar) { console.error("[FREQ FORM] Botao SALVAR nao encontrado"); return false; }
  btnSalvar.scrollIntoView({ behavior: 'smooth', block: 'center' });
  await delay(500);

  // Verifica se envio foi parado antes de clicar Salvar
  if (envioFoiParado()) { console.log('[FREQ FORM] Envio parado antes de Salvar.'); return false; }

  btnSalvar.click();
  console.log("[FREQ FORM] ✓ SALVAR clicado");

  // 6. SENHA + CONFIRMAR (com tratamento de erro de rede)
  await delay(1500);
  const senhaInput = await waitForElement('#input-password', 8000);
  if (senhaInput) {
    // Verifica se envio foi parado antes de confirmar senha
    if (envioFoiParado()) { console.log('[FREQ FORM] Envio parado antes de confirmar senha.'); return false; }
    await confirmarComSenhaFreq(senha, senhaInput);
  } else {
    console.log("[FREQ FORM] Modal de senha nao apareceu");
  }

  // Verifica se envio foi parado apos confirmar
  if (envioFoiParado()) { console.log('[FREQ FORM] Envio parado apos confirmar senha.'); return false; }

  console.log("[FREQ FORM] ✓ Registro concluido");
  return true;
}

// ============================================================
// PARTE 6: NAVEGACAO NO CALENDARIO
// ============================================================

async function preencherDataNoCalendar(inputEl, dataStr) {
  const delay = (ms) => new Promise(r => setTimeout(r, ms));
  const [diaStr, mesStr, anoStr] = dataStr.split('/');
  const diaAlvo = parseInt(diaStr, 10);
  const mesAlvo = parseInt(mesStr, 10);
  const anoAlvo = parseInt(anoStr, 10);
  const mesAlvo0 = mesAlvo - 1;

  console.log(`[FREQ CALENDAR] Alvo: ${diaAlvo}/${mesAlvo}/${anoAlvo}`);

  // Passo 1: Abrir calendario
  inputEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
  await delay(500);

  let btnCalendario = document.querySelector('button.ui-datepicker-trigger, button.ui-calendar-button');
  if (!btnCalendario) {
    for (const btn of document.querySelectorAll('button')) {
      if (btn.querySelector('.pi-calendar')) { btnCalendario = btn; break; }
    }
  }
  if (!btnCalendario) { console.warn("[FREQ CALENDAR] Botao calendario nao encontrado"); return false; }

  btnCalendario.click();
  await delay(1200);

  let painel = document.querySelector('.ui-datepicker');
  if (!painel) { console.warn("[FREQ CALENDAR] Painel nao abriu"); return false; }

  // Passo 2: Ler estado inicial
  const mesesPt = ['janeiro','fevereiro','marco','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
  const mesesPtAbrev = ['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'];

  function lerMes(p) {
    const span = p.querySelector('.ui-datepicker-month');
    if (!span) return -1;
    const t = span.textContent.trim().toLowerCase();
    for (let i = 0; i < 12; i++) {
      if (t.includes(mesesPt[i]) || t.includes(mesesPtAbrev[i])) return i;
    }
    return -1;
  }

  let mesInicial = lerMes(painel);
  const anoSelect = painel.querySelector('select.ui-datepicker-year');
  let anoInicial = anoSelect ? parseInt(anoSelect.value, 10) : -1;

  console.log(`[FREQ CALENDAR] Inicial: mes=${mesInicial + 1}, ano=${anoInicial}`);
  if (mesInicial < 0 || anoInicial < 0) { console.warn("[FREQ CALENDAR] Nao leu mes/ano"); return false; }

  // Passo 3: Mudar ANO via select
  if (anoSelect && anoInicial !== anoAlvo) {
    console.log(`[FREQ CALENDAR] >>> ANO: ${anoInicial} -> ${anoAlvo}`);
    anoSelect.value = String(anoAlvo);
    anoSelect.dispatchEvent(new Event('change', { bubbles: true }));
    await delay(1200);
    painel = document.querySelector('.ui-datepicker');
    mesInicial = lerMes(painel);
    console.log(`[FREQ CALENDAR] Apos ano: mes=${mesInicial + 1}`);
  }

  // Passo 4: Mudar MES (contagem fixa, SEM ler DOM entre clicks)
  let mesesDiff = mesAlvo0 - mesInicial;
  if (mesesDiff !== 0) {
    const direcao = mesesDiff > 0 ? 'NEXT' : 'PREV';
    const totalClicks = Math.abs(mesesDiff);
    console.log(`[FREQ CALENDAR] >>> MES: ${mesInicial + 1} -> ${mesAlvo} (${totalClicks} clicks ${direcao})`);

    for (let i = 0; i < totalClicks; i++) {
      painel = document.querySelector('.ui-datepicker');
      if (!painel) { console.warn(`[FREQ CALENDAR] Painel sumiu no click ${i + 1}`); return false; }
      const btn = direcao === 'NEXT' ? painel.querySelector('.ui-datepicker-next') : painel.querySelector('.ui-datepicker-prev');
      if (!btn) { console.warn(`[FREQ CALENDAR] Seta ${direcao} nao encontrada`); return false; }
      btn.click();
      await delay(800);
    }
    console.log(`[FREQ CALENDAR] ${totalClicks} clicks concluidos`);
    await delay(1000);
  }

  // Passo 5: Verificar mes final
  painel = document.querySelector('.ui-datepicker');
  if (!painel) { console.warn("[FREQ CALENDAR] Painel sumiu"); return false; }

  const mesFinal = lerMes(painel);
  console.log(`[FREQ CALENDAR] Final: mes=${mesFinal + 1} (esperado: ${mesAlvo})`);
  if (mesFinal !== mesAlvo0) { console.warn("[FREQ CALENDAR] Mes ERRADO"); return false; }

  // Passo 6: Clicar no DIA
  const celulas = painel.querySelectorAll('.ui-datepicker-calendar td');
  for (const td of celulas) {
    if (td.classList.contains('ui-datepicker-other-month')) continue;
    if (td.classList.contains('ui-state-disabled')) continue;
    const link = td.querySelector('a.ui-state-default, span.ui-state-default');
    if (!link) continue;
    const numDia = parseInt(link.textContent.trim(), 10);
    if (numDia === diaAlvo) {
      link.scrollIntoView({ block: 'center' });
      await delay(200);
      link.click();
      console.log(`[FREQ CALENDAR] ✓ Dia ${diaAlvo} clicado`);
      await delay(800);
      if (inputEl.value && inputEl.value.includes(diaStr.padStart(2, '0'))) {
        console.log(`[FREQ CALENDAR] ✓✓✓ DATA OK: "${inputEl.value}"`);
        return true;
      }
      return false;
    }
  }

  console.warn(`[FREQ CALENDAR] Dia ${diaAlvo} nao encontrado`);
  return false;
}

// ============================================================
// PARTE 7: OBSERVADOR DE URL
// ============================================================

/**
 * Mostra notificacao toast no estilo glassmorphism
 */
function mostrarToastFreq(mensagem, tipo) {
  const cores = {
    sucesso: { bg: 'rgba(212,237,218,0.95)', cor: '#155724', borda: 'rgba(195,230,203,0.8)', icone: '&#9989;' },
    erro:    { bg: 'rgba(248,215,218,0.95)', cor: '#721c24', borda: 'rgba(245,198,203,0.8)', icone: '&#10060;' },
    aviso:   { bg: 'rgba(255,243,205,0.95)', cor: '#856404', borda: 'rgba(255,234,167,0.8)', icone: '&#9888;' },
    info:    { bg: 'rgba(209,236,241,0.95)', cor: '#0c5460', borda: 'rgba(190,230,239,0.8)', icone: '&#128161;' }
  };
  const estilo = cores[tipo] || cores.info;

  // Remove toast anterior
  const antigo = document.getElementById('freq-toast-notificacao');
  if (antigo) antigo.remove();

  const div = document.createElement('div');
  div.id = 'freq-toast-notificacao';
  div.style.cssText = `
    position: fixed; top: 20px; right: 20px; z-index: 2147483647;
    background: ${estilo.bg}; backdrop-filter: blur(15px); 
    color: ${estilo.cor}; border: 1px solid ${estilo.borda};
    border-radius: 16px; padding: 16px 24px;
    font-family: 'Segoe UI', Arial, sans-serif; font-size: 0.92em; font-weight: 500;
    box-shadow: 0 8px 32px rgba(0,0,0,0.12);
    max-width: 420px; animation: slideInToastFreq 0.3s ease;
  `;
  div.innerHTML = `<span style="margin-right:8px;font-size:1.1em;">${estilo.icone}</span> ${mensagem}`;

  const cssAnims = document.createElement('style');
  cssAnims.textContent = `@keyframes slideInToastFreq { from { opacity:0; transform: translateX(100px); } to { opacity:1; transform: translateX(0); } }`;
  div.appendChild(cssAnims);

  document.body.appendChild(div);
  setTimeout(() => div.remove(), 8000);
}

let lastUrlFreq = location.href;
new MutationObserver(() => {
  if (location.href !== lastUrlFreq) {
    lastUrlFreq = location.href;

    // Usa sessionStorage - se a aba foi fechada/reaberta, os dados ja sumiram
    const temDados = sessionStorage.getItem("freq_registroDados");
    if (!temDados) return;

    const idxObs = parseInt(sessionStorage.getItem("freq_registroIndex") || "0", 10);
    const dadosObs = JSON.parse(temDados);

    // Terminou?
    if (dadosObs.datas && idxObs >= dadosObs.datas.length) {
      const errosObs = JSON.parse(sessionStorage.getItem("freq_registroErros") || "[]");
      setTimeout(() => mostrarResumoFinal(dadosObs.datas.length, errosObs), 1000);
      return;
    }

    if (location.href.includes('/frequencia/cadastrar')) {
      console.log("[FREQ OBSERVER] Na tela de cadastro. Continuando...");
      // Mostra toast informativo se veio de navegacao automatica (sem dados ainda)
      if (!sessionStorage.getItem("freq_registroDados")) {
        mostrarToastFreq("Aulas concluidas! Copie as frequencias do painel web e clique em 'Buscar do Painel' na extensao.", "info");
      }
      setTimeout(() => iniciarRegistroFrequencia(), 2500);
      return;
    }

    if (location.href.includes('/frequencia') && !location.href.includes('/cadastrar')) {
      console.log("[FREQ OBSERVER] Na listagem. Clicando em Registrar Frequencia...");
      setTimeout(() => clicarRegistrarFrequencia(), 2000);
      return;
    }
  }
}).observe(document, { subtree: true, childList: true });

async function clicarRegistrarFrequencia() {
  await new Promise(r => setTimeout(r, 1500));
  const todosBotoes = document.querySelectorAll('button');
  let btn = null;
  for (const b of todosBotoes) {
    const texto = b.textContent.toLowerCase().replace(/\s/g, '');
    const routerlink = b.getAttribute('routerlink');
    if ((texto.includes('registrarfrequencia') || texto.includes('registrarfrequência')) && routerlink === 'cadastrar') {
      btn = b; break;
    }
  }
  if (!btn) {
    for (const b of todosBotoes) {
      if (b.classList.contains('btn-primary-dark') && b.querySelector('.bi-person-check-fill')) { btn = b; break; }
    }
  }
  if (!btn) {
    for (const b of todosBotoes) {
      if (b.textContent.toLowerCase().includes('registrar') && b.textContent.toLowerCase().includes('frequen')) { btn = b; break; }
    }
  }
  if (btn) {
    btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await new Promise(r => setTimeout(r, 500));
    btn.click();
    console.log("[FREQ REGISTRAR] ✓ Registrar Frequencia clicado");
  } else {
    console.warn("[FREQ REGISTRAR] Botao nao encontrado");
  }
}

// ============================================================
// PARTE 8: MODAL DE RESUMO FINAL
// ============================================================

function mostrarResumoFinal(totalDatas, erros) {
  console.log("[FREQ RESUMO] >>> CHAMANDO RESUMO FINAL <<<");
  const sucessos = totalDatas - erros.length;

  // Marca envio como finalizado e remove o botao flutuante
  _envioAtivo = false;
  removerBotaoPararEnvio();

  const existente = document.getElementById('freq-resumo-modal');
  if (existente) existente.remove();

  const overlay = document.createElement('div');
  overlay.id = 'freq-resumo-modal';
  overlay.style.cssText = `
    position: fixed; top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.5); z-index: 2147483647;
    display: flex; align-items: center; justify-content: center;
    font-family: 'Segoe UI', Arial, sans-serif;
  `;

  let errosHtml = '';
  if (erros.length > 0) {
    errosHtml = `
      <div style="margin-top: 16px; text-align: left; max-height: 200px; overflow-y: auto;">
        <p style="color: #dc3545; font-weight: 600; margin: 0 0 8px 0; font-size: 0.95em;">
          &#10007; ${erros.length} data(s) com erro:
        </p>
        <ul style="margin: 0; padding-left: 20px; color: #555; font-size: 0.9em;">
          ${erros.map(e => `<li style="margin-bottom: 4px;">${e}</li>`).join('')}
        </ul>
      </div>`;
  }

  overlay.innerHTML = `
    <div style="background: white; border-radius: 16px; padding: 32px; max-width: 420px; width: 90%;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3); text-align: center;
                animation: freqFadeIn 0.3s ease;">
      <div style="font-size: 3em; margin-bottom: 8px;">${erros.length > 0 ? '&#9888;&#65039;' : '&#9989;'}</div>
      <h2 style="margin: 0 0 8px 0; color: #333; font-size: 1.4em;">
        ${erros.length > 0 ? 'Registro Concluido!' : 'Tudo Certo!'}
      </h2>
      <p style="color: #666; margin: 0 0 16px 0; font-size: 0.95em;">
        ${erros.length > 0 ? 'Algumas datas foram registradas com sucesso.' : 'Todas as frequencias foram lancadas com sucesso!'}
      </p>
      <div style="display: flex; gap: 16px; justify-content: center; margin: 20px 0;">
        <div style="background: #d4edda; border-radius: 12px; padding: 12px 20px;">
          <div style="font-size: 1.6em; font-weight: 700; color: #155724;">${sucessos}</div>
          <div style="font-size: 0.8em; color: #155724;">&#10003; OK</div>
        </div>
        ${erros.length > 0 ? `
        <div style="background: #f8d7da; border-radius: 12px; padding: 12px 20px;">
          <div style="font-size: 1.6em; font-weight: 700; color: #721c24;">${erros.length}</div>
          <div style="font-size: 0.8em; color: #721c24;">&#10007; Erro</div>
        </div>` : ''}
      </div>
      ${errosHtml}
      <button id="freq-btn-ok" style="margin-top: 20px; background: linear-gradient(135deg, #28a745, #20c997);
        color: white; border: none; border-radius: 10px; padding: 12px 36px;
        font-size: 1.1em; font-weight: 600; cursor: pointer;
        transition: transform 0.15s, filter 0.2s;">OK</button>
    </div>
    <style>@keyframes freqFadeIn { from { opacity: 0; transform: scale(0.9); } to { opacity: 1; transform: scale(1); } }</style>
  `;

  document.body.appendChild(overlay);
  overlay.querySelector('#freq-btn-ok').addEventListener('click', () => {
    // Limpa TUDO do sessionStorage ao fechar o resumo
    sessionStorage.removeItem('freq_registroDados');
    sessionStorage.removeItem('freq_registroIndex');
    sessionStorage.removeItem('freq_senhaProfessor');
    sessionStorage.removeItem('freq_registroErros');
    sessionStorage.removeItem('freq_errosConsecutivos');
    _senhaCache = null;
    _urlInicialFrequencia = null;
    overlay.remove();
    const wrapper = document.getElementById('registro-frequencia-wrapper');
    if (wrapper) { wrapper.remove(); isUIFrequenciaOpen = false; }
    desativarDetectorErroAuth();
    console.log("[FREQ RESUMO] Modal fechado. Dados limpos do sessionStorage.");
  });
}

// ============================================================
// PARTE 9: DETECTOR DE ERRO DE AUTENTICACAO
// ============================================================

const observerErroAuth = new MutationObserver(() => {
  const modalErro = document.querySelector('.swal2-container, .swal2-popup');
  if (!modalErro) return;
  const btnOk = modalErro.querySelector('.swal2-confirm, .swal2-confirm.btn-primary');
  if (!btnOk) return;
  const texto = btnOk.textContent.trim().toLowerCase();
  if (texto !== 'ok') return;
  const modalTexto = modalErro.textContent.toLowerCase();
  const ehErro = modalTexto.includes('erro') || modalTexto.includes('falha') ||
                 modalTexto.includes('invalid') || modalTexto.includes('nao foi possivel') ||
                 modalTexto.includes('tente novamente') || modalTexto.includes('senha');
  if (!ehErro) return;

  console.log("[FREQ ERRO AUTH] Modal de erro detectado! Clicando OK...");
  btnOk.click();
  console.log("[FREQ ERRO AUTH] OK clicado! Aguardando senha reaparecer...");
  setTimeout(() => tentarConfirmarSenhaNovamente(), 1500);
});

/**
 * Tenta reconfirmar a senha apos um erro de autenticacao.
 * Usa _senhaCache (memoria) como prioridade, com fallback para sessionStorage.
 */
async function tentarConfirmarSenhaNovamente() {
  // Prioridade 1: cache em memoria (mais rapido, nao depende de storage)
  // Prioridade 2: sessionStorage (fallback se a pagina foi recarregada)
  const senha = _senhaCache || sessionStorage.getItem("freq_senhaProfessor");
  if (!senha) { console.warn("[FREQ ERRO AUTH] Sem senha em cache nem no sessionStorage"); return; }

  for (let tentativa = 0; tentativa < 10; tentativa++) {
    const senhaInput = document.querySelector('#input-password');
    if (senhaInput && senhaInput.offsetParent !== null) {
      console.log("[FREQ ERRO AUTH] Modal de senha reapareceu! Reenviando...");
      senhaInput.value = senha;
      senhaInput.dispatchEvent(new Event('input', { bubbles: true }));
      await new Promise(r => setTimeout(r, 500));
      const botoes = Array.from(document.querySelectorAll('button.btn-primary'));
      const btnConfirmar = botoes.find(btn => btn.textContent.replace(/\s/g, '').toLowerCase().includes('confirmar'));
      if (btnConfirmar && !btnConfirmar.disabled) {
        btnConfirmar.click();
        console.log("[FREQ ERRO AUTH] ✓ Confirmar re-clicado!");
        return;
      }
    }
    await new Promise(r => setTimeout(r, 800));
  }
  console.warn("[FREQ ERRO AUTH] Modal de senha nao reapareceu");
}

function ativarDetectorErroAuth() {
  const temDados = sessionStorage.getItem("freq_registroDados");
  const senha = sessionStorage.getItem("freq_senhaProfessor");
  if (temDados && senha) {
    _senhaCache = senha;
    observerErroAuth.observe(document.body, { childList: true, subtree: true });
    console.log("[FREQ ERRO AUTH] Detector ATIVADO");
  }
}

function desativarDetectorErroAuth() {
  observerErroAuth.disconnect();
  _senhaCache = null;
  console.log("[FREQ ERRO AUTH] Detector DESATIVADO");
}

// ============================================================
// PARTE 10: UTILITARIOS
// ============================================================

async function waitForElement(selector, timeout = 5000, interval = 200) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const el = document.querySelector(selector);
    if (el && el.isConnected && el.offsetParent !== null) return el;
    await new Promise(r => setTimeout(r, interval));
  }
  console.warn(`[waitForElement] Nao encontrado: ${selector}`);
  return null;
}

if (typeof window !== 'undefined') {
  window.iniciarRegistroFrequencia = iniciarRegistroFrequencia;
  window.preencherUmaData = preencherUmaData;
}

// ============================================================================
// PARTE 11: VERIFICACAO DE CARREGAMENTO DIRETO
// Se o script carrega JA na pagina /frequencia (sem /cadastrar) e tem dados,
// clica em "Registrar Frequencia" automaticamente (o MutationObserver nao
// detecta porque a URL nao mudou - ja comecou nessa pagina).
// ============================================================================
(function verificarCarregamentoDireto() {
  const url = window.location.href;
  const temDados = sessionStorage.getItem("freq_registroDados");

  // Esta na pagina /frequencia mas NAO em /frequencia/cadastrar?
  const ehPaginaFrequencia = url.includes('/frequencia') && !url.includes('/cadastrar');

  if (ehPaginaFrequencia && temDados) {
    console.log('[FREQ INIT] Carregamento direto em /frequencia detectado! Tem dados no sessionStorage.');
    console.log('[FREQ INIT] Clicando em "Registrar Frequencia" em 3 segundos...');
    setTimeout(() => clicarRegistrarFrequencia(), 3000);
  }
})();

// ============================================================================
// PARTE 12: VERIFICACAO DE PARADA COMPARTILHADA
// O content-executar-tudo.js limpa o sessionStorage quando o usuario clica
// "Parar". Este modulo precisa verificar se os dados ainda existem durante
// a execucao de preencherUmaData().
// ============================================================================
setInterval(() => {
  if (!_envioAtivo) return; // So verifica quando envio esta ativo
  if (!sessionStorage.getItem("freq_registroDados")) {
    console.warn('[FREQ STOP] Dados removidos do sessionStorage (usuario clicou Parar)! Parando...');
    pararEnvioFrequencia();
  }
}, 1000);

console.log('[content-frequencia] Modulo v3.1 carregado - Correcoes: sessionStorage + verificacao URL + botao Parar + carregamento direto');
