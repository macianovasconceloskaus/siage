chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        console.log('[CONTENT] Received message from popup.js:', request.action); // log do que foi recebido
        if (request.action === "openAulasForm") { // Ação agora é openAulasForm
            abrirFormularioAulas();
        } else if (request.action === "openNotasForm") { // Ação agora é openNotasForm
            abrirFormularioNotas();
        } else if (request.action === "openFrequenciaForm") {
            abrirFormularioFrequencia();
        } else if (request.action === "openExecutarTudoForm") {
            window.abrirFormularioExecutarTudo();
        }
        // Responde ao remetente (popup.js) que a mensagem foi recebida.
        sendResponse({status: "Message received by content.js"});
    }
);

// ====== END OF content.js CODE (COPY ALL OF THIS) ======



// === Observador para preencher senha automaticamente no SIAGE ===
const observerSenha = new MutationObserver((mutationsList, observer) => {
  for (const mutation of mutationsList) {
    if (mutation.type === 'childList') {
      const senhaInput = document.querySelector('#input-password');
      const btnConfirmar = Array.from(document.querySelectorAll('button[type="submit"]')).find(btn => btn.textContent?.toLowerCase().includes('confirmar'));
      if (senhaInput && btnConfirmar) {
        chrome.storage.local.get(['senhaConfirmacao'], function(result) {
          const senha = result.senhaConfirmacao;
          if (senha) {
            senhaInput.value = senha;
            senhaInput.dispatchEvent(new Event('input', { bubbles: true }));
            senhaInput.dispatchEvent(new Event('change', { bubbles: true }));
            console.log("[AUTO-SENHA] Senha preenchida automaticamente em #input-password.");
            setTimeout(() => {
              btnConfirmar.click();
console.log("[AUTO-SENHA] Botão Confirmar clicado.");
observarVoltaParaListaDeAulas();
              console.log("[AUTO-SENHA] Botão Confirmar clicado.");
            }, 500);
            observer.disconnect();
          }
        });
      }
    }
  }
});