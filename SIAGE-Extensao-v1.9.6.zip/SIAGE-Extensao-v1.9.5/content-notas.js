async function preencherDadosNoSIAGE(formularioId, dadosParaPreencher) {
  console.log(`[SIAGE FILL] Preenchendo dados no SIAGE para o formulário: ${formularioId}`);
  console.log('[SIAGE FILL] Dados recebidos para preenchimento:', dadosParaPreencher);

  let preenchimentoRealizado = false;

  if (formularioId === 'formRegistroNotasSIAGE') {
    const colunasNotas = ["ALUNO", "NOTA 1", "REC 1", "NOTA 2", "REC 2", "NOTA 3", "REC 3"];

    const dadosExtensaoPorAluno = [];
    const numLinhas = dadosParaPreencher["ALUNO"] ? dadosParaPreencher["ALUNO"].split('\n').filter(line => line.trim() !== '').length : 0;

    for (let i = 0; i < numLinhas; i++) {
      const alunoData = {};
      colunasNotas.forEach(col => {
        const lines = dadosParaPreencher[col] ? dadosParaPreencher[col].split('\n') : [];
        alunoData[col] = lines[i] ? lines[i].trim() : '';
      });
      if (alunoData["ALUNO"]) {
        dadosExtensaoPorAluno.push(alunoData);
      }
    }

    console.log('[SIAGE FILL] Dados da extensão por aluno (processado):', dadosExtensaoPorAluno);

    const mapeamentoFormControlsNotas = {
      'NOTA 1': 'notaUnidade1',
      'REC 1': 'notaRecuperacaoReposicaoUnidade1',
      'NOTA 2': 'notaUnidade2',
      'REC 2': 'notaRecuperacaoReposicaoUnidade2',
      'NOTA 3': 'notaUnidade3',
      'REC 3': 'notaRecuperacaoReposicaoUnidade3'
    };

    const linhasSIAGE = document.querySelectorAll('tbody tr, tr[class*="ng-star-inserted"]');
    let alunosPreenchidosCount = 0;

    if (linhasSIAGE.length === 0) {
      alert('Nenhuma linha de aluno encontrada na página do SIAGE. Verifique se a tabela de notas está carregada.');
    }

    linhasSIAGE.forEach(linhaSIAGE => {
      const elementoNomeAlunoSIAGE = linhaSIAGE.querySelector('td.wide-column') || linhaSIAGE.querySelector('td');
      const nomeAlunoSIAGE = elementoNomeAlunoSIAGE ? elementoNomeAlunoSIAGE.textContent.trim().toUpperCase() : '';

      if (!nomeAlunoSIAGE) {
        console.log('[SIAGE FILL] Nome do aluno SIAGE não encontrado na linha:', linhaSIAGE);
        return;
      }

      const dadosAlunoExtensao = dadosExtensaoPorAluno.find(
        extData => extData["ALUNO"].trim().toUpperCase() === nomeAlunoSIAGE
      );

      if (dadosAlunoExtensao) {
        console.log(`[SIAGE FILL] Correspondência encontrada para o aluno: ${nomeAlunoSIAGE}`);
        let notasPreenchidasNaLinha = false;

        for (const colunaExtensao in mapeamentoFormControlsNotas) {
          if (mapeamentoFormControlsNotas.hasOwnProperty(colunaExtensao) && dadosAlunoExtensao.hasOwnProperty(colunaExtensao)) {
            const formControlNameSIAGE = mapeamentoFormControlsNotas[colunaExtensao];
            const valorParaPreencher = dadosAlunoExtensao[colunaExtensao];

            const campoSIAGE = linhaSIAGE.querySelector(`input[formcontrolname="${formControlNameSIAGE}"]`);

            if (campoSIAGE && valorParaPreencher !== '') {
              campoSIAGE.value = valorParaPreencher;
              campoSIAGE.dispatchEvent(new Event('input', { bubbles: true }));
              campoSIAGE.dispatchEvent(new Event('change', { bubbles: true }));
              console.log(`  [SIAGE FILL] Preenchido ${colunaExtensao} (${formControlNameSIAGE}): ${valorParaPreencher}`);
              notasPreenchidasNaLinha = true;
            } else {
              console.warn(`  [SIAGE FILL] Campo ${formControlNameSIAGE} não encontrado na linha de ${nomeAlunoSIAGE}.`);
            }
          }
        }
        if (notasPreenchidasNaLinha) {
            alunosPreenchidosCount++;
            preenchimentoRealizado = true;
        }
      } else {
        console.log(`[SIAGE FILL] Aluno ${nomeAlunoSIAGE} (SIAGE) não encontrado nos dados colados.`);
      }
    });

    if (alunosPreenchidosCount > 0) {
        alert(`Preenchimento de notas concluído para ${alunosPreenchidosCount} aluno(s)! Verifique a página.`);
    } else {
        alert('Nenhum aluno correspondente encontrado ou notas preenchidas. Verifique os nomes e os dados colados.');
    }

  } else if (formularioId === 'formRegistroAulasSIAGE') {
    const aulaParaPreencher = dadosParaPreencher;
    console.log('[SIAGE FILL] Tentando preencher o formulário de aula com os dados:', aulaParaPreencher);

    let metodologiaPrecisaManual = false;
    let camposPreenchidosComSucesso = 0;

    // Ação: Clicar no botão "Registrar Aula" (se ainda não clicado)
    console.log('[SIAGE FILL] Attempting to click "Registrar Aula" button...');
    const registrarAulaButton = await waitForElement('button.btn.btn-primary-dark.rounded-pill.mb-2', 10000); // Aumentar timeout para 10s

    if (registrarAulaButton) {
        registrarAulaButton.click();
        console.log('[SIAGE FILL] Successfully clicked "Registrar Aula" button.');
        // ADICIONADO: Esperar por um elemento CRÍTICO do formulário de aula que aparece APÓS o clique no botão
        // Usaremos o campo de Mês como o marcador de que o formulário está carregado.
        const mesInputLoaded = await waitForElement('p-autocomplete input[placeholder="Selecione"]', 15000);
        if (!mesInputLoaded) {
            console.error('[SIAGE FILL] Campo MÊS não carregou. Abortando preenchimento.');
            alert('Erro: O campo MÊS não apareceu. Verifique a página.');
            return;
        }
        await new Promise(resolve => setTimeout(resolve, 1000));
 // Aumentar timeout para 15s

        if (!mesInputLoaded) {
            console.error('[SIAGE FILL] O formulário de registro de aula não carregou completamente após o clique no botão "Registrar Aula". Interrompendo preenchimento.');
            alert('Erro: O formulário de registro de aula não apareceu ou demorou demais para carregar. Por favor, tente novamente ou preencha manualmente.');
            return; // Sai da função se o formulário não carregou
        }
        console.log('[SIAGE FILL] Formulário de aula carregado e pronto para preenchimento.');
        await new Promise(resolve => setTimeout(resolve, 1000)); // Pequeno delay adicional de segurança
    } else {
        console.warn('[SIAGE FILL] "Registrar Aula" button not found or not connected to DOM. Proceeding with form fill assuming it\'s already open.');
        alert('Atenção: O botão "Registrar Aula" não foi encontrado. Certifique-se de que o formulário de aula já está aberto ou abra-o manualmente.');
        // Se o botão não for encontrado, ainda precisamos esperar pelos campos do formulário
        const mesInputLoaded = await waitForElement('p-autocomplete input[placeholder="Selecione"]', 10000);
        if (!mesInputLoaded) {
             console.error('[SIAGE FILL] O formulário de registro de aula não carregou completamente mesmo sem o clique no botão. Interrompendo preenchimento.');
             alert('Erro: O formulário de registro de aula não apareceu ou demorou demais para carregar. Por favor, tente novamente ou preencha manualmente.');
             return;
        }
         await new Promise(resolve => setTimeout(resolve, 1000));
    }

    // Select month in dropdown
    if (aulaParaPreencher.MÊS) {
      const nomeMes = aulaParaPreencher.MÊS.trim();
      if (nomeMes) {
          console.log(`[SIAGE FILL] Attempting to select month: ${nomeMes}`);
          // GARANTIR QUE O CAMPO DO MÊS ESTÁ PRONTO
          const mesInput = await waitForElement('p-autocomplete input[placeholder="Selecione"]', 5000);

          if (mesInput) {
              try {
                  mesInput.focus();
                  mesInput.value = nomeMes;
                  mesInput.dispatchEvent(new Event('input', { bubbles: true }));
                  console.log(`[SIAGE FILL] Dispatched input event for month: "${nomeMes}".`);

                  // Pequeno atraso para dar tempo ao autocomplete
                  await new Promise(resolve => setTimeout(resolve, 200));

                  mesInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', code: 'ArrowDown', bubbles: true }));
                  console.log('[SIAGE FILL] Dispatched ArrowDown keydown event.');
                  await new Promise(resolve => setTimeout(resolve, 1000));

                  const suggestionList = await waitForElement('ul.ui-autocomplete-items', 3000);

                  if (suggestionList) {
                      const allSuggestionSpans = suggestionList.querySelectorAll('li.ui-autocomplete-list-item span');
                      let foundAndClickedMonth = false;

                      for (const span of allSuggestionSpans) {
                          if (span.textContent.trim().toUpperCase() === nomeMes.toUpperCase()) {
                              const listItem = span.closest('li.ui-autocomplete-list-item');
                              if (listItem && listItem.isConnected) {
                                  try {
                                      listItem.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true, view: window }));
                                      listItem.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
                                      await new Promise(resolve => setTimeout(resolve, 50));
                                      listItem.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
                                      listItem.click();
                                      console.log(`[SIAGE FILL] Month "${nomeMes}" selected via robust click sequence.`);
                                      foundAndClickedMonth = true;
                                      break;
                                  } catch (clickErr) {
                                      console.error('[SIAGE FILL] ERRO AO SIMULAR CLIQUE NA SUGESTÃO DE MÊS:', clickErr);
                                  }
                              }
                          }
                      }
                      
if (!foundAndClickedMonth) {
  console.warn(`[SIAGE FILL] Sugestão para o mês "${nomeMes}" não encontrada na lista suspensa. Tentando forçar clique.`);
  const dropdownBtn = mesInput.parentElement.querySelector('button');
  if (dropdownBtn) {
    dropdownBtn.click();
    await new Promise(resolve => setTimeout(resolve, 500));
  }
  const suggestionList = await waitForElement('ul.ui-autocomplete-items', 5000);
  if (suggestionList) {
    const listItems = suggestionList.querySelectorAll('li.ui-autocomplete-list-item');
    let encontrado = false;
    for (const li of listItems) {
      const span = li.querySelector('span');
      if (span && span.textContent.trim().toUpperCase() === nomeMes.toUpperCase()) {
        li.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
        await new Promise(resolve => setTimeout(resolve, 100));
        const evtOpts = { bubbles: true, cancelable: true, view: window };
        li.dispatchEvent(new MouseEvent('mousedown', evtOpts));
        li.dispatchEvent(new MouseEvent('mouseup', evtOpts));
        li.dispatchEvent(new MouseEvent('click', evtOpts));
        console.log(`[SIAGE FILL] Mês "${nomeMes}" selecionado no autocomplete da pop-up.`);
        encontrado = true;
        break;
      }
    }
    if (!encontrado) {
      console.warn(`[SIAGE FILL] Mês "${nomeMes}" não encontrado na lista de sugestões.`);
    }
  }
}

                  } else {
                      console.warn('[SIAGE FILL] Lista de sugestões para o mês não apareceu a tempo ou não está conectada ao DOM.');
                  }

                  // Add blur then focus to potentially finalize selection for component
                  mesInput.dispatchEvent(new Event('blur', { bubbles: true }));
                  mesInput.focus();
                  console.log('[SIAGE FILL] Dispatched blur/focus events for month input.');

              } catch (e) {
                  console.error(`[SIAGE FILL] ERRO AO MANIPULAR CAMPO DE MÊS para "${nomeMes}":`, e);
              }
              await new Promise(resolve => setTimeout(resolve, 1000));
          } else {
              console.warn('[SIAGE FILL] Campo de seleção de Mês (p-autocomplete input[placeholder="Selecione"]) não encontrado ou não está conectado ao DOM.');
          }
      } else {
          console.warn('[SIAGE FILL] Campo "MÊS" está vazio. Não foi possível preencher o mês.');
      }
    }

    







// FLUXO FINAL USANDO CONTEXTO DA POP-UP PARA SELETOR DO CAMPO DE MÊS
if (aulaParaPreencher.DIA && aulaParaPreencher.MÊS) {
    const nomeMes = aulaParaPreencher.MÊS.trim();
    const diaSelecionado = parseInt(aulaParaPreencher.DIA.trim(), 10);
    const numeroMes = getNumeroMes(nomeMes);
    const anoAtual = new Date().getFullYear();

    if (!numeroMes || isNaN(diaSelecionado)) {
        console.warn('[SIAGE FILL] Mês ou Dia inválidos para preenchimento do calendário.');
    } else {
        // 0. Aguardar campo de mês visível na pop-up (contextualizado dentro do diálogo)
        const mesInput = await waitForElement('#mes > span > input.ui-autocomplete-input[placeholder="Selecione"]', 10000);
        if (mesInput) {
            mesInput.focus();
            mesInput.value = nomeMes;
            mesInput.dispatchEvent(new Event('input', { bubbles: true }));

            const dropdownBtn = mesInput.parentElement.querySelector('button');
            if (dropdownBtn) {
                dropdownBtn.click(); // força abrir o painel
                await new Promise(resolve => setTimeout(resolve, 500));
            }

            const suggestionList = await waitForElement('ul.ui-autocomplete-items', 5000);
            if (suggestionList) {
                const listItems = suggestionList.querySelectorAll('li.ui-autocomplete-list-item');
                let encontrado = false;
                for (const li of listItems) {
                    const span = li.querySelector('span');
                    if (span && span.textContent.trim().toUpperCase() === nomeMes.toUpperCase()) {
                        li.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
                        await new Promise(resolve => setTimeout(resolve, 100));
                        
const evtOpts = { bubbles: true, cancelable: true, view: window };
li.dispatchEvent(new MouseEvent('mousedown', evtOpts));
li.dispatchEvent(new MouseEvent('mouseup', evtOpts));
li.dispatchEvent(new MouseEvent('click', evtOpts));

                        console.log(`[SIAGE FILL] Mês "${nomeMes}" selecionado no autocomplete da pop-up.`);
                        encontrado = true;
                        break;
                    }
                }
                if (!encontrado) {
                    console.warn(`[SIAGE FILL] Mês "${nomeMes}" não encontrado na lista de sugestões.`);
                }
            } else {
                console.warn('[SIAGE FILL] Lista de sugestões de mês não encontrada.');
            }
        } else {
            console.warn('[SIAGE FILL] Campo de MÊS da pop-up não encontrado. A pop-up pode não ter carregado.');
        }

        // 2. Esperar atualização do calendário e simular clique duplo no dia
        await new Promise(resolve => setTimeout(resolve, 1500));
        const calendarioDias = document.querySelectorAll('div.calendario-dia');
        let clicado = false;
        for (const diaDiv of calendarioDias) {
            const dia = parseInt(diaDiv.textContent.trim(), 10);
            if (dia === diaSelecionado) {
                const eventOpts = { bubbles: true, cancelable: true, view: window };
                diaDiv.dispatchEvent(new MouseEvent('mousedown', eventOpts));
                diaDiv.dispatchEvent(new MouseEvent('mouseup', eventOpts));
                diaDiv.dispatchEvent(new MouseEvent('click', eventOpts));
                diaDiv.dispatchEvent(new MouseEvent('click', eventOpts)); // clique duplo
                clicado = true;
                console.log(`[SIAGE FILL] Dia ${diaSelecionado} clicado no calendário.`);
                break;
            }
        }

        if (!clicado) {
            console.warn(`[SIAGE FILL] Dia ${diaSelecionado} não encontrado no calendário.`);
        } else {
            // 3. Aguardar botão REGISTRAR e clicar com scrollIntoView
            const registrarBtn = document.querySelector('button.btn.rounded-pill.btn-primary.mb-2.ng-star-inserted');
            if (registrarBtn) {
                registrarBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
                await new Promise(resolve => setTimeout(resolve, 200));

const evtOpts = { bubbles: true, cancelable: true, view: window };
registrarBtn.dispatchEvent(new MouseEvent('mousedown', evtOpts));
registrarBtn.dispatchEvent(new MouseEvent('mouseup', evtOpts));
registrarBtn.dispatchEvent(new MouseEvent('click', evtOpts));
                console.log('[SIAGE FILL] Botão REGISTRAR clicado após seleção do dia.');
                await new Promise(resolve => setTimeout(resolve, 2000)); // aguarda formulário carregar
            } else {
                console.warn('[SIAGE FILL] Botão REGISTRAR não encontrado após clique no dia.');
            }
        }
    }
} else {
    console.warn('[SIAGE FILL] Campos DIA ou MÊS ausentes. Não é possível simular clique no calendário.');
}


// Preenchimento do Modo de Aula// Preenchimento do Modo de Aula// Preenchimento do Modo de Aula// Preenchimento do Modo de Aula// Preenchimento do Modo de Aula// Preenchimento do Modo de Aula// Preenchimento do Modo de Aula// Preenchimento do Modo de Aula// Preenchimento do Modo de Aula
    if (aulaParaPreencher.Modo) {
        const modo = aulaParaPreencher.Modo.trim().toUpperCase();
        let radioInput = null;
        if (modo === 'AULA') {
            // GARANTIR QUE O CAMPO DE MODO ESTÁ PRONTO
            radioInput = await waitForElement('input#option-AULA', 5000);
        } else if (modo === 'AVALIAÇÃO') {
            // GARANTIR QUE O CAMPO DE MODO ESTÁ PRONTO
            radioInput = await waitForElement('input#option-AVALIACAO', 5000);
        }

        if (radioInput) {
            radioInput.click();
            radioInput.dispatchEvent(new Event('change', { bubbles: true }));
            console.log(`[SIAGE FILL] Modo de Aula selecionado: ${aulaParaPreencher.Modo}`);
            camposPreenchidosComSucesso++;
        } else {
            console.warn(`[SIAGE FILL] Opção de Modo de Aula "${aulaParaPreencher.Modo}" não encontrada ou não está conectada ao DOM.`);
        }
    }

    // Preenchimento do Tipo de Aula
    if (aulaParaPreencher.Tipo) {
        const tipo = aulaParaPreencher.Tipo.trim().toUpperCase();
        let radioInput = null;
        if (tipo === 'PLANO DE ENSINO') {
            // GARANTIR QUE O CAMPO DE TIPO ESTÁ PRONTO
            radioInput = await waitForElement('input#option-PLANO_DE_ENSINO', 5000);
        } else if (tipo === 'AVULSO') {
            // GARANTIR QUE O CAMPO DE TIPO ESTÁ PRONTO
            radioInput = await waitForElement('input#option-AVULSO', 5000);
        }

        if (radioInput) {
            radioInput.click();
            radioInput.dispatchEvent(new Event('change', { bubbles: true }));
            console.log(`[SIAGE FILL] Tipo de Aula selecionado: ${aulaParaPreencher.Tipo}`);
            camposPreenchidosComSucesso++;
        } else {
            console.warn(`[SIAGE FILL] Opção de Tipo de Aula "${aulaParaPreencher.Tipo}" não encontrada ou não está conectada ao DOM.`);
        }
    }

    // Preenchimento do Conteúdo
    if (aulaParaPreencher.Conteúdo) {
        // GARANTIR QUE O CAMPO DE CONTEÚDO ESTÁ PRONTO
        const campoConteudo = await waitForElement('textarea#textarea-objetosConhecimento', 5000);
        if (campoConteudo) {
            campoConteudo.value = aulaParaPreencher.Conteúdo.trim();
            campoConteudo.dispatchEvent(new Event('input', { bubbles: true }));
            campoConteudo.dispatchEvent(new Event('change', { bubbles: true }));
            console.log(`[SIAGE FILL] Preenchido Conteúdo.`);
            camposPreenchidosComSucesso++;
        } else {
            console.warn('[SIAGE FILL] Campo de Conteúdo (textarea-objetosConhecimento) não encontrado ou não está conectado ao DOM.');
        }
    }

    // Preenchimento de Metodologia (usando async/await para sequenciar e maior robustez)
    if (aulaParaPreencher.Metodologia) {
        const metodologias = aulaParaPreencher.Metodologia.split('\n').map(m => m.trim()).filter(m => m !== '');
        const numMetodologias = metodologias.length;

        if (numMetodologias > 0) {
            // GARANTIR QUE O CAMPO DE METODOLOGIA ESTÁ PRONTO
            const campoMetodologiaInput = await waitForElement('p-autocomplete#metodologia input.ui-autocomplete-input', 5000);

            if (campoMetodologiaInput) {
                console.log('[SIAGE FILL] Tentando preencher Metodologia(s)...');

                for (const metodologiaAtual of metodologias) {
                    if (!metodologiaAtual) continue;

                    console.log(`  [SIAGE FILL] Processing methodology: "${metodologiaAtual}"`);
                    try {
                        campoMetodologiaInput.focus();
                        campoMetodologiaInput.value = metodologiaAtual;
                        campoMetodologiaInput.dispatchEvent(new Event('input', { bubbles: true }));
                        campoMetodologiaInput.dispatchEvent(new Event('change', { bubbles: true }));
                        console.log(`  [SIAGE FILL] Dispatched input/change events for "${metodologiaAtual}".`);
                    } catch (e) {
                        console.error(`[SIAGE FILL] ERRO AO MANIPULAR CAMPO DE METODOLOGIA para "${metodologiaAtual}":`, e);
                        metodologiaPrecisaManual = true; // Mark that manual intervention might be needed
                        continue; // Skip to the next methodology
                    }

                    // Wait for suggestions to appear
                    const suggestionList = await waitForElement('ul.ui-autocomplete-items', 3000); // 3 seconds timeout for suggestions
                    let foundAndClicked = false;

                    if (suggestionList) {
                        const allSuggestionSpans = suggestionList.querySelectorAll('li.ui-autocomplete-list-item span');
                        console.log(`  [SIAGE FILL] Found ${allSuggestionSpans.length} suggestions.`);

                        for (const span of allSuggestionSpans) {
                            if (span.textContent.trim().toUpperCase() === metodologiaAtual.toUpperCase()) {
                                const listItem = span.closest('li.ui-autocomplete-list-item');
                                if (listItem && listItem.isConnected) {
                                    try {
                                        listItem.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true, view: window }));
                                        listItem.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
                                        await new Promise(resolve => setTimeout(resolve, 50));
                                        listItem.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
                                        listItem.click();
                                        console.log(`  [SIAGE FILL] Metodologia "${metodologiaAtual}" selecionada por eventos de clique/mouse.`);
                                        foundAndClicked = true;
                                        break;
                                    } catch (clickErr) {
                                        console.error('[SIAGE FILL] ERRO AO SIMULAR CLIQUE NA SUGESTÃO DE METODOLOGIA:', clickErr);
                                    }
                                }
                            }
                        }
                    } else {
                        console.warn('[SIAGE FILL] Lista de sugestões de Metodologia não apareceu a tempo ou não está conectada ao DOM.');
                    }

                    if (!foundAndClicked) {
                        console.warn(`  [SIAGE FILL] Sugestão para "${metodologiaAtual}" não encontrada na lista suspensa. Tentando simular Enter.`);
                        metodologiaPrecisaManual = true; // Mark for manual check
                        try {
                            campoMetodologiaInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true, composed: true }));
                            campoMetodologiaInput.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', bubbles: true, composed: true }));
                            campoMetodologiaInput.dispatchEvent(new Event('change', { bubbles: true })); // Ensure change event after enter
                            console.log(`  [SIAGE FILL] Simulado Enter para "${metodologiaAtual}".`);
                        } catch (keyErr) {
                            console.error('[SIAGE FILL] ERRO AO SIMULAR ENTER PARA METODOLOGIA:', keyErr);
                        }
                    }
                    await new Promise(resolve => setTimeout(resolve, 1000)); // Atraso entre metodologias
                }
                camposPreenchidosComSucesso++; // Conta o preenchimento de metodologia como sucesso se houve tentativa.
            } else {
                console.warn('[SIAGE FILL] Campo de Metodologia (p-autocomplete#metodologia input.ui-autocomplete-input) não encontrado ou não está conectado ao DOM. Preenchimento manual necessário.');
                metodologiaPrecisaManual = true;
            }
        }
    }

    // Preenchimento de Observações
    if (aulaParaPreencher.Observações) {
        // GARANTIR QUE O CAMPO DE OBSERVAÇÕES ESTÁ PRONTO
        const campoObservacoes = await waitForElement('textarea#observacoes', 5000);
        if (campoObservacoes) {
            campoObservacoes.value = aulaParaPreencher.Observações.trim();
            campoObservacoes.dispatchEvent(new Event('input', { bubbles: true }));
            campoObservacoes.dispatchEvent(new Event('change', { bubbles: true }));
            console.log(`[SIAGE FILL] Preenchidas Observações.`);
            camposPreenchidosComSucesso++;
        } else {
            console.warn('[SIAGE FILL] Campo de Observações (observacoes) não encontrado ou não está conectado ao DOM.');
        }
    }

    // Clicar no botão Salvar
    // GARANTIR QUE O BOTÃO SALVAR ESTÁ PRONTO
    const saveAulaButton = await waitForElement('button[type="submit"].btn-primary', 5000) ||
                         await waitForElement('button:not([disabled]):contains("Salvar")', 5000) ||
                         await waitForElement('button#btnSalvarAula', 5000);

    if (saveAulaButton) {
        if (!saveAulaButton.disabled && saveAulaButton.offsetParent !== null) {
            saveAulaButton.click();
            console.log(`[SIAGE FILL] Clicou no botão Salvar do SIAGE.`);

            await new Promise(resolve => setTimeout(resolve, 2000)); // Espera após salvar
        } else {
            console.warn('[SIAGE FILL] Botão Salvar do SIAGE encontrado, mas está desabilitado ou invisível. O professor precisará salvar manualmente.');
            alert("Atenção: O botão 'Salvar' do SIAGE foi encontrado, mas está desabilitado ou invisível. Por favor, salve a aula manualmente após o preenchimento.");
        }
    } else {
        console.warn('[SIAGE FILL] Botão Salvar do SIAGE não encontrado ou não está conectado ao DOM. O professor precisará salvar manualmente.');
        alert("Atenção: O botão 'Salvar' do SIAGE não foi encontrado. Por favor, salve a aula manualmente após o preenchimento.");
    }

    // Remove a aula preenchida da lista e salva o restante
    let aulasSalvas = await new Promise(resolve => {
        chrome.storage.local.get(["aulasParaPreencher"], function(result) {
            resolve(result.aulasParaPreencher || []);
        });
    });

    if (aulasSalvas.length > 0) {
        aulasSalvas.shift(); // Remove a primeira aula do array (que acabamos de tentar preencher)
    }

    await new Promise(resolve => {
        chrome.storage.local.set({ aulasParaPreencher: aulasSalvas }, function() {
            console.log('[SIAGE FILL] Aula preenchida removida do armazenamento. Aulas restantes:', aulasSalvas.length);
            resolve();
        });
    });

// Atualiza os campos visuais da caixa de diálogo (UI) após remover a primeira aula
    const formElement = document.getElementById('formRegistroAulasSIAGE');
    if (formElement) {
      const textareas = formElement.querySelectorAll('textarea');
      textareas.forEach(textarea => {
        const lines = textarea.value.split('\n');
        const primeiraLinha = lines.shift(); // remove a primeira linha preenchida
        textarea.value = lines.join('\n'); // atualiza a textarea
        textarea.dispatchEvent(new Event('input', { bubbles: true }));
        textarea.dispatchEvent(new Event('change', { bubbles: true }));
      });
    }

    // Atualizar contador após preenchimento
    atualizarContadorAulas();

    // Alerta final
    if (camposPreenchidosComSucesso > 0 && !metodologiaPrecisaManual) {
        alert(`Preenchimento da aula concluído! Há ${aulasSalvas.length} aula(s) restante(s) para preencher. Para preencher a próxima, reabra a caixa de diálogo da extensão.`);
    } else if (camposPreenchidosComSucesso > 0 && metodologiaPrecisaManual) {
        alert(`Preenchimento da aula concluído! ATENÇÃO: Verifique o campo Metodologia, pois ele pode precisar de seleção manual se alguma sugestão não for encontrada. Há ${aulasSalvas.length} aula(s) restante(s). Para preencher a próxima, reabra a caixa de diálogo da extensão.`);
    } else {
        alert(`Nenhum campo para a aula foi preenchido no SIAGE. Verifique se o formulário de aula está aberto e os dados estão corretos. Há ${aulasSalvas.length} aula(s) restante(s). Reabra a caixa para ver a lista atualizada.`);
    }
  }
}



function abrirFormularioNotas() {
    console.log('[content-notas] abrirFormularioNotas chamada.');

  if (isUINotasOpen) {
    console.log('[ACTION] Notas UI already open. Bringing to front.');
    const existingForm = document.getElementById('formRegistroNotasSIAGE');
    if (existingForm) {
      existingForm.style.zIndex = 2147483647; // Traz para frente
      existingForm.style.pointerEvents = 'auto'; // Garante que é clicável
    }
    return;
  }
  console.log('[ACTION] Opening Notas form...');
  criarCaixa(
    'formRegistroNotasSIAGE',
    'REGISTRO DE NOTAS', // Título para a caixa de diálogo
    ["ALUNO", "NOTA 1", "REC 1", "NOTA 2", "REC 2", "NOTA 3", "REC 3"]
  );
  isUINotasOpen = true; // Define a flag como true após criar a caixa
}

console.log('[content-notas] Módulo de notas carregado e função criarCaixa disponível.');
