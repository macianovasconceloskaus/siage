// content-sync.js - v1.9
// Modulo de sincronizacao com o Painel Web SIAGE via CLIPBOARD
// O professor clica "Enviar para Extensao" no painel (copia para clipboard)
// e a extensao le o clipboard e preenche o formulario automaticamente

(function() {
  'use strict';

  console.log('[SYNC] Modulo de sincronizacao via clipboard carregado v1.9');

  // ============================================================
  // LER CLIPBOARD E PREENCHER FORMULARIOS
  // ============================================================

  /**
   * Le o conteudo do clipboard e tenta interpretar como dados de aulas
   */
  async function lerClipboard() {
    try {
      const texto = await navigator.clipboard.readText();
      console.log('[SYNC] Clipboard lido:', texto.substring(0, 200) + (texto.length > 200 ? '...' : ''));
      return texto.trim();
    } catch (err) {
      console.error('[SYNC] Erro ao ler clipboard:', err);
      throw new Error('Nao foi possivel ler o clipboard. Certifique-se de que copiou os dados do painel (clique "Enviar para Extensao" no calendario) e de que deu permissao de clipboard para a extensao.');
    }
  }

  /**
   * Parseia o texto do clipboard em linhas de dados
   * Formato esperado (tab-separated do painel):
   * data\tdia_semana\tquantidade\tmodo_aula\ttipo_aula\tobjetos_conhecimento\tmetodologia\tobservacoes
   */
  function parsearDadosAulas(texto) {
    const linhas = texto.split('\n').filter(l => l.trim());
    const aulas = [];

    for (const linha of linhas) {
      const cols = linha.split('\t');
      if (cols.length >= 6) {
        aulas.push({
          data: cols[0]?.trim() || '',
          dia_semana: cols[1]?.trim() || '',
          quantidade: parseInt(cols[2]?.trim()) || 1,
          modo_aula: cols[3]?.trim() || 'Aula',
          tipo_aula: cols[4]?.trim() || 'Avulso',
          objetos_conhecimento: cols[5]?.trim() || 'Aula realizada de acordo com o plano competente.',
          metodologia: cols[6]?.trim() || 'Aula dialogada',
          observacoes: cols[7]?.trim() || ''
        });
      }
    }

    return aulas;
  }

  /**
   * Parseia o texto do clipboard em dados de frequencias
   * Formato esperado:
   * data\ttempos
   */
  function parsearDadosFrequencias(texto) {
    const linhas = texto.split('\n').filter(l => l.trim());
    const frequencias = [];

    for (const linha of linhas) {
      const cols = linha.split('\t');
      if (cols.length >= 1) {
        frequencias.push({
          data: cols[0]?.trim() || '',
          tempos: cols[1]?.trim() || '1,2'
        });
      }
    }

    return frequencias;
  }

  // ============================================================
  // FORMATAR DADOS PARA FORMULARIOS
  // ============================================================

  function formatarParaFormularioAulas(aulas) {
    const nomeMes = (n) => {
      const mesesPt = ['Janeiro','Fevereiro','Marco','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
      return mesesPt[n - 1];
    };

    const meses = [], dias = [], modos = [], tipos = [], conteudos = [], metodologias = [], observacoesList = [];

    for (const aula of aulas) {
      const dataStr = aula.data || '';
      let dia, mes;

      if (dataStr.includes('/')) {
        const parts = dataStr.split('/');
        dia = parts[0];
        mes = nomeMes(parseInt(parts[1], 10));
      } else if (dataStr.includes('-')) {
        const parts = dataStr.split('-');
        dia = parts[2];
        mes = nomeMes(parseInt(parts[1], 10));
      } else {
        dia = dataStr;
        mes = '';
      }

      meses.push(mes);
      dias.push(dia);
      modos.push(aula.modo_aula || '');
      tipos.push(aula.tipo_aula || '');
      conteudos.push(aula.objetos_conhecimento || '');
      metodologias.push(aula.metodologia || '');
      observacoesList.push(aula.observacoes || '');
    }

    return {
      mes: meses.join('\n'),
      dias: dias.join('\n'),
      modo: modos.join('\n'),
      tipo: tipos.join('\n'),
      conteudo: conteudos.join('\n'),
      metodologia: metodologias.join('\n'),
      observacoes: observacoesList.join('\n')
    };
  }

  function formatarParaFormularioFrequencia(frequencias) {
    const datas = [];
    const tempos = [];

    for (const f of frequencias) {
      datas.push(f.data || '');
      tempos.push(f.tempos || '1,2');
    }

    return { datas: datas.join('\n'), tempos: tempos.join('\n') };
  }

  // ============================================================
  // PREENCHER FORMULARIOS VIA CLIPBOARD
  // ============================================================

  /**
   * Detecta se o clipboard contem dados de aulas ou frequencias
   * baseado no numero de colunas (tabs) na primeira linha.
   * @returns {'aulas'|'frequencias'|'desconhecido'}
   */
  function detectarFormatoClipboard(texto) {
    const linhas = texto.split('\n').filter(l => l.trim());
    if (linhas.length === 0) return 'desconhecido';
    
    const primeiraLinha = linhas[0];
    const numColunas = primeiraLinha.split('\t').length;
    
    console.log(`[SYNC] Detectando formato: ${numColunas} colunas na primeira linha`);
    
    if (numColunas >= 6) return 'aulas';        // Aulas: 8 colunas (data, dia, qtd, modo, tipo, conteudo, metodologia, obs)
    if (numColunas >= 2 && numColunas <= 3) return 'frequencias'; // Frequencias: 2 colunas (data, tempos)
    return 'desconhecido';
  }

  /**
   * Preenche o formulario de aulas lendo do clipboard
   * Interpreta como formato de AULAS (8 colunas tab-separated)
   */
  async function preencherFormularioAulasDoPainel() {
    try {
      mostrarNotificacaoSync('Lendo dados do clipboard...', 'info');

      const texto = await lerClipboard();
      if (!texto) {
        mostrarNotificacaoSync('Clipboard vazio. Va no painel web e clique "Copiar Aulas" para copiar os dados.', 'aviso');
        return;
      }

      const aulas = parsearDadosAulas(texto);
      console.log('[SYNC] Aulas parseadas do clipboard:', aulas.length);

      if (aulas.length === 0) {
        mostrarNotificacaoSync('Nenhuma aula encontrada no clipboard. Va no painel e clique "Copiar Aulas".', 'aviso');
        return;
      }

      const formatado = formatarParaFormularioAulas(aulas);

      // Preenche os campos do formulario
      const campos = {
        'mes': formatado.mes,
        'dias': formatado.dias,
        'modo': formatado.modo,
        'tipo': formatado.tipo,
        'conteudo': formatado.conteudo,
        'metodologia': formatado.metodologia,
        'observacoes': formatado.observacoes
      };

      for (const [id, valor] of Object.entries(campos)) {
        const el = document.getElementById(id);
        if (el) {
          el.value = valor;
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }

      // Atualiza contadores
      atualizarContadoresAulasFromSync(aulas.length);

      mostrarNotificacaoSync(
        aulas.length + ' aula(s) carregada(s) do clipboard! Clique em "Iniciar registro de aulas" para comecar.',
        'sucesso'
      );
      console.log('[SYNC] Formulario de aulas preenchido via clipboard com', aulas.length, 'aulas');

    } catch (err) {
      console.error('[SYNC] Erro:', err);
      mostrarNotificacaoSync('Erro: ' + err.message, 'erro');
    }
  }

  /**
   * Preenche o formulario de frequencia lendo do clipboard
   * Interpreta como formato de FREQUENCIAS (2 colunas: data + tempos)
   */
  async function preencherFormularioFrequenciaDoPainel() {
    try {
      mostrarNotificacaoSync('Lendo dados do clipboard...', 'info');

      const texto = await lerClipboard();
      console.log('[SYNC] === CLIPBOARD RAW ===');
      console.log(texto);
      console.log('[SYNC] === FIM CLIPBOARD ===');
      
      if (!texto) {
        mostrarNotificacaoSync('Clipboard vazio. Va no painel e clique "Copiar Frequencias".', 'aviso');
        return;
      }

      const frequencias = parsearDadosFrequencias(texto);
      console.log('[SYNC] Frequencias parseadas:', frequencias);

      if (frequencias.length === 0) {
        mostrarNotificacaoSync('Nenhuma frequencia encontrada no clipboard. Va no painel e clique "Copiar Frequencias".', 'aviso');
        return;
      }

      const formatado = formatarParaFormularioFrequencia(frequencias);

      const elDatas = document.getElementById('freq-datas');
      const elTempos = document.getElementById('freq-tempos');

      if (elDatas) {
        elDatas.value = formatado.datas;
        elDatas.dispatchEvent(new Event('input', { bubbles: true }));
      }
      if (elTempos) {
        elTempos.value = formatado.tempos;
        elTempos.dispatchEvent(new Event('input', { bubbles: true }));
      }

      // Atualiza contadores
      atualizarContadoresFrequenciaFromSync(frequencias.length);

      mostrarNotificacaoSync(
        frequencias.length + ' frequencia(s) carregada(s) do clipboard!',
        'sucesso'
      );
      console.log('[SYNC] Formulario de frequencia preenchido via clipboard com', frequencias.length, 'registros');

    } catch (err) {
      console.error('[SYNC] Erro:', err);
      mostrarNotificacaoSync('Erro: ' + err.message, 'erro');
    }
  }

  // ============================================================
  // ATUALIZAR CONTADORES
  // ============================================================

  function atualizarContadoresAulasFromSync(total) {
    const elReg = document.getElementById('aulas-registradas');
    const elRest = document.getElementById('aulas-restantes');
    if (elReg) elReg.textContent = '0';
    if (elRest) elRest.textContent = total;
  }

  function atualizarContadoresFrequenciaFromSync(total) {
    const elReg = document.getElementById('freq-registradas');
    const elRest = document.getElementById('freq-restantes');
    if (elReg) elReg.textContent = '0';
    if (elRest) elRest.textContent = total;
  }

  // ============================================================
  // NOTIFICACOES VISUAIS
  // ============================================================

  let _notifTimeout = null;

  function mostrarNotificacaoSync(mensagem, tipo) {
    const antiga = document.getElementById('siage-sync-notificacao');
    if (antiga) antiga.remove();
    if (_notifTimeout) clearTimeout(_notifTimeout);

    const cores = {
      sucesso: { bg: '#d4edda', cor: '#155724', borda: '#c3e6cb', icone: '&#9989;' },
      erro:    { bg: '#f8d7da', cor: '#721c24', borda: '#f5c6cb', icone: '&#10060;' },
      aviso:   { bg: '#fff3cd', cor: '#856404', borda: '#ffeaa7', icone: '&#9888;' },
      info:    { bg: '#d1ecf1', cor: '#0c5460', borda: '#bee5eb', icone: '&#128161;' }
    };

    const estilo = cores[tipo] || cores.info;

    const div = document.createElement('div');
    div.id = 'siage-sync-notificacao';
    div.style.cssText = `
      position: fixed; top: 20px; left: 50%; transform: translateX(-50%);
      background: ${estilo.bg}; color: ${estilo.cor}; border: 1px solid ${estilo.borda};
      padding: 14px 24px; border-radius: 14px; font-family: 'Segoe UI', Arial, sans-serif;
      font-size: 0.92em; font-weight: 500; z-index: 2147483647;
      box-shadow: 0 8px 32px rgba(0,0,0,0.15); max-width: 480px;
      text-align: center; animation: syncNotifSlide 0.3s ease;
      backdrop-filter: blur(10px);
    `;
    div.innerHTML = `<span style="margin-right:8px;">${estilo.icone}</span> ${mensagem}`;

    const cssAnims = document.createElement('style');
    cssAnims.textContent = `
      @keyframes syncNotifSlide { from { opacity:0; transform: translateX(-50%) translateY(-20px); } to { opacity:1; transform: translateX(-50%) translateY(0); } }
      @keyframes syncNotifFade { from { opacity:1; } to { opacity:0; } }
    `;
    div.appendChild(cssAnims);

    document.body.appendChild(div);

    _notifTimeout = setTimeout(() => {
      div.style.animation = 'syncNotifFade 0.3s ease forwards';
      setTimeout(() => div.remove(), 300);
    }, 5000);
  }

  // ============================================================
  // INJETAR BOTOES
  // ============================================================

  function injetarBotaoAulas() {
    const observer = new MutationObserver(() => {
      const btnBuscar = document.getElementById('btn-buscar-painel-aulas');
      if (btnBuscar && !btnBuscar._syncListener) {
        btnBuscar._syncListener = true;
        btnBuscar.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          preencherFormularioAulasDoPainel();
        });
        console.log('[SYNC] Botao conectado no formulario de aulas');
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function injetarBotaoFrequencia() {
    const observer = new MutationObserver(() => {
      const btnBuscar = document.getElementById('btn-buscar-painel-freq');
      if (btnBuscar && !btnBuscar._syncListener) {
        btnBuscar._syncListener = true;
        btnBuscar.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          preencherFormularioFrequenciaDoPainel();
        });
        console.log('[SYNC] Botao conectado no formulario de frequencia');
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  // ============================================================
  // INICIALIZACAO
  // ============================================================

  injetarBotaoAulas();
  injetarBotaoFrequencia();

  // ============================================================
  // EXPOR FUNCOES GLOBALMENTE
  // ============================================================
  window.siageSync = {
    preencherFormularioAulasDoPainel,
    preencherFormularioFrequenciaDoPainel,
    mostrarNotificacaoSync
  };

  console.log('[SYNC] Modulo pronto (modo clipboard). Funcoes disponiveis em window.siageSync');

})();
