// Variáveis globais para controle das UIs
if (typeof isUIAulasOpen === 'undefined') var isUIAulasOpen = false;
if (typeof isUINotasOpen === 'undefined') var isUINotasOpen = false;
if (typeof isUIFrequenciaOpen === 'undefined') var isUIFrequenciaOpen = false;

(function() {
  const originalAlert = window.alert;
  window.alert = function(msg) {
    if (typeof msg === 'string' && (
        msg.includes("Preenchimento da aula concluído") ||
        msg.includes("Há 0 aula(s) restante(s)")
    )) {
      console.log("Alerta do SIAGE suprimido:", msg);
      return;
    }
    originalAlert(msg);
  };
})();

async function waitForElement(selector, timeout = 5000, interval = 100) {
    const startTime = Date.now();
    while (Date.now() - startTime < timeout) {
        const element = document.querySelector(selector);
        if (element && element.isConnected) {
            return element;
        }
        await new Promise(resolve => setTimeout(resolve, interval));
    }
    console.warn(`[waitForElement] Elemento não encontrado após ${timeout}ms: ${selector}`);
    return null; // Element not found within timeout
}

function makeDraggable(elmnt) {
  let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  const header = elmnt.querySelector('.draggable-header'); // Assumimos que existe um header para arrastar
  if (header) {
    header.onmousedown = dragMouseDown;
  } else {
    elmnt.onmousedown = dragMouseDown; // Se não houver header, arrasta o elemento inteiro
  }

  function dragMouseDown(e) {
    e.preventDefault();
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    document.onmousemove = elementDrag;
  }

  function elementDrag(e) {
    e.preventDefault();
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
    elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
  }

  function closeDragElement() {
    document.onmouseup = null;
    document.onmousemove = null;
  }
}

function handleGridPaste(event, currentTextareaId, textareaElementsMeta, allColumnNames) {
    event.preventDefault();
    const pastedText = event.clipboardData.getData('text');
    const pastedLines = pastedText.split('\n');

    // Determine the column index of the textarea where the paste occurred
    const pastedIntoColumnMeta = textareaElementsMeta.find(meta => meta.id === currentTextareaId);
    if (!pastedIntoColumnMeta) return;

    const startIndex = allColumnNames.indexOf(pastedIntoColumnMeta.name);
    if (startIndex === -1) return;

    // Get the current line index in the textarea where the paste happened
    const currentTextarea = document.getElementById(currentTextareaId);
    const cursorPosition = currentTextarea.selectionStart;
    const currentTextareaValueBeforeCursor = currentTextarea.value.substring(0, cursorPosition);
    const currentLineIndex = currentTextareaValueBeforeCursor.split('\n').length - 1;

    // Build the current state of the "table" from all textareas
    let currentTableData = [];
    const maxLines = Math.max(...textareaElementsMeta.map(meta => {
        const ta = document.getElementById(meta.id);
        return ta ? ta.value.split('\n').length : 0;
    }));

    // Initialize currentTableData with existing content, padding if necessary
    for (let r = 0; r < Math.max(maxLines, currentLineIndex + pastedLines.length); r++) { // Ensure enough rows for pasted data
        currentTableData[r] = [];
        for (let c = 0; c < allColumnNames.length; c++) {
            currentTableData[r][c] = ''; // Initialize with empty strings
        }
    }

    textareaElementsMeta.forEach((meta, colIdx) => {
        const ta = document.getElementById(meta.id);
        if (ta) {
            const taLines = ta.value.split('\n');
            taLines.forEach((lineContent, r) => {
                if (currentTableData[r]) { // Ensure row exists
                    currentTableData[r][colIdx] = lineContent;
                }
            });
        }
    });

    // Overlay pasted data onto the current table data
    pastedLines.forEach((pastedLine, rOffset) => {
        const targetRowIndex = currentLineIndex + rOffset;
        // If a new row is created by paste, initialize it
        if (!currentTableData[targetRowIndex]) {
            currentTableData[targetRowIndex] = [];
            for (let c = 0; c < allColumnNames.length; c++) {
                currentTableData[targetRowIndex][c] = '';
            }
        }

        const pastedCells = pastedLine.split('\t');
        pastedCells.forEach((cellContent, cOffset) => {
            const targetColumnIndex = startIndex + cOffset;
            if (targetColumnIndex < allColumnNames.length) {
                currentTableData[targetRowIndex][targetColumnIndex] = cellContent;
            }
        });
    });

    // Reconstruct textarea values from the updated table data
    textareaElementsMeta.forEach((meta, colIdx) => {
        const ta = document.getElementById(meta.id);
        if (ta) {
            let newTaValueLines = [];
            for (let r = 0; r < currentTableData.length; r++) {
                newTaValueLines.push(currentTableData[r][colIdx] || ''); // Use empty string if cell is undefined
            }
            ta.value = newTaValueLines.join('\n');
            // Dispatch events to ensure UI updates and internal frameworks recognize the change
            ta.dispatchEvent(new Event('input', { bubbles: true }));
            ta.dispatchEvent(new Event('change', { bubbles: true }));
        }
    });
}

function getNumeroMes(nomeMes) {
    const meses = {
        "JANEIRO": 1, "FEVEREIRO": 2, "MARÇO": 3, "ABRIL": 4, "MAIO": 5, "JUNHO": 6,
        "JULHO": 7, "AGOSTO": 8, "SETEMBRO": 9, "OUTUBRO": 10, "NOVEMBRO": 11, "DEZEMBRO": 12
    };
    return meses[nomeMes.toUpperCase()];
}

// --- Função criarCaixa 
function criarCaixa(id, titulo, colunas) {
  // Remove formulário existente
  const existingForm = document.getElementById(id);
  if (existingForm) {
    existingForm.remove();
    console.log(`[UI] Removed existing dialog with ID: ${id}`);
  }

  const form = document.createElement('div');
  form.id = id;
  form.style.cssText = `
    position: fixed;
    top: 100px;
    left: 100px;
    background: #fff;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    z-index: 2147483647;
    max-width: 50%;
    min-width: 200px;
    font-family: 'Arial', sans-serif;
    color: #333;
    display: flex;
    flex-direction: column;
    max-height: 80vh;
    overflow-y: hidden;
  `;

  // Header com título centralizado e botão fechar à direita
  let headerHTML = `
    <div class="draggable-header" style="
      position: relative;
      display: flex;
      width: 100%;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
      cursor: grab;
      font-size: 1rem;
      font-weight: bold;
      color: #0056b3;
    ">
      <div style="
        position: absolute;
        left: 0; right: 0;
        text-align: center;
        font-size: 1.3rem;
        pointer-events: none;
      ">
        ${titulo}
      </div>
      <button id="fechar-caixa-btn" style="
        background-color: #464646ff;
        border: none;
        border-radius: 4px;
        margin-left: auto;
        font-size: 1.5rem;
        font-weight: bold;
        cursor: pointer;
        color: white;
        padding: 1px 6px;
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;
        z-index: 10;
      " aria-label="Fechar">×</button>
    </div>
  `;

  // Wrapper conteúdo textareas
  headerHTML += `<div class="content-wrapper" style="display: flex; flex-wrap: nowrap; flex-grow: 1; overflow-y: auto; font-size: 0.85rem;">`;
  const textareaElementsMeta = [];

  colunas.forEach(nome => {
    const minWidth = (nome === "ALUNO" || nome === "Conteúdo" || nome === "Metodologia" || nome === "Observações") ? '200px' :
                      (nome === "DIA" || nome === "MÊS") ? '60px' : '80px';
    const uniqueId = `textarea-${id}-${nome.replace(/\s+/g, '')}`;

    headerHTML += `
      <div style="
        flex: 1;
        border-right: 1px solid #e0e0e0;
        padding: 10px;
        min-width: ${minWidth};
        max-height: 380px;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
      ">
        <strong style="margin-bottom: 8px; color: #555; font-size: 0.85rem;">${nome}</strong>
        <textarea id="${uniqueId}" class="data-textarea"
                  style="
                    border: 1px solid #bbb;
                    min-height: 100px;
                    max-height: 280px;
                    flex-grow: 1;
                    overflow-y: auto;
                    padding: 8px;
                    background-color: #fcfcfc;
                    white-space: pre-wrap;
                    word-break: break-word;
                    resize: vertical;
                    outline: none;
                    transition: border-color 0.2s;
                    font-family: 'Arial', sans-serif;
                    font-size: 0.75rem;
                  "
                  onfocus="this.style.borderColor='#007bff';"
                  onblur="this.style.borderColor='#bbb';"
        ></textarea>
      </div>
    `;
    textareaElementsMeta.push({ name: nome, id: uniqueId });
  });
  headerHTML += `</div>`; // fecha content-wrapper

  // Container dos botões limpar e preencher lado a lado
  headerHTML += `<br><div style="display: flex; gap: 10px; margin-top: 10px; width: 100%; justify-content: center; align-items: center; ">`;

  if (id === 'formRegistroAulasSIAGE') {
    headerHTML += `<button id="limpar-aulas-btn" class="action-button" data-bg="#dc3545" data-text-color="white" style="flex: 1">LIMPAR</button>`;
    headerHTML += `<button id="preencher-aulas-siage-btn" class="action-button" data-bg="#28a745" data-text-color="white" style="flex: 1">PREENCHER SIAGE (Aulas)</button>`;
  } else if (id === 'formRegistroNotasSIAGE') {
    headerHTML += `<button id="limpar-aulas-btn" class="action-button" style="border: 2px solid black; color: black; backgroundColor: white; flex: 1">LIMPAR CAMPOS</button>`;
    headerHTML += `<button id="preencher-notas-siage-btn" class="action-button" data-bg="#28a745" data-text-color="white" style="flex: 1">PREENCHER SIAGE (Notas)</button>`;
  } else if (id === 'formRegistroFrequenciaSIAGE') {
    headerHTML += `<button id="limpar-aulas-btn" class="action-button" style="border: 2px solid black; color: black; backgroundColor: white; flex: 1">LIMPAR CAMPOS</button>`;
    headerHTML += `<button id="preencher-aulas-siage-btn" class="action-button" data-bg="#17a2b8" data-text-color="white" style="flex: 1">PREENCHER SIAGE (Frequência)</button>`;
  }

  headerHTML += `</div>`;

  // Contador aulas
  headerHTML += `
    <div id="contador-aulas" style="margin-top: 10px; font-size: 0.75rem; color: #555;">
      Carregando status das aulas salvas...
    </div>
  `;

  form.innerHTML = headerHTML;
  document.body.appendChild(form);

  makeDraggable(form);

  // Eventos botões
  form.querySelector('#fechar-caixa-btn').addEventListener('click', () => {
    form.remove();
    if (id === 'formRegistroAulasSIAGE') {
      isUIAulasOpen = false;
    } else if (id === 'formRegistroNotasSIAGE') {
      isUINotasOpen = false;
    } else if (id === 'formRegistroFrequenciaSIAGE') {
      isUIFrequenciaOpen = false;
    }
    console.log(`[UI] Closed dialog with ID: ${id}`);
  });


  const styleModern = document.createElement('style');
  styleModern.textContent = `
    .dialog-box {
      border-radius: 12px !important;
      box-shadow: 0 4px 20px rgba(0,0,0,0.15);
      font-family: 'Segoe UI', sans-serif;
    }
    .dialog-box h2 {
      font-weight: 600;
      color: #2c3e50;
    }
    .dialog-box textarea {
      border-radius: 8px;
      border: 1px solid #ccc;
      padding: 6px 10px;
      font-size: 0.95em;
      resize: vertical;
    }
    .action-button {
      border-radius: 8px !important;
      font-size: 0.85rem;
      transition: background 0.3s ease, transform 0.1s ease;
      cursor: pointer;
    }
    .action-button:hover {
      transform: scale(1.03);
      filter: brightness(1.05);
    }
  `;
  document.head.appendChild(styleModern);

  // Estilo dinâmico para botões
  form.querySelectorAll('.action-button').forEach(button => {
    button.style.cssText += `
      background-color: ${button.dataset.bg};
      color: ${button.dataset.textColor};
      border: none;
      padding: 10px 15px;
      margin: 0; /* margin entre botões é controlado pelo flex container */
      transition: background-color 0.2s ease;
    `;
    button.onmouseover = () => button.style.backgroundColor = darkenColor(button.dataset.bg, -15);
    button.onmouseout = () => button.style.backgroundColor = button.dataset.bg;
  });

  function darkenColor(hex, percent) {
    var f=parseInt(hex.slice(1),16),t=percent<0?0:255,p=percent<0?percent*-1:percent,R=f>>16,G=(f>>8)&0x00FF,B=f&0x0000FF;
    return "#"+(0x1000000+(Math.round((t-R)*p)+R)*0x10000+(Math.round((t-G)*p)+G)*0x100+(Math.round((t-B)*p)+B)).toString(16).slice(1);
  }

  // Eventos textarea para colar
  textareaElementsMeta.forEach(meta => {
    const textarea = document.getElementById(meta.id);
    if (textarea) {
      textarea.addEventListener('paste', (event) => {
        handleGridPaste(event, meta.id, textareaElementsMeta, colunas);
      });
    }
  });

  // Eventos dos botões preencher
  if (id === 'formRegistroAulasSIAGE') {
    form.querySelector('#preencher-aulas-siage-btn').addEventListener('click', () => {
      const dadosParaPreencher = {};
      textareaElementsMeta.forEach(meta => {
        const textarea = document.getElementById(meta.id);
        if (textarea) {
          const lines = textarea.value.split('\n');
          dadosParaPreencher[meta.name] = lines[0] || '';
        }
      });
      preencherDadosNoSIAGE(id, dadosParaPreencher);
    });
  } else if (id === 'formRegistroNotasSIAGE') {
    form.querySelector('#preencher-notas-siage-btn').addEventListener('click', () => {
      const dadosParaPreencher = {};
      textareaElementsMeta.forEach(meta => {
        const textarea = document.getElementById(meta.id);
        if (textarea) {
          dadosParaPreencher[meta.name] = textarea.value;
        }
      });
      preencherDadosNoSIAGE(id, dadosParaPreencher);
    });
  } else if (id === 'formRegistroFrequenciaSIAGE') {
    form.querySelector('#preencher-aulas-siage-btn').addEventListener('click', () => {
      const dadosParaPreencher = {};
      textareaElementsMeta.forEach(meta => {
        const textarea = document.getElementById(meta.id);
        if (textarea) {
          dadosParaPreencher[meta.name] = textarea.value;
        }
      });
      preencherDadosNoSIAGE(id, dadosParaPreencher);
    });
  }

  // Evento limpar aulas
  const limparAulasBtn = form.querySelector('#limpar-aulas-btn');
  if (limparAulasBtn) {
    limparAulasBtn.addEventListener('click', async () => {

      await new Promise(resolve => {
        chrome.storage.local.set({ aulasParaPreencher: [] }, function() {
          console.log('[UI] Todas as aulas salvas foram limpas do armazenamento local.');
          resolve();
        });
      });

      textareaElementsMeta.forEach(meta => {
        const textarea = document.getElementById(meta.id);
        if (textarea) {
          textarea.value = '';
          textarea.dispatchEvent(new Event('input', { bubbles: true }));
          textarea.dispatchEvent(new Event('change', { bubbles: true }));
        }
      });
    });
  }

  // Atualiza contador
  function atualizarContadorAulas() {
    chrome.storage.local.get(["aulasParaPreencher"], function(result) {
      const aulas = result.aulasParaPreencher || [];
      const restante = aulas.length;
      const contadorDiv = document.getElementById("contador-aulas");
      if (contadorDiv) {
        contadorDiv.textContent = `Aulas salvas: ${restante} | A preencher: ${restante > 0 ? 1 : 0}`;
      }
    });
  }

  if (id === 'formRegistroAulasSIAGE') {
    setTimeout(() => {
      atualizarContadorAulas();
    }, 500);
  } else if (id === 'formRegistroNotasSIAGE' || id === 'formRegistroFrequenciaSIAGE') {
    const contadorDiv = document.getElementById("contador-aulas");
    if (contadorDiv) {
      contadorDiv.style.display = 'none';
    }
  }

  if (id === 'formRegistroAulasSIAGE') {
    chrome.storage.local.get(["aulasParaPreencher"], function(result) {
      const aulasSalvas = result.aulasParaPreencher || [];
      if (aulasSalvas.length > 0) {
        console.log('[UI] Carregando aulas salvas:', aulasSalvas);
        textareaElementsMeta.forEach(meta => {
          const textarea = document.getElementById(meta.id);
          if (textarea) {
            let content = '';
            aulasSalvas.forEach(aula => {
              content += (aula[meta.name] || '') + '\n';
            });
            textarea.value = content.trim();
            textarea.dispatchEvent(new Event('input', { bubbles: true }));
            textarea.dispatchEvent(new Event('change', { bubbles: true }));
          }
        });
      } else {
        console.log('[UI] Nenhuma aula salva encontrada.');
      }
    });
  }

  // Injeta CSS unificado INLINE (sincrono - aplica imediatamente)
  if (id === 'formRegistroAulasSIAGE' || id === 'formRegistroNotasSIAGE') {
    injetarCSSUnificado();
  }
}

// Funcao separada para injetar CSS de forma sincrona
function injetarCSSUnificado() {
  const cssId = 'siage-style-unificado';
  if (document.getElementById(cssId)) return; // Ja injetado

  const style = document.createElement('style');
  style.id = cssId;
  style.textContent = `
/* === GLASSMORPHISM - AULAS E NOTAS === */
#formRegistroAulasSIAGE,
#formRegistroNotasSIAGE {
  width: 480px !important; max-width: 90vw !important; max-height: 450px !important;
  min-width: 260px !important; padding: 0 !important;
  border: 1px solid rgba(255,255,255,0.3) !important;
  border-radius: 16px !important;
  box-shadow: 0 8px 32px rgba(0,0,0,0.15), 0 2px 8px rgba(0,0,0,0.1), inset 0 1px 0 rgba(255,255,255,0.2) !important;
  overflow: hidden !important; display: flex !important; flex-direction: column !important;
  font-family: 'Segoe UI', Arial, sans-serif !important;
  position: fixed !important; top: 60px !important; right: 15px !important; left: auto !important;
  background: rgba(255,255,255,0.85) !important;
  backdrop-filter: blur(20px) saturate(180%) !important;
  -webkit-backdrop-filter: blur(20px) saturate(180%) !important;
  animation: glassIn 0.3s cubic-bezier(0.16,1,0.3,1) !important;
}
@keyframes glassIn {
  from { opacity: 0; transform: translateY(-12px) scale(0.95); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}
#formRegistroAulasSIAGE .draggable-header,
#formRegistroNotasSIAGE .draggable-header {
  padding: 10px 16px !important; margin-bottom: 0 !important; border-bottom: 1px solid rgba(255,255,255,0.2) !important;
  cursor: grab !important; font-size: 0.95rem !important; font-weight: 600 !important;
  display: flex !important; align-items: center !important; justify-content: space-between !important;
  position: relative !important; user-select: none !important;
  color: white !important;
}
#formRegistroAulasSIAGE .draggable-header {
  background: linear-gradient(135deg, rgba(0,123,255,0.9), rgba(0,86,179,0.95)) !important;
}
#formRegistroNotasSIAGE .draggable-header {
  background: linear-gradient(135deg, rgba(40,167,69,0.9), rgba(30,126,52,0.95)) !important;
}
#formRegistroAulasSIAGE .draggable-header > div:first-child,
#formRegistroNotasSIAGE .draggable-header > div:first-child {
  position: absolute !important; left: 0 !important; right: 0 !important; top: 50% !important;
  transform: translateY(-50%) !important; text-align: center !important; font-size: 1em !important;
  font-weight: 600 !important; pointer-events: none !important; white-space: nowrap !important;
  text-shadow: 0 1px 2px rgba(0,0,0,0.15) !important;
}
#formRegistroAulasSIAGE #fechar-caixa-btn,
#formRegistroNotasSIAGE #fechar-caixa-btn {
  background: rgba(255,255,255,0.25) !important; border: 1px solid rgba(255,255,255,0.3) !important;
  border-radius: 50% !important; width: 26px !important; height: 26px !important;
  font-size: 1.2em !important; font-weight: bold !important; color: white !important;
  cursor: pointer !important; display: flex !important; align-items: center !important;
  justify-content: center !important; padding: 0 0 2px 0 !important; margin-left: auto !important;
  position: relative !important; z-index: 10 !important; line-height: 1 !important;
  transition: all 0.2s ease !important;
}
#formRegistroAulasSIAGE #fechar-caixa-btn:hover,
#formRegistroNotasSIAGE #fechar-caixa-btn:hover {
  background: rgba(255,255,255,0.45) !important; transform: scale(1.1) !important;
}
#formRegistroAulasSIAGE .content-wrapper,
#formRegistroNotasSIAGE .content-wrapper {
  display: flex !important; flex-wrap: nowrap !important; flex-grow: 1 !important;
  overflow-y: auto !important; font-size: 0.78rem !important; padding: 10px !important;
  background: rgba(248,249,250,0.6) !important; max-height: 240px !important; gap: 2px !important;
}
#formRegistroAulasSIAGE .content-wrapper > div,
#formRegistroNotasSIAGE .content-wrapper > div {
  flex: 1 !important; border-right: 1px solid rgba(0,0,0,0.06) !important;
  padding: 6px 8px !important; min-width: 55px !important; max-height: 220px !important;
  overflow-y: auto !important; display: flex !important; flex-direction: column !important;
}
#formRegistroAulasSIAGE .content-wrapper > div:last-child,
#formRegistroNotasSIAGE .content-wrapper > div:last-child {
  border-right: none !important;
}
#formRegistroAulasSIAGE .content-wrapper strong,
#formRegistroNotasSIAGE .content-wrapper strong {
  margin-bottom: 6px !important; color: #444 !important; font-size: 0.72rem !important;
  font-weight: 700 !important; text-transform: uppercase !important; letter-spacing: 0.3px !important;
}
#formRegistroAulasSIAGE textarea,
#formRegistroNotasSIAGE textarea {
  border: 1px solid rgba(0,0,0,0.08) !important; border-radius: 10px !important; padding: 8px !important;
  font-size: 0.78rem !important; font-family: 'SF Mono', 'Fira Code', monospace !important;
  background: rgba(255,255,255,0.9) !important; min-height: 50px !important; max-height: 180px !important;
  resize: vertical !important; outline: none !important; transition: all 0.2s ease !important;
  box-shadow: inset 0 1px 3px rgba(0,0,0,0.04) !important; color: #333 !important; line-height: 1.4 !important;
}
#formRegistroAulasSIAGE textarea:focus { border-color: rgba(0,123,255,0.5) !important; box-shadow: 0 0 0 3px rgba(0,123,255,0.1), inset 0 1px 3px rgba(0,0,0,0.04) !important; background: rgba(255,255,255,0.98) !important; }
#formRegistroNotasSIAGE textarea:focus { border-color: rgba(40,167,69,0.5) !important; box-shadow: 0 0 0 3px rgba(40,167,69,0.1), inset 0 1px 3px rgba(0,0,0,0.04) !important; background: rgba(255,255,255,0.98) !important; }
#formRegistroAulasSIAGE > div:nth-last-child(3),
#formRegistroNotasSIAGE > div:nth-last-child(3) {
  display: flex !important; gap: 8px !important; padding: 10px 14px !important;
  background: rgba(255,255,255,0.4) !important; border-top: 1px solid rgba(0,0,0,0.06) !important;
}
#formRegistroAulasSIAGE #limpar-aulas-btn,
#formRegistroNotasSIAGE #limpar-aulas-btn {
  background: linear-gradient(135deg, rgba(255,193,7,0.9), rgba(255,167,38,0.95)) !important;
  color: #333 !important; border: none !important; border-radius: 10px !important;
  padding: 8px 16px !important; font-size: 0.8rem !important; font-weight: 600 !important;
  cursor: pointer !important; flex: 1 !important; transition: all 0.2s ease !important;
  box-shadow: 0 2px 8px rgba(255,193,7,0.3) !important; text-align: center !important;
}
#formRegistroAulasSIAGE #limpar-aulas-btn:hover,
#formRegistroNotasSIAGE #limpar-aulas-btn:hover {
  transform: translateY(-1px) !important; box-shadow: 0 4px 12px rgba(255,193,7,0.4) !important;
  filter: brightness(1.05) !important;
}
#formRegistroAulasSIAGE #preencher-aulas-siage-btn,
#formRegistroNotasSIAGE #preencher-notas-siage-btn {
  background: linear-gradient(135deg, rgba(40,167,69,0.9), rgba(32,201,151,0.95)) !important;
  color: white !important; border: none !important; border-radius: 10px !important;
  padding: 8px 16px !important; font-size: 0.8rem !important; font-weight: 600 !important;
  cursor: pointer !important; flex: 1 !important; transition: all 0.2s ease !important;
  box-shadow: 0 2px 8px rgba(40,167,69,0.3) !important; text-align: center !important;
  text-shadow: 0 1px 1px rgba(0,0,0,0.1) !important;
}
#formRegistroAulasSIAGE #preencher-aulas-siage-btn:hover,
#formRegistroNotasSIAGE #preencher-notas-siage-btn:hover {
  transform: translateY(-1px) !important; box-shadow: 0 4px 12px rgba(40,167,69,0.4) !important;
  filter: brightness(1.08) !important;
}
#formRegistroAulasSIAGE #contador-aulas {
  background: rgba(233,236,239,0.6) !important; padding: 8px 14px !important;
  text-align: center !important; font-size: 0.75rem !important; color: #555 !important;
  border-top: 1px solid rgba(0,0,0,0.06) !important; font-weight: 500 !important;
}
#formRegistroNotasSIAGE #contador-aulas { display: none !important; }
`;
  document.head.appendChild(style);
  console.log('[UI] CSS unificado INLINE injetado');
}


// Expor como global
try {
  if (typeof window !== 'undefined') window.criarCaixa = criarCaixa;
} catch(e) {}
