// popup.js - v1.9 SIAGE Auto

document.addEventListener('DOMContentLoaded', function() {

  // ============================================================
  // NAVEGACAO POR ABAS
  // ============================================================
  const tabs = document.querySelectorAll('.tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('ativa'));
      tab.classList.add('ativa');
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('ativa'));
      document.getElementById('tab-' + tab.dataset.tab).classList.add('ativa');
    });
  });

  // ============================================================
  // BOTOES DE ACAO
  // ============================================================
  document.getElementById('abrirAulas').addEventListener('click', () => {
    sendMessageToContentScript('openAulasForm');
  });

  document.getElementById('abrirNotas').addEventListener('click', () => {
    sendMessageToContentScript('openNotasForm');
  });

  document.getElementById('abrirFrequencia').addEventListener('click', () => {
    sendMessageToContentScript('openFrequenciaForm');
  });

  document.getElementById('abrirExecutarTudo').addEventListener('click', () => {
    sendMessageToContentScript('openExecutarTudoForm');
  });

  function sendMessageToContentScript(action) {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      const activeTab = tabs[0];
      if (!activeTab) {
        alert('Nenhuma aba ativa encontrada.');
        return;
      }

      const siageUrlRegex = /^(https?:\/\/(professor\.see\.pb\.gov\.br|.*\.siage\.educacao\.ba\.gov\.br))(\/.*)?$/;
      if (!siageUrlRegex.test(activeTab.url)) {
        alert('Esta extensao funciona apenas em paginas do SIAGE (professor.see.pb.gov.br ou siage.educacao.ba.gov.br).\n\nVoce esta em: ' + activeTab.url);
        return;
      }

      chrome.tabs.sendMessage(activeTab.id, {action: action}, function(response) {
        if (chrome.runtime.lastError) {
          console.error('[POPUP] Erro:', chrome.runtime.lastError.message);
          alert('Erro ao comunicar com a pagina do SIAGE.\n\nSolucao:\n1. Recarregue a pagina do SIAGE (F5)\n2. Tente novamente\n\nErro: ' + chrome.runtime.lastError.message);
        } else {
          console.log('[POPUP] Mensagem entregue com sucesso:', response);
        }
        window.close();
      });
    });
  }

});
