<?php
// api/carregar-aulas.php - Retorna aulas de uma turma+disciplina (JSON para AJAX)
require_once '../config.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario_id'])) { echo json_encode(['status'=>'erro','erro'=>'Nao autenticado']); exit; }
$usuarioId = $_SESSION['usuario_id'];
$turmaId = (int)($_GET['turma'] ?? 0);
$discId = (int)($_GET['disciplina'] ?? 0);

if ($turmaId <= 0 || $discId <= 0) { echo json_encode(['status'=>'erro','erro'=>'Turma e disciplina obrigatorias']); exit; }

if (!tabelaExiste($pdo, 'aulas_professor')) { echo json_encode(['status'=>'erro','erro'=>'Tabela nao existe']); exit; }

$stmt = $pdo->prepare("SELECT a.*, t.nome as turma_nome, d.nome as disc_nome, d.abreviacao as disc_abrev 
    FROM aulas_professor a 
    LEFT JOIN turmas t ON a.turma_id = t.id 
    LEFT JOIN disciplinas d ON a.disciplina_id = d.id 
    WHERE a.usuario_id = ? AND a.turma_id = ? AND a.disciplina_id = ? 
    ORDER BY a.data ASC");
$stmt->execute([$usuarioId, $turmaId, $discId]);
$aulas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Formata aulas
$aulasFmt = [];
$aulasMapJs = []; // Para atualizar o calendario no JS
foreach ($aulas as $a) {
    $dataObj = new DateTime($a['data']);
    $df = $dataObj->format('d/m/Y');
    $aulasFmt[] = [
        'id' => $a['id'],
        'data' => $a['data'],
        'data_formatada' => $df,
        'dia_semana' => $a['dia_semana'],
        'quantidade' => (int)$a['quantidade'],
        'modo_aula' => $a['modo_aula'],
        'tipo_aula' => $a['tipo_aula'],
        'objetos_conhecimento' => $a['objetos_conhecimento'] ?: 'Aula realizada de acordo com o plano competente.',
        'metodologia' => $a['metodologia'],
        'observacoes' => $a['observacoes'] ?: '',
        'tempos' => $a['tempos'] ?: '1,2',
        'periodo' => (int)$a['periodo'],
    ];
    $aulasMapJs[$a['data']] = [
        'id' => $a['id'],
        'quantidade' => (int)$a['quantidade'],
        'modo_aula' => $a['modo_aula'],
        'tipo_aula' => $a['tipo_aula'],
        'objetos_conhecimento' => $a['objetos_conhecimento'] ?: 'Aula realizada de acordo com o plano competente.',
        'metodologia' => $a['metodologia'],
        'observacoes' => $a['observacoes'] ?: '',
        'tempos' => $a['tempos'] ?: '1,2',
    ];
}

// Texto para exportacao (tab-separated)
$textoAulas = '';
$textoFrequencias = '';
foreach ($aulasFmt as $a) {
    $textoAulas .= $a['data_formatada'] . "\t" . $a['dia_semana'] . "\t" . $a['quantidade'] . "\t" . $a['modo_aula'] . "\t" . $a['tipo_aula'] . "\t" . $a['objetos_conhecimento'] . "\t" . $a['metodologia'] . "\t" . $a['observacoes'] . "\n";
    $textoFrequencias .= $a['data_formatada'] . "\t" . $a['tempos'] . "\n";
}

echo json_encode([
    'status' => 'ok',
    'total' => count($aulas),
    'turma_id' => $turmaId,
    'disciplina_id' => $discId,
    'turma_nome' => $aulas[0]['turma_nome'] ?? '',
    'disc_nome' => $aulas[0]['disc_nome'] ?? '',
    'disc_abrev' => $aulas[0]['disc_abrev'] ?? '',
    'aulas' => $aulasFmt,
    'aulas_map' => $aulasMapJs,
    'texto_aulas' => $textoAulas,
    'texto_frequencias' => $textoFrequencias,
], JSON_UNESCAPED_UNICODE);
