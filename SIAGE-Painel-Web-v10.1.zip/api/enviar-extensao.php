<?php
// api/enviar-extensao.php - Endpoint para a extensao buscar aulas (usado pelo botao "Enviar para Extensao")
require_once '../config.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['status'=>'erro','erro'=>'Nao autenticado']);
    exit;
}

$usuarioId = $_SESSION['usuario_id'];

// Recebe JSON
$input = json_decode(file_get_contents('php://input'), true);
$turmaId = (int)($input['turma'] ?? 0);
$discId = (int)($input['disciplina'] ?? 0);

if ($turmaId <= 0 || $discId <= 0) {
    echo json_encode(['status'=>'erro','erro'=>'Turma e disciplina obrigatorias']);
    exit;
}

if (!tabelaExiste($pdo, 'aulas_professor')) {
    echo json_encode(['status'=>'erro','erro'=>'Tabela nao existe']);
    exit;
}

// Busca aulas
$stmt = $pdo->prepare("SELECT a.*, t.nome as turma_nome, d.nome as disc_nome 
    FROM aulas_professor a 
    LEFT JOIN turmas t ON a.turma_id = t.id 
    LEFT JOIN disciplinas d ON a.disciplina_id = d.id 
    WHERE a.usuario_id = ? AND a.turma_id = ? AND a.disciplina_id = ? 
    ORDER BY a.data ASC");
$stmt->execute([$usuarioId, $turmaId, $discId]);
$aulas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Formata para a extensao
$aulasFormatadas = [];
$frequenciasFormatadas = [];

foreach ($aulas as $a) {
    $dataObj = new DateTime($a['data']);
    $dataFmt = $dataObj->format('d/m/Y');
    
    $aulasFormatadas[] = [
        'data' => $dataFmt,
        'dia_semana' => $a['dia_semana'],
        'quantidade' => (int)$a['quantidade'],
        'modo_aula' => $a['modo_aula'],
        'tipo_aula' => $a['tipo_aula'],
        'objetos_conhecimento' => $a['objetos_conhecimento'] ?: 'Aula realizada de acordo com o plano competente.',
        'metodologia' => $a['metodologia'],
        'observacoes' => $a['observacoes'] ?: '',
        'periodo' => (int)$a['periodo'],
    ];
    
    $frequenciasFormatadas[] = [
        'data' => $dataFmt,
        'tempos' => $a['tempos'] ?: '1,2',
    ];
}

echo json_encode([
    'status' => 'ok',
    'total' => count($aulas),
    'turma_id' => $turmaId,
    'disciplina_id' => $discId,
    'aulas' => $aulasFormatadas,
    'frequencias' => $frequenciasFormatadas,
    'texto_aulas' => implode("\n", array_map(fn($a) => 
        $a['data']."\t".$a['dia_semana']."\t".$a['quantidade']."\t".$a['modo_aula']."\t".$a['tipo_aula']."\t".$a['objetos_conhecimento']."\t".$a['metodologia']."\t".$a['observacoes'], 
        $aulasFormatadas
    )),
    'texto_frequencias' => implode("\n", array_map(fn($f) => $f['data']."\t".$f['tempos'], $frequenciasFormatadas)),
], JSON_UNESCAPED_UNICODE);
