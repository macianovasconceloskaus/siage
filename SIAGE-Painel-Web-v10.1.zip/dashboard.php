<?php
require_once 'config.php';
if (!isset($_SESSION['usuario_id'])) { header('Location: index.php'); exit; }
$usuarioId = $_SESSION['usuario_id'];
$usuarioNome = $_SESSION['usuario_nome'] ?? 'Professor';

$stmt = querySegura($pdo, "SELECT api_key FROM usuarios WHERE id = ?", [$usuarioId]);
$usuario = ($stmt !== null) ? $stmt->fetch(PDO::FETCH_ASSOC) : null;
$apiKey = $usuario['api_key'] ?? '';

$totalTurmas = tabelaExiste($pdo, 'turmas') ? fetchColumnSeguro($pdo, "SELECT COUNT(*) FROM turmas WHERE usuario_id = ?", [$usuarioId], 0) : 0;
$totalDisc = tabelaExiste($pdo, 'disciplinas') ? fetchColumnSeguro($pdo, "SELECT COUNT(*) FROM disciplinas WHERE usuario_id = ?", [$usuarioId], 0) : 0;
$totalAulas = tabelaExiste($pdo, 'aulas_professor') ? fetchColumnSeguro($pdo, "SELECT COUNT(*) FROM aulas_professor WHERE usuario_id = ?", [$usuarioId], 0) : 0;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SIAGE Auto - Painel</title><link rel="stylesheet" href="assets/painel.css"></head>
<body>
<div class="container">
<div class="card">
    <div class="header">
        <div><h1>SIAGE Auto</h1><span>Painel de Controle</span></div>
        <a href="logout.php" class="btn btn-vermelho" style="padding:8px 16px;font-size:0.82em;">&#10005; Sair</a>
    </div>
    <div class="card-body">
        <h2 style="color:#333;margin-bottom:20px;font-size:1.15em;">Ola, <?php echo htmlspecialchars($usuarioNome); ?>! &#128075;</h2>

        <div class="cards-dash">
            <div class="card-stat"><div class="numero" style="color:#17a2b8;"><?php echo $totalTurmas; ?></div><div class="label">Turmas</div></div>
            <div class="card-stat"><div class="numero" style="color:#fd7e14;"><?php echo $totalDisc; ?></div><div class="label">Disciplinas</div></div>
            <div class="card-stat"><div class="numero" style="color:#28a745;"><?php echo $totalAulas; ?></div><div class="label">Aulas Cad.</div></div>
        </div>

        <div class="menu">
            <a href="gerenciar-turmas.php" class="btn btn-ciano" style="flex:1;justify-content:center;font-size:1em;padding:14px;">&#128218; Turmas e Disciplinas</a>
            <a href="calendario.php" class="btn btn-ciano" style="flex:1;justify-content:center;font-size:1em;padding:14px;">&#128197; Calendario Letivo</a>
        </div>

        <div class="info-box">
            <strong>&#128161; Como usar:</strong>
            <ol style="margin:10px 0 0 20px;padding:0;line-height:1.8;">
                <li><strong>Cadastre suas turmas</strong> e disciplinas</li>
                <li><strong>Vincule</strong> disciplinas as turmas</li>
                <li>Acesse o <strong>Calendario Letivo</strong></li>
                <li>Selecione <strong>turma + disciplina</strong></li>
                <li><strong>Clique nos dias letivos</strong> do calendario (use Ctrl ou Shift para multi-selecao)</li>
                <li>Preencha os dados da aula e <strong>salve</strong></li>
                <li><strong>Copie</strong> os dados para a extensao SIAGE!</li>
            </ol>
        </div>

        <div style="margin-top:24px;padding:20px;background:rgba(248,249,250,0.6);backdrop-filter:blur(10px);border-radius:14px;border:1px solid rgba(233,236,239,0.8);">
            <strong style="font-size:0.88em;color:#555;">&#128273; API Key:</strong>
            <div class="api-key-box" id="apiKeyBox" style="margin:10px 0;"><?php echo htmlspecialchars($apiKey); ?></div>
            <button class="btn btn-verde" onclick="copiarApiKey()" style="padding:8px 18px;font-size:0.85em;">&#128203; Copiar</button>
        </div>
    </div>
    <div class="rodape">Desenvolvido por <strong style="color:#17a2b8;">Maciano Vasconcelos</strong></div>
</div>
</div>
<script>
function copiarApiKey(){const k=document.getElementById('apiKeyBox').textContent.trim();navigator.clipboard.writeText(k).then(()=>alert('Copiado!')).catch(()=>{const r=document.createRange();r.selectNode(document.getElementById('apiKeyBox'));window.getSelection().removeAllRanges();window.getSelection().addRange(r);document.execCommand('copy');alert('Copiado!');});}
</script>
</body></html>
