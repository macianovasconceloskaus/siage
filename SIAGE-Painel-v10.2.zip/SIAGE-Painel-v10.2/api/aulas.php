<?php
// api/aulas.php - Retorna aulas do professor para a extensao (por turma/disciplina)
require_once '../config.php';
header('Content-Type: application/json; charset=utf-8');

$apiKey = $_SERVER['HTTP_X_API_KEY'] ?? $_GET['api_key'] ?? '';
if (empty($apiKey)) {
    http_response_code(401);
    echo json_encode(['erro' => 'API Key obrigatoria']);
    exit;
}

$stmt = $pdo->prepare("SELECT id, nome FROM usuarios WHERE api_key = ?");
$stmt->execute([$apiKey]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$usuario) {
    http_response_code(403);
    echo json_encode(['erro' => 'API Key invalida']);
    exit;
}

$usuarioId = $usuario['id'];

// Parametros opcionais: turma_id e disciplina_id
$turmaId = (int)($_GET['turma_id'] ?? 0);
$discId = (int)($_GET['disciplina_id'] ?? 0);

// Busca aulas - se nao passar turma/disc, busca todas
$sql = "SELECT a.*, t.nome as turma_nome, d.nome as disc_nome, d.abreviacao as disc_abrev 
        FROM aulas_professor a 
        LEFT JOIN turmas t ON a.turma_id = t.id 
        LEFT JOIN disciplinas d ON a.disciplina_id = d.id 
        WHERE a.usuario_id = ?";
$params = [$usuarioId];

if ($turmaId > 0) {
    $sql .= " AND a.turma_id = ?";
    $params[] = $turmaId;
}
if ($discId > 0) {
    $sql .= " AND a.disciplina_id = ?";
    $params[] = $discId;
}
$sql .= " ORDER BY a.data ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$aulas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Formata para a extensao
$listaSimples = [];
$porTurmaDisc = [];

foreach ($aulas as $a) {
    $dataObj = new DateTime($a['data']);
    $dataFmt = $dataObj->format('d/m/Y');
    
    $item = [
        'data' => $dataFmt,
        'dia_semana' => $a['dia_semana'],
        'quantidade' => (int)$a['quantidade'],
        'modo_aula' => $a['modo_aula'],
        'tipo_aula' => $a['tipo_aula'],
        'objetos_conhecimento' => $a['objetos_conhecimento'] ?: 'Aula realizada de acordo com o plano competente.',
        'metodologia' => $a['metodologia'],
        'observacoes' => $a['observacoes'] ?: '',
        'tempos' => $a['tempos'] ?: '1,2',
        'periodo' => (int)$a['periodo'],
        'enviada' => (int)($a['enviada_extensao'] ?? 0),
        'turma' => $a['turma_nome'],
        'disciplina' => $a['disc_nome'],
        'disc_abrev' => $a['disc_abrev'],
    ];
    $listaSimples[] = $item;
    
    // Agrupa por turma+disciplina
    $chave = $a['turma_nome'] . '|' . $a['disc_nome'];
    if (!isset($porTurmaDisc[$chave])) {
        $porTurmaDisc[$chave] = [
            'turma' => $a['turma_nome'],
            'disciplina' => $a['disc_nome'],
            'disc_abrev' => $a['disc_abrev'],
            'aulas' => []
        ];
    }
    $porTurmaDisc[$chave]['aulas'][] = $item;
}

// Frequencias separadas
$frequencias = [];
foreach ($aulas as $a) {
    $dataObj = new DateTime($a['data']);
    $frequencias[] = [
        'data' => $dataObj->format('d/m/Y'),
        'tempos' => $a['tempos'] ?: '1,2',
        'turma' => $a['turma_nome'],
        'disciplina' => $a['disc_nome'],
    ];
}

echo json_encode([
    'status' => 'ok',
    'total' => count($aulas),
    'usuario' => $usuario['nome'],
    'aulas' => $listaSimples,
    'por_turma_disciplina' => array_values($porTurmaDisc),
    'frequencias' => $frequencias,
], JSON_UNESCAPED_UNICODE);
