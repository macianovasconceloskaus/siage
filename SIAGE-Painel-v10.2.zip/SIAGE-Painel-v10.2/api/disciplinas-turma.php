<?php
// api/disciplinas-turma.php - Retorna disciplinas de uma turma (JSON/AJAX)
require_once '../config.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario_id'])) { echo json_encode([]); exit; }
$usuarioId = $_SESSION['usuario_id'];
$turmaId = (int)($_GET['turma'] ?? 0);

if ($turmaId <= 0 || !tabelaExiste($pdo, 'turma_disciplina')) { echo json_encode([]); exit; }

$disciplinas = fetchAllSeguro($pdo,
    "SELECT d.id, d.nome, d.abreviacao FROM disciplinas d 
     JOIN turma_disciplina td ON d.id = td.disciplina_id 
     WHERE td.turma_id = ? AND td.usuario_id = ? ORDER BY d.nome",
    [$turmaId, $usuarioId]
);

echo json_encode($disciplinas ?: []);
