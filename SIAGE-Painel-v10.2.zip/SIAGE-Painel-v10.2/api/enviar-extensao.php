<?php
// api/enviar-extensao.php - Envia aulas da turma+disciplina selecionada para a extensao
// Por padrao envia apenas aulas NAO enviadas (enviada_extensao=0)
// Parametro opcional: incluir_enviadas=1 para reenviar todas
require_once '../config.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['status'=>'erro','erro'=>'Nao autenticado']);
    exit;
}

$usuarioId = $_SESSION['usuario_id'];

// Recebe JSON
$input = json_decode(file_get_contents('php://input'), true);
$turmaId = (int)($input['turma'] ?? 0);
$discId = (int)($input['disciplina'] ?? 0);
$incluirEnviadas = (int)($input['incluir_enviadas'] ?? 0);

if ($turmaId <= 0 || $discId <= 0) {
    echo json_encode(['status'=>'erro','erro'=>'Turma e disciplina obrigatorias']);
    exit;
}

if (!tabelaExiste($pdo, 'aulas_professor')) {
    echo json_encode(['status'=>'erro','erro'=>'Tabela nao existe']);
    exit;
}

// Verifica se a coluna enviada_extensao existe
$colunaExiste = false;
try {
    $stmt = $pdo->query("SHOW COLUMNS FROM aulas_professor LIKE 'enviada_extensao'");
    $colunaExiste = ($stmt->rowCount() > 0);
} catch (PDOException $e) {
    $colunaExiste = false;
}

// Busca aulas - apenas nao enviadas por padrao
$sql = "SELECT a.*, t.nome as turma_nome, d.nome as disc_nome 
    FROM aulas_professor a 
    LEFT JOIN turmas t ON a.turma_id = t.id 
    LEFT JOIN disciplinas d ON a.disciplina_id = d.id 
    WHERE a.usuario_id = ? AND a.turma_id = ? AND a.disciplina_id = ?";

$params = [$usuarioId, $turmaId, $discId];

// Se a coluna existe e nao quer incluir enviadas, filtra
if ($colunaExiste && !$incluirEnviadas) {
    $sql .= " AND a.enviada_extensao = 0";
}

$sql .= " ORDER BY a.data ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$aulas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Formata para a extensao
$aulasFormatadas = [];
$frequenciasFormatadas = [];

foreach ($aulas as $a) {
    $dataObj = new DateTime($a['data']);
    $dataFmt = $dataObj->format('d/m/Y');
    
    $aulasFormatadas[] = [
        'data' => $dataFmt,
        'dia_semana' => $a['dia_semana'],
        'quantidade' => (int)$a['quantidade'],
        'modo_aula' => $a['modo_aula'],
        'tipo_aula' => $a['tipo_aula'],
        'objetos_conhecimento' => $a['objetos_conhecimento'] ?: 'Aula realizada de acordo com o plano competente.',
        'metodologia' => $a['metodologia'],
        'observacoes' => $a['observacoes'] ?: '',
        'periodo' => (int)$a['periodo'],
        'enviada' => $colunaExiste ? (int)$a['enviada_extensao'] : 0,
    ];
    
    $frequenciasFormatadas[] = [
        'data' => $dataFmt,
        'tempos' => $a['tempos'] ?: '1,2',
    ];
}

// Marca as aulas como enviadas (se a coluna existe)
$marcadas = 0;
if ($colunaExiste && count($aulas) > 0) {
    $ids = array_column($aulas, 'id');
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    try {
        $stmt = $pdo->prepare("UPDATE aulas_professor 
            SET enviada_extensao = 1, data_envio_extensao = NOW() 
            WHERE id IN ($placeholders) AND usuario_id = ?");
        $updateParams = array_merge($ids, [$usuarioId]);
        $stmt->execute($updateParams);
        $marcadas = $stmt->rowCount();
    } catch (PDOException $e) {
        error_log("[SIAGE] Erro ao marcar aulas como enviadas: " . $e->getMessage());
    }
}

echo json_encode([
    'status' => 'ok',
    'total' => count($aulas),
    'turma_id' => $turmaId,
    'disciplina_id' => $discId,
    'marcadas_como_enviadas' => $marcadas,
    'incluir_enviadas' => $incluirEnviadas ? true : false,
    'aulas' => $aulasFormatadas,
    'frequencias' => $frequenciasFormatadas,
    'texto_aulas' => implode("\n", array_map(fn($a) => 
        $a['data']."\t".$a['dia_semana']."\t".$a['quantidade']."\t".$a['modo_aula']."\t".$a['tipo_aula']."\t".$a['objetos_conhecimento']."\t".$a['metodologia']."\t".$a['observacoes'], 
        $aulasFormatadas
    )),
    'texto_frequencias' => implode("\n", array_map(fn($f) => $f['data']."\t".$f['tempos'], $frequenciasFormatadas)),
], JSON_UNESCAPED_UNICODE);
