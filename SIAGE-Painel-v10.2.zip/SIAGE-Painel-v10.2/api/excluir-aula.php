<?php
// api/excluir-aula.php - Exclui aula via AJAX (retorna JSON)
require_once '../config.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario_id'])) { echo json_encode(['status'=>'erro','erro'=>'Nao autenticado']); exit; }

$usuarioId = $_SESSION['usuario_id'];
$id = (int)($_GET['id'] ?? 0);

if (!$id || !tabelaExiste($pdo, 'aulas_professor')) {
    echo json_encode(['status'=>'erro','erro'=>'ID invalido']);
    exit;
}

$stmt = $pdo->prepare("DELETE FROM aulas_professor WHERE id = ? AND usuario_id = ?");
$stmt->execute([$id, $usuarioId]);

if ($stmt->rowCount() > 0) {
    echo json_encode(['status'=>'ok','mensagem'=>'Aula excluida!']);
} else {
    echo json_encode(['status'=>'erro','erro'=>'Aula nao encontrada']);
}
