<?php
// api/frequencias.php - Retorna datas de frequencias em JSON
require_once '../config.php';

$apiKey = $_SERVER['HTTP_X_API_KEY'] ?? $_GET['api_key'] ?? '';
if (empty($apiKey)) {
    http_response_code(401);
    echo json_encode(['erro' => 'API Key obrigatoria']);
    exit;
}

$stmt = $pdo->prepare("SELECT id, nome FROM usuarios WHERE api_key = ?");
$stmt->execute([$apiKey]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$usuario) {
    http_response_code(403);
    echo json_encode(['erro' => 'API Key invalida']);
    exit;
}

$usuarioId = $usuario['id'];
$periodo = $_GET['periodo'] ?? 'todos';

// Prioriza datas_geradas (novo calendario), senao usa calendario_frequencias (legado)
if ($periodo === 'todos') {
    $stmt = $pdo->prepare("SELECT * FROM datas_geradas WHERE usuario_id = ? AND formato = 'frequencia' ORDER BY data ASC");
    $stmt->execute([$usuarioId]);
} else {
    $stmt = $pdo->prepare("SELECT * FROM datas_geradas WHERE usuario_id = ? AND formato = 'frequencia' AND periodo = ? ORDER BY data ASC");
    $stmt->execute([$usuarioId, $periodo]);
}

$datas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Se nao tem datas geradas, busca do calendario legado
if (empty($datas)) {
    if ($periodo === 'todos') {
        $stmt = $pdo->query("SELECT * FROM calendario_frequencias ORDER BY data ASC");
    } else {
        $stmt = $pdo->prepare("SELECT * FROM calendario_frequencias WHERE periodo = ? ORDER BY data ASC");
        $stmt->execute([$periodo]);
    }
    $datas = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Formata datas para dd/mm/aaaa
foreach ($datas as &$d) {
    $dataObj = new DateTime($d['data']);
    $d['data_formatada'] = $dataObj->format('d/m/Y');
    $d['dia_semana'] = str_replace(
        ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],
        ['Domingo','Segunda','Terca','Quarta','Quinta','Sexta','Sabado'],
        $dataObj->format('l')
    );
}

// Formato simplificado para a extensao: array de {data, tempos}
$listaSimples = [];
foreach ($datas as $d) {
    $listaSimples[] = [
        'data' => $d['data_formatada'],
        'tempos' => $d['tempos'] ?? '1,2',
        'periodo' => (int)($d['periodo'] ?? 1)
    ];
}

echo json_encode([
    'status' => 'ok',
    'total' => count($datas),
    'usuario' => $usuario['nome'],
    'datas' => $listaSimples,
    'raw' => $datas
]);
?>
