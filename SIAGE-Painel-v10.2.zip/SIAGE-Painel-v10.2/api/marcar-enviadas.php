<?php
// api/marcar-enviadas.php - Marca aulas como enviadas para a extensao
require_once '../config.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['status'=>'erro','erro'=>'Nao autenticado']);
    exit;
}

$usuarioId = $_SESSION['usuario_id'];

// Recebe JSON
$input = json_decode(file_get_contents('php://input'), true);
$aulasIds = $input['aulas_ids'] ?? [];

if (empty($aulasIds) || !is_array($aulasIds)) {
    echo json_encode(['status'=>'erro','erro'=>'Nenhuma aula informada']);
    exit;
}

// Sanitiza IDs
$ids = array_filter(array_map('intval', $aulasIds), fn($id) => $id > 0);

if (empty($ids)) {
    echo json_encode(['status'=>'erro','erro'=>'IDs invalidos']);
    exit;
}

// Verifica se a coluna existe
try {
    $stmt = $pdo->query("SHOW COLUMNS FROM aulas_professor LIKE 'enviada_extensao'");
    if ($stmt->rowCount() === 0) {
        echo json_encode(['status'=>'erro','erro'=>'Coluna enviada_extensao nao existe. Execute migrar-enviada.php primeiro.']);
        exit;
    }
} catch (PDOException $e) {
    echo json_encode(['status'=>'erro','erro'=>'Erro ao verificar coluna']);
    exit;
}

// Marca como enviadas (apenas as do usuario logado)
$placeholders = implode(',', array_fill(0, count($ids), '?'));
try {
    $stmt = $pdo->prepare("UPDATE aulas_professor 
        SET enviada_extensao = 1, data_envio_extensao = NOW() 
        WHERE id IN ($placeholders) AND usuario_id = ?");
    $params = array_merge($ids, [$usuarioId]);
    $stmt->execute($params);
    $afetadas = $stmt->rowCount();

    echo json_encode([
        'status' => 'ok',
        'marcadas' => $afetadas,
        'total_enviadas' => $afetadas
    ]);
} catch (PDOException $e) {
    error_log("[SIAGE] Erro ao marcar aulas como enviadas: " . $e->getMessage());
    echo json_encode(['status'=>'erro','erro'=>'Erro ao atualizar status']);
}
