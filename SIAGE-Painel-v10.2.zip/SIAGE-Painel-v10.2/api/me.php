<?php
// api/me.php - Retorna dados do usuario logado (incluindo API Key)
// Usado pela extensao Chrome para obter a API Key automaticamente
require_once '../config.php';
header('Content-Type: application/json; charset=utf-8');

// Autenticacao por sessao (cookie) ou por API Key
$usuario = null;

// Tenta autenticar por sessao primeiro
if (isset($_SESSION['usuario_id'])) {
    $stmt = $pdo->prepare("SELECT id, nome, email, api_key FROM usuarios WHERE id = ?");
    $stmt->execute([$_SESSION['usuario_id']]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Se nao achou por sessao, tenta por API Key
if (!$usuario) {
    $apiKey = $_SERVER['HTTP_X_API_KEY'] ?? $_GET['api_key'] ?? '';
    if (!empty($apiKey)) {
        $stmt = $pdo->prepare("SELECT id, nome, email, api_key FROM usuarios WHERE api_key = ?");
        $stmt->execute([$apiKey]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

if (!$usuario) {
    http_response_code(401);
    echo json_encode([
        'status' => 'erro',
        'erro' => 'Nao autenticado. Faca login no painel web primeiro.'
    ]);
    exit;
}

echo json_encode([
    'status' => 'ok',
    'usuario' => [
        'id' => $usuario['id'],
        'nome' => $usuario['nome'],
        'email' => $usuario['email'],
        'api_key' => $usuario['api_key']
    ]
], JSON_UNESCAPED_UNICODE);
