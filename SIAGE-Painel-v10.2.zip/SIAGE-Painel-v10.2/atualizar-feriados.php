<?php
// atualizar-feriados.php - Feriados e Recessos EXATOS do Calendario Escolar PB 2026
require_once 'config.php';
if (!isset($_SESSION['usuario_id'])) { header('Location: index.php'); exit; }
$usuarioId = $_SESSION['usuario_id'];
$criados = 0;

if (tabelaExiste($pdo, 'feriados')) {
    $pdo->prepare("DELETE FROM feriados WHERE usuario_id = ?")->execute([$usuarioId]);

    // === FERIADOS (F) do calendario oficial ===
    // + feriados adicionais da Paraiba
    $feriadosPB = [
        ['2026-01-01', 'feriado', 'Confraternizacao Universal'],
        ['2026-01-06', 'feriado', 'Santos Reis (PB)'],
        ['2026-02-16', 'feriado', 'Carnaval - Segunda'],
        ['2026-02-17', 'feriado', 'Carnaval'],
        ['2026-02-18', 'feriado', 'Quarta-feira de Cinzas'],
        ['2026-04-03', 'feriado', 'Sexta-feira Santa'],
        ['2026-04-21', 'feriado', 'Tiradentes'],
        ['2026-05-01', 'feriado', 'Dia do Trabalho'],
        ['2026-06-04', 'feriado', 'Corpus Christi (ponto facultativo)'],
        ['2026-06-24', 'feriado', 'Sao Joao (PB)'],
        ['2026-07-09', 'feriado', 'Revolucao Constitucionalista'],
        ['2026-09-07', 'feriado', 'Independencia do Brasil'],
        ['2026-10-12', 'feriado', 'Nossa Senhora Aparecida'],
        ['2026-10-15', 'feriado', 'Dia dos Professores (ponto facultativo)'],
        ['2026-10-28', 'feriado', 'Dia do Servidor Publico'],
        ['2026-11-02', 'feriado', 'Finados'],
        ['2026-11-20', 'feriado', 'Dia da Consciencia Negra'],
        ['2026-12-25', 'feriado', 'Natal'],

        // === RECESSOS ESCOLARES (RE) - Calendario Escolar PB 2026 ===
        // 1o Recesso: 15 a 19/06/2026 (seg a sex) e 22 a 26/06/2026 (seg a sex)
        ['2026-06-15', 'recesso', 'Recesso Escolar'],
        ['2026-06-16', 'recesso', 'Recesso Escolar'],
        ['2026-06-17', 'recesso', 'Recesso Escolar'],
        ['2026-06-18', 'recesso', 'Recesso Escolar'],
        ['2026-06-19', 'recesso', 'Recesso Escolar'],
        ['2026-06-22', 'recesso', 'Recesso Escolar'],
        ['2026-06-23', 'recesso', 'Recesso Escolar'],
        ['2026-06-24', 'recesso', 'Recesso Escolar'],
        ['2026-06-25', 'recesso', 'Recesso Escolar'],
        ['2026-06-26', 'recesso', 'Recesso Escolar'],
    ];

    $stmtF = $pdo->prepare("INSERT INTO feriados (usuario_id, data, tipo, descricao) VALUES (?, ?, ?, ?)");
    foreach ($feriadosPB as $f) {
        try { $stmtF->execute([$usuarioId, $f[0], $f[1], $f[2]]); $criados++; } catch (PDOException $e) {}
    }
}

// Verificar feriados cadastrados
$feriados = fetchAllSeguro($pdo, "SELECT * FROM feriados WHERE usuario_id = ? ORDER BY data ASC", [$usuarioId]);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="UTF-8"><link rel="stylesheet" href="assets/painel.css">
<style>
.status-box { background: rgba(212,237,218,0.8); border: 1px solid rgba(195,230,203,0.6); border-radius: 16px; padding: 30px; margin: 20px 0; text-align: center; animation: glassIn 0.5s ease-out; }
.status-box h3 { color: #155724; }
.lista-datas { text-align: left; max-height: 400px; overflow-y: auto; margin-top: 16px; padding: 16px; background: rgba(255,255,255,0.6); border-radius: 12px; }
.lista-datas div { padding: 5px 0; border-bottom: 1px solid rgba(0,0,0,0.05); font-size: 0.85em; }
.lista-datas .feriado { color: #e74c3c; }
.lista-datas .recesso { color: #e67e22; }
</style></head>
<body>
<div class="container" style="max-width: 600px;">
<div class="card">
    <div class="header"><div><h1>SIAGE Auto</h1><span>Feriados e Recessos 2026</span></div></div>
    <div class="card-body">
        <div class="status-box">
            <h3>&#9989; <?php echo $criados; ?> feriados/recessos atualizados!</h3>
            <p>Calendario Escolar da Paraiba 2026 (PDF oficial)</p>
        </div>
        <div class="lista-datas">
            <h4 style="margin-bottom:10px;color:#333;">Feriados e Recessos cadastrados:</h4>
            <?php foreach ($feriados as $f):
                $dataFmt = date('d/m/Y', strtotime($f['data']));
                $diaSemana = ['Dom','Seg','Ter','Qua','Qui','Sex','Sab'][(int)(new DateTime($f['data']))->format('w')];
                $classe = $f['tipo'];
            ?>
            <div class="<?php echo $classe; ?>">
                <strong><?php echo $dataFmt; ?></strong> (<?php echo $diaSemana; ?>) - 
                <strong><?php echo strtoupper($f['tipo']); ?>:</strong> <?php echo htmlspecialchars($f['descricao']); ?>
            </div>
            <?php endforeach; ?>
        </div>
        <div style="text-align: center; margin-top: 24px;">
            <a href="calendario.php" class="btn btn-ciano" style="font-size: 1em; padding: 14px 28px;">&#128197; Ver Calendario</a>
        </div>
    </div>
    <div class="rodape">Desenvolvido por <strong style="color:#17a2b8;">Maciano Vasconcelos</strong></div>
</div>
</div>
</body></html>
