<?php
// cadastro.php - Cadastro de novo usuario (FECHADO - requer codigo de convite)
require_once 'config.php';

// Se ja estiver logado, vai pro painel
if (isset($_SESSION['usuario_id'])) {
    header('Location: dashboard.php');
    exit;
}

// === CONTROLE DE ACESSO - CODIGO DE CONVITE ===
// Defina o codigo de convite aqui. Apenas quem tiver este codigo podera se cadastrar.
// Para mudar o codigo, altere a linha abaixo.
define('CODIGO_CONVITE', 'SIAGE2026');

$erro = '';
$sucesso = '';
$conviteOk = false;

// Verifica se o codigo de convite foi enviado (GET ou POST)
$codigoEnviado = trim($_POST['codigo_convite'] ?? $_GET['convite'] ?? '');
if ($codigoEnviado === CODIGO_CONVITE) {
    $conviteOk = true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $conviteOk) {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $senha2 = $_POST['senha2'] ?? '';

    // Validacoes
    if (empty($nome) || empty($email) || empty($senha)) {
        $erro = 'Preencha todos os campos.';
    } elseif (strlen($senha) < 6) {
        $erro = 'Senha deve ter no minimo 6 caracteres.';
    } elseif ($senha !== $senha2) {
        $erro = 'As senhas nao conferem.';
    } else {
        // Verifica se email ja existe
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $erro = 'Este email ja esta cadastrado.';
        } else {
            // Gera API Key
            $apiKey = bin2hex(random_bytes(32));
            $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

            $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, api_key) VALUES (?, ?, ?, ?)");
            $stmt->execute([$nome, $email, $senhaHash, $apiKey]);

            $sucesso = 'Cadastro realizado com sucesso! Faca login para continuar.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIAGE Auto - Cadastro</title>
    <link rel="stylesheet" href="assets/painel.css">
</head>
<body>

<div class="container" style="max-width: 480px;">

    <div class="card">
        <div class="header">
            <div>
                <h1>SIAGE Auto</h1>
                <span>Criar Conta</span>
            </div>
        </div>

        <div class="card-body">

            <?php if ($erro): ?>
            <div class="alerta alerta-erro"><?php echo htmlspecialchars($erro); ?></div>
            <?php endif; ?>

            <?php if ($sucesso): ?>
            <div class="alerta alerta-sucesso"><?php echo htmlspecialchars($sucesso); ?></div>
            <div style="text-align: center; margin-top: 16px;">
                <a href="index.php" class="btn btn-verde">Ir para Login</a>
            </div>

            <?php elseif (!$conviteOk): ?>
            <!-- TELA DE CONVITE -->
            <div class="info-box" style="text-align: center;">
                <strong>&#128274; Acesso Restrito</strong><br><br>
                O cadastro e fechado e requer um <strong>codigo de convite</strong>.<br>
                Entre em contato com o administrador para obter acesso.
            </div>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="codigo_convite">Codigo de Convite</label>
                    <input type="text" id="codigo_convite" name="codigo_convite" placeholder="Digite o codigo de convite" required autocomplete="off">
                </div>
                <button type="submit" class="btn btn-ciano" style="width: 100%;">
                    &#10132; Verificar Convite
                </button>
            </form>

            <div style="text-align: center; margin-top: 16px;">
                <a href="index.php" style="color: #17a2b8; font-size: 0.85em; text-decoration: none;">
                    Ja tem conta? Faca login
                </a>
            </div>

            <?php else: ?>
            <!-- FORMULARIO DE CADASTRO (convite OK) -->
            <div class="alerta alerta-sucesso" style="margin-bottom: 16px;">
                &#9989; Codigo de convite verificado! Preencha seus dados.
            </div>

            <form method="POST" action="?convite=<?php echo urlencode(CODIGO_CONVITE); ?>">
                <input type="hidden" name="codigo_convite" value="<?php echo htmlspecialchars(CODIGO_CONVITE); ?>">

                <div class="form-group">
                    <label for="nome">Nome Completo</label>
                    <input type="text" id="nome" name="nome" placeholder="Seu nome" required
                           value="<?php echo htmlspecialchars($_POST['nome'] ?? ''); ?>">
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="professor@email.com" required
                           value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                </div>

                <div class="form-group">
                    <label for="senha">Senha (minimo 6 caracteres)</label>
                    <div class="senha-wrapper">
                        <input type="password" id="senha" name="senha" placeholder="Crie uma senha" required>
                        <button type="button" class="btn-icone" onclick="toggleSenha('senha')">&#128065;</button>
                    </div>
                </div>

                <div class="form-group">
                    <label for="senha2">Confirmar Senha</label>
                    <input type="password" id="senha2" name="senha2" placeholder="Repita a senha" required>
                </div>

                <button type="submit" class="btn btn-ciano" style="width: 100%;">
                    &#9654; Criar Conta
                </button>
            </form>

            <?php endif; ?>

        </div>

        <div class="rodape">
            Desenvolvido por <strong style="color: #17a2b8;">Maciano Vasconcelos</strong>
        </div>
    </div>

</div>

<script>
function toggleSenha(id) {
    const input = document.getElementById(id);
    input.type = input.type === 'password' ? 'text' : 'password';
}
</script>

</body>
</html>
