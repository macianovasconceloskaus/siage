<?php
// calendario.php - Calendario Interativo (Clique no dia = modal, Turma via AJAX)
require_once 'config.php';
if (!isset($_SESSION['usuario_id'])) { header('Location: index.php'); exit; }

$usuarioId = $_SESSION['usuario_id'];

// === CONFIG ===
$config = null;
if (tabelaExiste($pdo, 'configuracoes_calendario')) {
    $stmt = querySegura($pdo, "SELECT * FROM configuracoes_calendario WHERE usuario_id = ?", [$usuarioId]);
    if ($stmt) $config = $stmt->fetch(PDO::FETCH_ASSOC);
}
if (!$config) {
    $config = ['p1_inicio'=>'2026-02-10','p1_fim'=>'2026-04-23','p2_inicio'=>'2026-04-24','p2_fim'=>'2026-07-23','p3_inicio'=>'2026-07-24','p3_fim'=>'2026-10-05','p4_inicio'=>'2026-10-06','p4_fim'=>'2026-12-17','dias_semana'=>'1,2,3,4,5'];
}

// === FERIADOS ===
$feriadosJs = [];
if (tabelaExiste($pdo, 'feriados')) {
    $feriados = fetchAllSeguro($pdo, "SELECT * FROM feriados WHERE usuario_id = ? ORDER BY data ASC", [$usuarioId]);
    foreach ($feriados as $f) { $feriadosJs[$f['data']] = ['tipo'=>$f['tipo'],'desc'=>$f['descricao']]; }
}

// === TURMAS ===
$turmas = tabelaExiste($pdo, 'turmas') ? fetchAllSeguro($pdo, "SELECT * FROM turmas WHERE usuario_id = ? ORDER BY nome", [$usuarioId]) : [];

$turmaId = isset($_GET['turma']) ? (int)$_GET['turma'] : 0;
$discId = isset($_GET['disciplina']) ? (int)$_GET['disciplina'] : 0;

// Disciplinas da turma
$disciplinasTurma = [];
if ($turmaId > 0 && tabelaExiste($pdo, 'turma_disciplina')) {
    $disciplinasTurma = fetchAllSeguro($pdo,
        "SELECT d.* FROM disciplinas d JOIN turma_disciplina td ON d.id = td.disciplina_id WHERE td.turma_id = ? AND td.usuario_id = ? ORDER BY d.nome",
        [$turmaId, $usuarioId]);
}

$turmaNome = '';
foreach ($turmas as $t) { if ($t['id'] == $turmaId) { $turmaNome = $t['nome']; break; } }
$discNome = '';
foreach ($disciplinasTurma as $d) { if ($d['id'] == $discId) { $discNome = $d['nome']; break; } }

// Aulas
$aulasCadastradas = [];
$aulasMap = [];
if ($turmaId > 0 && $discId > 0 && tabelaExiste($pdo, 'aulas_professor')) {
    $aulasCadastradas = fetchAllSeguro($pdo,
        "SELECT * FROM aulas_professor WHERE usuario_id = ? AND turma_id = ? AND disciplina_id = ? ORDER BY data",
        [$usuarioId, $turmaId, $discId]);
    foreach ($aulasCadastradas as $a) { $aulasMap[$a['data']] = $a; }
}

function getTipoDia($dataStr, $config, $feriadosMap) {
    $data = new DateTime($dataStr); $ts = $data->getTimestamp(); $diaSemana = (int)$data->format('w');
    if ($diaSemana == 0 || $diaSemana == 6) return ['tipo'=>'fim_semana','label'=>'Fim de Semana'];
    if (isset($feriadosMap[$dataStr])) { $f = $feriadosMap[$dataStr]; return ['tipo'=>$f['tipo'],'label'=>($f['desc'] ?: ucfirst($f['tipo']))]; }
    $periodos = [['ini'=>$config['p1_inicio'],'fim'=>$config['p1_fim'],'num'=>1],['ini'=>$config['p2_inicio'],'fim'=>$config['p2_fim'],'num'=>2],['ini'=>$config['p3_inicio'],'fim'=>$config['p3_fim'],'num'=>3],['ini'=>$config['p4_inicio'],'fim'=>$config['p4_fim'],'num'=>4]];
    foreach ($periodos as $p) {
        $ini = new DateTime($p['ini']); $fim = new DateTime($p['fim']);
        if ($ts >= $ini->getTimestamp() && $ts <= $fim->getTimestamp()) {
            $diasSemana = explode(',', $config['dias_semana'] ?? '1,2,3,4,5');
            if (in_array((string)$diaSemana, $diasSemana)) return ['tipo'=>'letivo','label'=>$p['num'].'o Periodo','periodo'=>$p['num']];
            return ['tipo'=>'nao_letivo','label'=>'Nao Letivo'];
        }
        if ($dataStr === $p['ini']) return ['tipo'=>'inicio_periodo','label'=>'Inicio '.$p['num'].'o Periodo'];
        if ($dataStr === $p['fim']) return ['tipo'=>'fim_periodo','label'=>'Fim '.$p['num'].'o Periodo'];
    }
    $iniP1 = new DateTime($config['p1_inicio']); $fimP4 = new DateTime($config['p4_fim']);
    if ($ts < $iniP1->getTimestamp() || $ts > $fimP4->getTimestamp()) return ['tipo'=>'ferias','label'=>'Ferias'];
    return ['tipo'=>'recesso','label'=>'Recesso'];
}

$mesesPt = ['Janeiro','Fevereiro','Marco','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
$diasSemanaPt = ['Dom','Seg','Ter','Qua','Qui','Sex','Sab'];
$calendarioDados = [];
$contagemPeriodos = [1=>0,2=>0,3=>0,4=>0];
for ($mes=1; $mes<=12; $mes++) {
    $diasNoMes = cal_days_in_month(CAL_GREGORIAN, $mes, 2026);
    $calendarioDados[$mes] = [];
    for ($dia=1; $dia<=$diasNoMes; $dia++) {
        $dataStr = sprintf('2026-%02d-%02d', $mes, $dia);
        $info = getTipoDia($dataStr, $config, $feriadosJs);
        $info['dia'] = $dia; $info['data'] = $dataStr;
        $info['temAula'] = isset($aulasMap[$dataStr]);
        if ($info['temAula']) $info['aulaInfo'] = $aulasMap[$dataStr];
        $calendarioDados[$mes][$dia] = $info;
        if ($info['tipo'] === 'letivo' && isset($info['periodo'])) $contagemPeriodos[$info['periodo']]++;
    }
}

$periodoCores = ['','#17a2b8','#28a745','#fd7e14','#9b59b6'];
$modelo = [];
if (tabelaExiste($pdo, 'modelos_aula')) {
    $stmt = querySegura($pdo, "SELECT * FROM modelos_aula WHERE usuario_id = ?", [$usuarioId]);
    if ($stmt) $modelo = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
}
if (!$modelo) $modelo = ['metodologia'=>'Aula dialogada','conteudo'=>'Aula realizada de acordo com o plano competente.','observacoes'=>''];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SIAGE Auto - Calendario Letivo 2026</title>
<link rel="stylesheet" href="assets/painel.css">
<style>
.selectores-turma { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 20px; padding: 18px; background: rgba(255,255,255,0.6); backdrop-filter: blur(15px); border-radius: 16px; border: 1px solid rgba(255,255,255,0.4); align-items: flex-end; animation: glassIn 0.5s ease-out; }
.selectores-turma .field { flex: 1; min-width: 180px; }
.selectores-turma .field label { display: block; font-size: 0.8em; font-weight: 600; color: #555; margin-bottom: 6px; }
.selectores-turma .field select { width: 100%; padding: 12px 14px; border: 1px solid rgba(0,0,0,0.1); border-radius: 12px; font-size: 0.95em; background: rgba(255,255,255,0.85); font-family: 'Segoe UI', sans-serif; cursor: pointer; transition: all 0.2s; }
.selectores-turma .field select:focus { outline: none; border-color: rgba(23,162,184,0.5); box-shadow: 0 0 0 3px rgba(23,162,184,0.1); }
.selectores-turma .btn { padding: 12px 22px; font-size: 0.9em; }
.selectores-turma a.btn { padding: 12px 18px; font-size: 0.85em; }
.loading-disc { display: none; font-size: 0.8em; color: #17a2b8; margin-left: 8px; }

.calendario-wrapper { background: rgba(255,255,255,0.7); backdrop-filter: blur(25px) saturate(160%); border-radius: 24px; border: 1px solid rgba(255,255,255,0.45); box-shadow: 0 12px 48px rgba(0,0,0,0.12), inset 0 1px 0 rgba(255,255,255,0.5); padding: 28px; margin: 20px 0; animation: glassIn 0.6s cubic-bezier(0.16,1,0.3,1); }
.nav-mes { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.nav-mes button { background: rgba(255,255,255,0.7); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.4); border-radius: 14px; width: 44px; height: 44px; cursor: pointer; font-size: 1.3em; display: flex; align-items: center; justify-content: center; transition: all 0.25s cubic-bezier(0.16,1,0.3,1); color: #555; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
.nav-mes button:hover { background: rgba(23,162,184,0.2); transform: scale(1.12); box-shadow: 0 4px 16px rgba(23,162,184,0.25); color: #17a2b8; }
.nav-mes select { padding: 10px 18px; border: 1px solid rgba(0,0,0,0.08); border-radius: 14px; font-size: 0.95em; font-family: 'Segoe UI', sans-serif; background: rgba(255,255,255,0.8); backdrop-filter: blur(10px); cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,0.06); color: #333; font-weight: 500; }
.nav-mes h3 { font-size: 1.4em; font-weight: 700; color: #333; text-shadow: 0 1px 2px rgba(0,0,0,0.05); }

.calendario-mes { width: 100%; border-collapse: separate; border-spacing: 5px; }
.calendario-mes th.dia-semana { padding: 10px 4px; text-align: center; font-weight: 600; color: #777; font-size: 0.78em; text-transform: uppercase; letter-spacing: 0.5px; }
.calendario-mes th.dia-semana.fds { color: #e74c3c; }
.calendario-mes td.dia-cell { height: 56px; text-align: center; vertical-align: middle; border-radius: 14px; font-size: 0.95em; font-weight: 500; cursor: pointer; transition: all 0.2s cubic-bezier(0.16,1,0.3,1); position: relative; user-select: none; border: 2px solid transparent; }
.calendario-mes td.dia-cell .dia-numero { display: flex; align-items: center; justify-content: center; width: 100%; height: 100%; flex-direction: column; gap: 1px; }
.calendario-mes td.dia-cell .dia-numero .num { font-size: 1em; font-weight: 600; }
.calendario-mes td.dia-cell .dia-numero .badge { font-size: 0.6em; opacity: 0.9; }
.calendario-mes td.dia-cell:not(.vazio):hover { transform: scale(1.1); z-index: 10; }
.calendario-mes td.dia-cell.selecionado { border-color: #17a2b8; box-shadow: 0 0 0 3px rgba(23,162,184,0.25), 0 4px 16px rgba(23,162,184,0.3); transform: scale(1.08); }
.calendario-mes td.vazio { background: transparent; cursor: default; height: 56px; }

/* CORES */
.calendario-mes td.tipo-letivo { background: rgba(52, 152, 219, 0.18); color: #1a5276; }
.calendario-mes td.tipo-letivo:hover { background: rgba(52, 152, 219, 0.35); }
.calendario-mes td.tipo-letivo.com-aula { background: linear-gradient(135deg, #27ae60, #2ecc71); color: white; box-shadow: 0 2px 8px rgba(39,174,96,0.35); }
.calendario-mes td.tipo-letivo.com-aula:hover { filter: brightness(1.1); }
.calendario-mes td.tipo-feriado { background: linear-gradient(135deg, #e74c3c, #c0392b); color: white; }
.calendario-mes td.tipo-recesso { background: linear-gradient(135deg, #f39c12, #e67e22); color: white; }
.calendario-mes td.tipo-ferias { background: linear-gradient(135deg, #5d6d7e, #34495e); color: rgba(255,255,255,0.8); }
.calendario-mes td.tipo-recuperacao { background: linear-gradient(135deg, #e91e63, #ad1457); color: white; }
.calendario-mes td.tipo-fim_semana { background: rgba(215, 189, 226, 0.35); color: #999; }
.calendario-mes td.tipo-nao_letivo { background: rgba(236, 240, 241, 0.5); color: #bbb; }
.calendario-mes td.tipo-inicio_periodo { background: linear-gradient(135deg, #9b59b6, #8e44ad); color: white; }
.calendario-mes td.tipo-fim_periodo { background: linear-gradient(135deg, #3498db, #2980b9); color: white; }

.toolbar { display: flex; gap: 10px; flex-wrap: wrap; margin: 16px 0; padding: 14px; background: rgba(255,255,255,0.5); backdrop-filter: blur(10px); border-radius: 14px; align-items: center; }
.toolbar-info { font-size: 0.85em; color: #555; flex: 1; }
.toolbar-info strong { color: #17a2b8; font-size: 1.1em; }

/* MODAL */
.modal-overlay, .modal-fundo { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.45); backdrop-filter: blur(8px); z-index: 999999; display: none; align-items: center; justify-content: center; animation: fadeIn 0.25s ease; }
.modal-overlay.ativo, .modal-fundo.ativo { display: flex; }
.modal-glass, .modal-box { background: rgba(255,255,255,0.92); backdrop-filter: blur(30px) saturate(180%); border-radius: 24px; border: 1px solid rgba(255,255,255,0.6); box-shadow: 0 24px 80px rgba(0,0,0,0.2), inset 0 1px 0 rgba(255,255,255,0.6); max-width: 540px; width: 92%; max-height: 90vh; overflow-y: auto; animation: modalIn 0.35s cubic-bezier(0.16,1,0.3,1); }
@keyframes modalIn { from { opacity: 0; transform: translateY(30px) scale(0.95); } to { opacity: 1; transform: translateY(0) scale(1); } }
.modal-header { background: linear-gradient(135deg, rgba(23,162,184,0.92), rgba(102,126,234,0.95)); color: white; padding: 20px 24px; border-radius: 24px 24px 0 0; display: flex; justify-content: space-between; align-items: center; }
.modal-header h3 { font-size: 1.15em; font-weight: 600; }
.modal-fechar { background: rgba(255,255,255,0.25); border: 1px solid rgba(255,255,255,0.3); border-radius: 50%; width: 32px; height: 32px; color: white; font-size: 1.3em; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s; padding: 0 0 2px 0; }
.modal-fechar:hover { background: rgba(255,255,255,0.45); transform: scale(1.1) rotate(90deg); }
.modal-body { padding: 24px; }
.modal-datas { background: rgba(23,162,184,0.08); border: 1px solid rgba(23,162,184,0.2); border-radius: 12px; padding: 12px 16px; margin-bottom: 16px; font-size: 0.85em; color: #0c7b93; font-weight: 500; }
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px; }
.form-row .field label { display: block; font-size: 0.8em; font-weight: 600; color: #555; margin-bottom: 4px; }
.form-row .field input, .form-row .field select, .form-row .field textarea { width: 100%; padding: 10px 12px; border: 1px solid rgba(0,0,0,0.1); border-radius: 10px; font-size: 0.9em; background: rgba(255,255,255,0.85); transition: all 0.2s; font-family: 'Segoe UI', sans-serif; }
.form-row .field input:focus, .form-row .field select:focus, .form-row .field textarea:focus { outline: none; border-color: rgba(23,162,184,0.5); box-shadow: 0 0 0 3px rgba(23,162,184,0.1); background: white; }
.form-row .field textarea { min-height: 60px; resize: vertical; }
.field-full { grid-column: 1 / -1; }
.modal-footer { padding: 16px 24px 24px; display: flex; gap: 10px; justify-content: flex-end; }

.legenda-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px 20px; margin: 16px 0; padding: 14px; background: rgba(255,255,255,0.5); backdrop-filter: blur(10px); border-radius: 14px; }
.legenda-item { display: flex; align-items: center; gap: 10px; font-size: 0.82em; color: #555; }
.legenda-cor { width: 18px; height: 18px; border-radius: 5px; box-shadow: 0 1px 4px rgba(0,0,0,0.12); flex-shrink: 0; }

.export-box { background: rgba(40,167,69,0.08); backdrop-filter: blur(15px); border: 1px solid rgba(40,167,69,0.2); border-radius: 18px; padding: 24px; margin: 24px 0; animation: glassIn 0.5s ease-out; }
.export-tabs { display: flex; gap: 8px; margin-bottom: 14px; flex-wrap: wrap; }
.export-tab { padding: 8px 16px; border-radius: 10px; font-size: 0.82em; font-weight: 600; cursor: pointer; border: none; background: rgba(255,255,255,0.6); color: #555; transition: all 0.2s; }
.export-tab.active { background: linear-gradient(135deg, rgba(40,167,69,0.9), rgba(32,201,151,0.95)); color: white; box-shadow: 0 2px 8px rgba(40,167,69,0.3); }
.export-content { display: none; }
.export-content.active { display: block; }

.periodos-header { display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 12px; margin: 16px 0; }
.periodo-mini { background: rgba(255,255,255,0.55); backdrop-filter: blur(15px); border-radius: 14px; padding: 14px; text-align: center; border-top: 4px solid; transition: all 0.3s; animation: glassIn 0.4s ease-out backwards; }
.periodo-mini:nth-child(1) { animation-delay: 0.05s; border-color: #17a2b8; }
.periodo-mini:nth-child(2) { animation-delay: 0.1s; border-color: #28a745; }
.periodo-mini:nth-child(3) { animation-delay: 0.15s; border-color: #fd7e14; }
.periodo-mini:nth-child(4) { animation-delay: 0.2s; border-color: #9b59b6; }
.periodo-mini:hover { transform: translateY(-3px); background: rgba(255,255,255,0.8); box-shadow: 0 8px 24px rgba(0,0,0,0.1); }
.periodo-mini .num { font-size: 1.6em; font-weight: 700; }
.periodo-mini .label { font-size: 0.72em; color: #666; }

.aviso-info { background: rgba(23,162,184,0.08); border: 1px dashed rgba(23,162,184,0.35); border-radius: 14px; padding: 14px; margin: 12px 0; text-align: center; font-size: 0.88em; color: #0c7b93; }
.aviso-erro { background: rgba(255,243,205,0.7); border: 1px dashed rgba(255,193,7,0.5); border-radius: 14px; padding: 14px; margin: 12px 0; text-align: center; font-size: 0.88em; color: #856404; }

/* TOAST GLASSMORPHISM */
.toast-glass { background: rgba(255,255,255,0.85); backdrop-filter: blur(20px) saturate(160%); border-radius: 16px; border: 1px solid rgba(255,255,255,0.5); box-shadow: 0 8px 32px rgba(0,0,0,0.15), inset 0 1px 0 rgba(255,255,255,0.4); padding: 14px 20px; margin-bottom: 10px; font-size: 0.9em; font-weight: 500; color: #333; display: flex; align-items: center; gap: 10px; min-width: 280px; max-width: 360px; animation: toastSlideIn 0.4s cubic-bezier(0.16,1,0.3,1); transition: all 0.3s ease; pointer-events: auto; }
.toast-glass.sucesso { border-left: 4px solid #27ae60; background: rgba(255,255,255,0.9); }
.toast-glass.sucesso::before { content: '✓'; background: linear-gradient(135deg,#27ae60,#2ecc71); color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.75em; font-weight: 700; flex-shrink: 0; }
.toast-glass.erro { border-left: 4px solid #e74c3c; background: rgba(255,255,255,0.9); }
.toast-glass.erro::before { content: '!'; background: linear-gradient(135deg,#e74c3c,#c0392b); color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.85em; font-weight: 700; flex-shrink: 0; }
.toast-glass.fadeOut { animation: toastFadeOut 0.3s ease forwards; }
@keyframes toastSlideIn { from { opacity: 0; transform: translateX(120%); } to { opacity: 1; transform: translateX(0); } }
@keyframes toastFadeOut { from { opacity: 1; transform: translateX(0); } to { opacity: 0; transform: translateX(120%); } }

/* TABELA AULAS */
.tabela-acoes { display: flex; gap: 6px; justify-content: flex-end; }
.tabela-acoes button { padding: 4px 10px; font-size: 0.75em; border-radius: 8px; cursor: pointer; border: none; transition: all 0.2s; }
.btn-excluir-mini { background: linear-gradient(135deg,#e74c3c,#c0392b); color: white; }
.btn-excluir-mini:hover { transform: scale(1.1); box-shadow: 0 2px 8px rgba(231,76,60,0.4); }
.btn-enviar-mini { background: linear-gradient(135deg,#17a2b8,#138496); color: white; }
.btn-enviar-mini:hover { transform: scale(1.05); box-shadow: 0 2px 8px rgba(23,162,184,0.4); }
.linha-aula { transition: all 0.3s ease; }
/* Abas de filtro por periodo */
#abasPeriodo { display: flex; gap: 6px; margin-bottom: 12px; flex-wrap: wrap; }
.aba-periodo { padding: 6px 14px; border-radius: 10px; font-size: 0.82em; font-weight: 600; cursor: pointer; border: 1px solid rgba(0,0,0,0.08); background: rgba(255,255,255,0.7); color: #555; transition: all 0.2s; }
.aba-periodo:hover { background: rgba(255,255,255,0.95); transform: translateY(-1px); box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
.aba-periodo.active { background: linear-gradient(135deg, rgba(23,162,184,0.9), rgba(102,126,234,0.95)); color: white; border-color: rgba(23,162,184,0.4); box-shadow: 0 2px 8px rgba(23,162,184,0.25); }
.linha-aula.escondida { display: none; }
.linha-aula.fadeOutRow { opacity: 0; transform: translateX(30px); }

@media (max-width: 768px) { .form-row { grid-template-columns: 1fr; } .periodos-header { grid-template-columns: 1fr 1fr; } .legenda-grid { grid-template-columns: 1fr; } .calendario-mes td.dia-cell { height: 44px; font-size: 0.85em; } .toolbar { flex-direction: column; align-items: stretch; } .modal-glass { max-width: 95%; } .selectores-turma { flex-direction: column; } }
@media (max-width: 480px) { .periodos-header { grid-template-columns: 1fr 1fr; } .calendario-wrapper { padding: 16px; border-radius: 16px; } }
</style>
</head>
<body>
<div class="container" style="max-width: 900px;">
<div class="card">
    <div class="header"><div><h1>SIAGE Auto</h1><span>Calendario Letivo 2026</span></div><a href="dashboard.php" class="btn btn-cinza" style="padding:8px 16px;font-size:0.82em;">&#8592; Voltar</a></div>
    <div class="card-body">

<!-- PERIODOS -->
<div class="periodos-header">
    <?php for ($p=1; $p<=4; $p++):
        $aulasP = ($turmaId>0 && $discId>0) ? count(array_filter($aulasCadastradas, fn($a)=>$a['periodo']==$p)) : 0;
    ?>
    <div class="periodo-mini">
        <div class="num" style="color:<?php echo $periodoCores[$p]; ?>"><?php echo $contagemPeriodos[$p]; ?></div>
        <div class="label"><?php echo $p; ?>o Periodo</div>
        <div class="label" style="font-size:0.65em;margin-top:2px;"><?php echo date('d/m',strtotime($config["p{$p}_inicio"])); ?> - <?php echo date('d/m',strtotime($config["p{$p}_fim"])); ?></div>
        <?php if ($aulasP>0): ?><div style="font-size:0.7em;color:<?php echo $periodoCores[$p]; ?>;margin-top:4px;font-weight:600;"><?php echo $aulasP; ?> aulas</div><?php endif; ?>
    </div>
    <?php endfor; ?>
</div>

<!-- SELETORES TURMA/DISCIPLINA (Turma via AJAX, Disciplina recarrega) -->
<?php if (!empty($turmas)): ?>
<div class="selectores-turma">
    <div class="field">
        <label>&#127979; Turma</label>
        <select name="turma" id="selTurma" onchange="carregarDisciplinas()">
            <option value="">-- Selecione a Turma --</option>
            <?php foreach ($turmas as $t): ?>
            <option value="<?php echo $t['id']; ?>" <?php echo $turmaId==$t['id']?'selected':''; ?>><?php echo htmlspecialchars($t['nome']); ?><?php echo $t['serie']?' - '.$t['serie']:''; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="field" style="position:relative;">
        <label>&#128214; Disciplina <span class="loading-disc" id="loadingDisc">&#9203; carregando...</span></label>
        <select name="disciplina" id="selDisciplina" onchange="carregarAulas()">
            <option value="">-- Selecione --</option>
            <?php foreach ($disciplinasTurma as $d): ?>
            <option value="<?php echo $d['id']; ?>" <?php echo $discId==$d['id']?'selected':''; ?>><?php echo htmlspecialchars($d['nome']); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <a href="gerenciar-turmas.php" class="btn btn-amarelo">&#128218; Turmas</a>
</div>
<?php else: ?>
<div style="text-align:center;margin:16px 0;"><a href="gerenciar-turmas.php" class="btn btn-ciano" style="font-size:1em;padding:14px 28px;">&#128218; Cadastrar Turmas e Disciplinas</a></div>
<?php endif; ?>

<!-- STATUS -->
<?php if ($turmaId>0 && $discId>0): ?>
    <div class="aviso-info">&#9989; Registrando aulas para: <strong><?php echo htmlspecialchars($turmaNome); ?></strong> + <strong><?php echo htmlspecialchars($discNome); ?></strong> &mdash; <em>Clique em um dia letivo para registrar</em></div>
<?php elseif ($turmaId>0 && empty($disciplinasTurma)): ?>
    <div class="aviso-erro">&#9888; Turma sem disciplinas vinculadas. <a href="gerenciar-turmas.php" style="color:#17a2b8;font-weight:600;">Vincule aqui</a>.</div>
<?php elseif (!empty($turmas)): ?>
    <div class="aviso-info">&#128161; <strong>Selecione turma e disciplina</strong> acima para registrar aulas</div>
<?php endif; ?>

<!-- CALENDARIO -->
<div class="calendario-wrapper">
    <div class="nav-mes">
        <button onclick="mesAnterior()" title="Mes anterior">&#9664;</button>
        <select id="seletorMes" onchange="mostrarMes(this.value)">
            <?php for ($m=1; $m<=12; $m++): ?><option value="<?php echo $m; ?>" <?php echo $m==date('n')?'selected':''; ?>><?php echo $mesesPt[$m-1]; ?> 2026</option><?php endfor; ?>
        </select>
        <button onclick="mesProximo()" title="Proximo mes">&#9654;</button>
    </div>
    <table class="calendario-mes" id="tabelaCalendario">
        <thead><tr>
            <?php foreach ($diasSemanaPt as $i=>$dsp): ?><th class="dia-semana <?php echo ($i==0||$i==6)?'fds':''; ?>"><?php echo $dsp; ?></th><?php endforeach; ?>
        </tr></thead>
        <tbody id="corpoCalendario"></tbody>
    </table>
    <div class="toolbar" id="toolbarSelecao" style="display:none;">
        <div class="toolbar-info"><strong id="contadorSelecionados">0</strong> dia(s) selecionado(s)</div>
        <?php if ($turmaId>0 && $discId>0): ?>
        <button class="btn btn-ciano" onclick="abrirModalMultiplo()" style="padding:8px 18px;font-size:0.85em;">&#9998; Registrar Aulas</button>
        <?php endif; ?>
        <button class="btn btn-vermelho" onclick="limparSelecao()" style="padding:8px 14px;font-size:0.82em;">&#10005; Limpar</button>
    </div>
</div>

<!-- LEGENDA -->
<div class="legenda-grid">
    <div class="legenda-item"><div class="legenda-cor" style="background:rgba(52,152,219,0.3);"></div> Dia Letivo</div>
    <div class="legenda-item"><div class="legenda-cor" style="background:linear-gradient(135deg,#27ae60,#2ecc71);"></div> Com Aula</div>
    <div class="legenda-item"><div class="legenda-cor" style="background:linear-gradient(135deg,#e74c3c,#c0392b);"></div> Feriado</div>
    <div class="legenda-item"><div class="legenda-cor" style="background:linear-gradient(135deg,#f39c12,#e67e22);"></div> Recesso Escolar</div>
    <div class="legenda-item"><div class="legenda-cor" style="background:linear-gradient(135deg,#5d6d7e,#34495e);"></div> Ferias</div>
    <div class="legenda-item"><div class="legenda-cor" style="background:rgba(215,189,226,0.5);"></div> Fim de Semana</div>
    <div class="legenda-item"><div class="legenda-cor" style="background:linear-gradient(135deg,#9b59b6,#8e44ad);"></div> Inicio/Fim Periodo</div>
    <div class="legenda-item"><div class="legenda-cor" style="background:linear-gradient(135deg,#e91e63,#ad1457);"></div> Recuperacao</div>
</div>

<!-- AULAS + EXPORT (container para atualizacao dinamica via AJAX) -->
<div id="containerAulas" style="display:<?php echo ($turmaId>0 && $discId>0) ? 'block' : 'none'; ?>;">
    <div style="margin-top:24px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:8px;">
            <h3 style="color:#333;font-size:1em;">&#128203; Aulas Cadastradas <span id="contadorAulasLista" style="color:#17a2b8;font-size:0.85em;"></span></h3>
            <div id="contadorAulasFiltradas" style="font-size:0.78em; color:#888;"></div>
            <button class="btn btn-ciano" onclick="abrirModalEnviarExtensao()" style="padding:8px 16px;font-size:0.82em;">&#128229; Enviar para Extensao</button>
            <div id="botoesEnvioDuplo" style="display:none; gap:8px; margin-top:8px;">
                <button class="btn btn-verde" onclick="copiarAulasParaExtensao()" style="padding:6px 14px; font-size:0.78em;">&#128221; Copiar Aulas</button>
                <button class="btn btn-info" onclick="copiarFrequenciasParaExtensao()" style="padding:6px 14px; font-size:0.78em;">&#128203; Copiar Frequencias</button>
            </div>
        </div>
        <!-- Abas de filtro por periodo -->
        <div id="abasPeriodo" style="display:flex; gap:6px; margin-bottom:12px; flex-wrap:wrap;">
            <button class="aba-periodo active" data-periodo="todos" onclick="filtrarAulasPorPeriodo('todos', this)" style="padding:6px 14px; border-radius:10px; font-size:0.82em; font-weight:600; cursor:pointer; border:1px solid rgba(0,0,0,0.08); background:rgba(255,255,255,0.7); color:#555; transition:all 0.2s;">Todas</button>
            <button class="aba-periodo" data-periodo="1" onclick="filtrarAulasPorPeriodo(1, this)" style="padding:6px 14px; border-radius:10px; font-size:0.82em; font-weight:600; cursor:pointer; border:1px solid rgba(0,0,0,0.08); background:rgba(255,255,255,0.7); color:#555; transition:all 0.2s; border-top:3px solid #17a2b8;">1o Periodo</button>
            <button class="aba-periodo" data-periodo="2" onclick="filtrarAulasPorPeriodo(2, this)" style="padding:6px 14px; border-radius:10px; font-size:0.82em; font-weight:600; cursor:pointer; border:1px solid rgba(0,0,0,0.08); background:rgba(255,255,255,0.7); color:#555; transition:all 0.2s; border-top:3px solid #28a745;">2o Periodo</button>
            <button class="aba-periodo" data-periodo="3" onclick="filtrarAulasPorPeriodo(3, this)" style="padding:6px 14px; border-radius:10px; font-size:0.82em; font-weight:600; cursor:pointer; border:1px solid rgba(0,0,0,0.08); background:rgba(255,255,255,0.7); color:#555; transition:all 0.2s; border-top:3px solid #fd7e14;">3o Periodo</button>
            <button class="aba-periodo" data-periodo="4" onclick="filtrarAulasPorPeriodo(4, this)" style="padding:6px 14px; border-radius:10px; font-size:0.82em; font-weight:600; cursor:pointer; border:1px solid rgba(0,0,0,0.08); background:rgba(255,255,255,0.7); color:#555; transition:all 0.2s; border-top:3px solid #9b59b6;">4o Periodo</button>
        </div>
        <div style="max-height:300px;overflow-y:auto;border-radius:14px;box-shadow:0 2px 8px rgba(0,0,0,0.05);">
            <table class="tabela" style="font-size:0.82em;" id="tabelaAulas">
                <thead><tr><th>Data</th><th>Dia</th><th>Aulas</th><th>Modo</th><th>Tipo</th><th>Metodologia</th><th style="text-align:right;">Acoes</th></tr></thead>
                <tbody>
                    <?php if (!empty($aulasCadastradas)): foreach ($aulasCadastradas as $a): $df=(new DateTime($a['data']))->format('d/m/Y'); ?>
                    <tr class="linha-aula" data-id="<?php echo $a['id']; ?>" data-data="<?php echo $a['data']; ?>">
                        <td><strong><?php echo $df; ?></strong></td>
                        <td><?php echo $a['dia_semana']; ?></td>
                        <td><?php echo $a['quantidade']; ?></td>
                        <td><?php echo htmlspecialchars($a['modo_aula']); ?></td>
                        <td><?php echo htmlspecialchars($a['tipo_aula']); ?></td>
                        <td><?php echo htmlspecialchars($a['metodologia']); ?></td>
                        <td>
                            <div class="tabela-acoes">
                                <button class="btn-excluir-mini" onclick="excluirAula(<?php echo $a['id']; ?>, this)" title="Excluir aula">&#10005;</button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; else: ?>
                    <tr id="semAulasMsg"><td colspan="7" style="text-align:center;color:#999;padding:20px;">Nenhuma aula cadastrada. Clique nos dias letivos para registrar.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

    </div>
    <div class="rodape">Desenvolvido por <strong style="color:#17a2b8;">Maciano Vasconcelos</strong> &#8226; SIAGE Auto</div>
</div>
</div>

<!-- TOAST NOTIFICATION -->
<div id="toastContainer" style="position:fixed;top:20px;right:20px;z-index:9999999;"></div>

<!-- MODAL -->
<div class="modal-overlay" id="modalAula">
    <div class="modal-glass">
        <div class="modal-header"><h3>&#9998; Registrar Aula</h3><button class="modal-fechar" onclick="fecharModalAula()">&times;</button></div>
        <div class="modal-body">
            <div class="modal-datas" id="modalDatasSelecionadas"></div>
            <form id="formAula" onsubmit="return false;">
                <div class="form-row">
                    <div class="field"><label>Quantidade de Aulas *</label><input type="number" id="campoQuantidade" value="1" min="1" max="10"></div>
                    <div class="field"><label>Modo de Aula *</label><select id="campoModo"><option value="Aula" selected>Aula</option><option value="Aula Pratica">Aula Pratica</option><option value="Aula de Campo">Aula de Campo</option><option value="Seminario">Seminario</option><option value="Prova">Prova</option></select></div>
                </div>
                <div class="form-row">
                    <div class="field"><label>Tipo de Aula *</label><select id="campoTipo"><option value="Avulso" selected>Avulso</option><option value="Reposicao">Reposicao</option><option value="Recuperacao">Recuperacao</option></select></div>
                    <div class="field"><label>Metodologia *</label><input type="text" id="campoMetodologia" value="<?php echo htmlspecialchars($modelo['metodologia']??'Aula dialogada'); ?>"></div>
                </div>
                <div class="form-row"><div class="field field-full"><label>Objetos de Conhecimento *</label><textarea id="campoObjetos"><?php echo htmlspecialchars($modelo['conteudo']??'Aula realizada de acordo com o plano competente.'); ?></textarea></div></div>
                <div class="form-row"><div class="field field-full"><label>Observacoes (opcional)</label><textarea id="campoObservacoes"><?php echo htmlspecialchars($modelo['observacoes']??''); ?></textarea></div></div>
                <div class="form-row"><div class="field field-full">
                    <label>Tempos (Aulas) * <small style="font-weight:normal;color:#888;">Marque os tempos em que houve aula</small></label>
                    <div id="campoTemposContainer" style="display:flex; flex-wrap:wrap; gap:8px; margin-top:6px;">
                        <label style="display:flex; align-items:center; gap:4px; padding:6px 12px; background:rgba(23,162,184,0.08); border-radius:8px; cursor:pointer; border:1px solid rgba(0,0,0,0.08); font-size:0.85em;"><input type="checkbox" value="1" class="chk-tempo" style="margin:0;"> 1º</label>
                        <label style="display:flex; align-items:center; gap:4px; padding:6px 12px; background:rgba(23,162,184,0.08); border-radius:8px; cursor:pointer; border:1px solid rgba(0,0,0,0.08); font-size:0.85em;"><input type="checkbox" value="2" class="chk-tempo" style="margin:0;"> 2º</label>
                        <label style="display:flex; align-items:center; gap:4px; padding:6px 12px; background:rgba(23,162,184,0.08); border-radius:8px; cursor:pointer; border:1px solid rgba(0,0,0,0.08); font-size:0.85em;"><input type="checkbox" value="3" class="chk-tempo" style="margin:0;"> 3º</label>
                        <label style="display:flex; align-items:center; gap:4px; padding:6px 12px; background:rgba(23,162,184,0.08); border-radius:8px; cursor:pointer; border:1px solid rgba(0,0,0,0.08); font-size:0.85em;"><input type="checkbox" value="4" class="chk-tempo" style="margin:0;"> 4º</label>
                        <label style="display:flex; align-items:center; gap:4px; padding:6px 12px; background:rgba(23,162,184,0.08); border-radius:8px; cursor:pointer; border:1px solid rgba(0,0,0,0.08); font-size:0.85em;"><input type="checkbox" value="5" class="chk-tempo" style="margin:0;"> 5º</label>
                        <label style="display:flex; align-items:center; gap:4px; padding:6px 12px; background:rgba(23,162,184,0.08); border-radius:8px; cursor:pointer; border:1px solid rgba(0,0,0,0.08); font-size:0.85em;"><input type="checkbox" value="6" class="chk-tempo" style="margin:0;"> 6º</label>
                        <label style="display:flex; align-items:center; gap:4px; padding:6px 12px; background:rgba(23,162,184,0.08); border-radius:8px; cursor:pointer; border:1px solid rgba(0,0,0,0.08); font-size:0.85em;"><input type="checkbox" value="7" class="chk-tempo" style="margin:0;"> 7º</label>
                        <label style="display:flex; align-items:center; gap:4px; padding:6px 12px; background:rgba(23,162,184,0.08); border-radius:8px; cursor:pointer; border:1px solid rgba(0,0,0,0.08); font-size:0.85em;"><input type="checkbox" value="8" class="chk-tempo" style="margin:0;"> 8º</label>
                        <label style="display:flex; align-items:center; gap:4px; padding:6px 12px; background:rgba(23,162,184,0.08); border-radius:8px; cursor:pointer; border:1px solid rgba(0,0,0,0.08); font-size:0.85em;"><input type="checkbox" value="9" class="chk-tempo" style="margin:0;"> 9º</label>
                    </div>
                    <input type="hidden" id="campoTempos" value="1,2">
                </div></div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-cinza" onclick="fecharModalAula()" style="padding:10px 18px;font-size:0.88em;">Cancelar</button>
            <button class="btn btn-verde" onclick="salvarAulas()" style="padding:10px 24px;font-size:0.9em;">&#128190; Salvar</button>
        </div>
    </div>
</div>

<script>
const calendarioDados=<?php echo json_encode($calendarioDados); ?>;
const mesesPt=<?php echo json_encode($mesesPt); ?>;
let mesAtual=<?php echo date('n'); ?>;
let diasSelecionados=new Set();
let ultimoDiaClicado=null;
let turmaSelecionada=<?php echo $turmaId; ?>;
let discSelecionada=<?php echo $discId; ?>;
let podeRegistrar=(turmaSelecionada>0&&discSelecionada>0);

// === TOAST NOTIFICATION GLASSMORPHISM ===
function mostrarToast(mensagem, tipo){
    const container=document.getElementById('toastContainer');
    const toast=document.createElement('div');
    toast.className='toast-glass '+tipo;
    toast.textContent=mensagem;
    container.appendChild(toast);
    setTimeout(()=>{
        toast.classList.add('fadeOut');
        setTimeout(()=>{if(toast.parentNode)toast.parentNode.removeChild(toast);},300);
    },3000);
}

// === CARREGAR DISCIPLINAS VIA AJAX (sem refresh) ===
async function carregarDisciplinas(){
    const turmaId=document.getElementById('selTurma').value;
    const selDisc=document.getElementById('selDisciplina');
    const loading=document.getElementById('loadingDisc');
    if(!turmaId){selDisc.innerHTML='<option value="">-- Selecione --</option>';return;}
    loading.style.display='inline';
    try{
        const r=await fetch('api/disciplinas-turma.php?turma='+turmaId);
        const disc=await r.json();
        let html='<option value="">-- Selecione --</option>';
        disc.forEach(d=>{html+='<option value="'+d.id+'">'+d.nome+'</option>';});
        selDisc.innerHTML=html;
    }catch(e){console.error(e);mostrarToast('Erro ao carregar disciplinas','erro');}
    finally{loading.style.display='none';}
}

// === CARREGAR AULAS AO SELECIONAR DISCIPLINA (sem refresh) ===
async function carregarAulas(){
    const t=document.getElementById('selTurma').value;
    const d=document.getElementById('selDisciplina').value;
    if(!t||!d){
        // Limpa aulas do calendario
        for(let m=1;m<=12;m++){
            for(let dia=1;dia<=31;dia++){
                if(calendarioDados[m]&&calendarioDados[m][dia]){
                    calendarioDados[m][dia].temAula=false;
                    delete calendarioDados[m][dia].aulaInfo;
                }
            }
        }
        turmaSelecionada=parseInt(t)||0;
        discSelecionada=0;
        podeRegistrar=false;
        mostrarMes(mesAtual);
        document.getElementById('containerAulas').style.display='none';
        return;
    }
    
    document.getElementById('loadingDisc').style.display='inline';
    try{
        const r=await fetch('api/carregar-aulas.php?turma='+t+'&disciplina='+d);
        const j=await r.json();
        if(j.status==='ok'){
            // Atualiza variaveis globais
            turmaSelecionada=parseInt(t);
            discSelecionada=parseInt(d);
            podeRegistrar=true;
            
            // Atualiza calendarioDados com as aulas
            for(let m=1;m<=12;m++){
                for(let dia=1;dia<=31;dia++){
                    if(calendarioDados[m]&&calendarioDados[m][dia]){
                        const dataStr=calendarioDados[m][dia].data;
                        if(j.aulas_map[dataStr]){
                            calendarioDados[m][dia].temAula=true;
                            calendarioDados[m][dia].aulaInfo=j.aulas_map[dataStr];
                        }else{
                            calendarioDados[m][dia].temAula=false;
                            delete calendarioDados[m][dia].aulaInfo;
                        }
                    }
                }
            }
            
            // Re-renderiza calendario
            mostrarMes(mesAtual);
            
            // Atualiza lista de aulas
            atualizarListaAulas(j);
            
            // (textareas de export removidos - exportacao agora e apenas via modal)
            
            // Mostra container
            document.getElementById('containerAulas').style.display='block';
            
            mostrarToast(j.total+' aulas carregadas para '+j.disc_abrev+' ('+j.turma_nome+')','sucesso');
        }else{
            mostrarToast(j.erro||'Erro ao carregar aulas','erro');
        }
    }catch(e){console.error(e);mostrarToast('Erro de comunicacao','erro');}
    finally{document.getElementById('loadingDisc').style.display='none';}
}

// === CONFIGURACOES DE PERIODOS PARA FILTRO ===
const periodosConfig = {
    1: { ini: '<?php echo $config['p1_inicio']; ?>', fim: '<?php echo $config['p1_fim']; ?>' },
    2: { ini: '<?php echo $config['p2_inicio']; ?>', fim: '<?php echo $config['p2_fim']; ?>' },
    3: { ini: '<?php echo $config['p3_inicio']; ?>', fim: '<?php echo $config['p3_fim']; ?>' },
    4: { ini: '<?php echo $config['p4_inicio']; ?>', fim: '<?php echo $config['p4_fim']; ?>' }
};
let filtroPeriodoAtivo = 'todos';

function filtrarAulasPorPeriodo(periodo, btn) {
    filtroPeriodoAtivo = periodo;
    // Atualiza abas visuais
    document.querySelectorAll('.aba-periodo').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    
    const linhas = document.querySelectorAll('.linha-aula');
    const semAulasMsg = document.getElementById('semAulasMsg');
    let visiveis = 0;
    
    linhas.forEach(linha => {
        if (periodo === 'todos') {
            linha.classList.remove('escondida');
            visiveis++;
        } else {
            const dataStr = linha.getAttribute('data-data');
            const dataTs = new Date(dataStr + 'T12:00:00').getTime();
            const iniTs = new Date(periodosConfig[periodo].ini + 'T00:00:00').getTime();
            const fimTs = new Date(periodosConfig[periodo].fim + 'T23:59:59').getTime();
            if (dataTs >= iniTs && dataTs <= fimTs) {
                linha.classList.remove('escondida');
                visiveis++;
            } else {
                linha.classList.add('escondida');
            }
        }
    });
    
    // Mostra/oculta mensagem "sem aulas" baseado no filtro
    if (semAulasMsg) {
        if (visiveis === 0 && periodo !== 'todos') {
            semAulasMsg.style.display = '';
            semAulasMsg.querySelector('td').textContent = 'Nenhuma aula cadastrada neste periodo.';
        } else if (linhas.length > 0) {
            semAulasMsg.style.display = 'none';
        }
    }
    
    document.getElementById('contadorAulasFiltradas').textContent = periodo === 'todos' ? '' : visiveis + ' aula(s) neste periodo';
}

function atualizarListaAulas(j){
    const container=document.getElementById('containerAulas');
    const tabela=document.getElementById('tabelaAulas');
    const tbody=tabela.querySelector('tbody');
    document.getElementById('contadorAulasLista').textContent=j.total?'('+j.total+')':'';
    if(!j.aulas||j.aulas.length===0){
        tbody.innerHTML='<tr id="semAulasMsg"><td colspan="7" style="text-align:center;color:#999;padding:20px;">Nenhuma aula cadastrada. Clique nos dias letivos para registrar.</td></tr>';
        return;
    }
    let html='';
    j.aulas.forEach(function(a){
        html+='<tr class="linha-aula" data-id="'+a.id+'" data-data="'+a.data+'">';
        html+='<td><strong>'+a.data_formatada+'</strong></td>';
        html+='<td>'+a.dia_semana+'</td>';
        html+='<td>'+a.quantidade+'</td>';
        html+='<td>'+(a.modo_aula||'')+'</td>';
        html+='<td>'+(a.tipo_aula||'')+'</td>';
        html+='<td>'+(a.metodologia||'')+'</td>';
        html+='<td><div class="tabela-acoes"><button class="btn-excluir-mini" onclick="excluirAula('+a.id+',this)" title="Excluir">&#10005;</button></div></td>';
        html+='</tr>';
    });
    tbody.innerHTML=html;
    // Reaplica filtro de periodo ativo apos atualizar a lista
    const abaAtiva = document.querySelector('.aba-periodo.active');
    if (abaAtiva && filtroPeriodoAtivo !== 'todos') {
        filtrarAulasPorPeriodo(filtroPeriodoAtivo, abaAtiva);
    }
}

function filtrarTurmaDisc(){
    const t=document.getElementById('selTurma').value;
    const d=document.getElementById('selDisciplina').value;
    if(!t||!d){mostrarToast('Selecione turma e disciplina!','erro');return;}
    carregarAulas();
}

function mostrarMes(mes){
    mes=parseInt(mes); mesAtual=mes;
    document.getElementById('seletorMes').value=mes;
    const tbody=document.getElementById('corpoCalendario');
    tbody.innerHTML='';
    const dadosMes=calendarioDados[mes]; if(!dadosMes)return;
    const primeiroDiaSemana=new Date(2026,mes-1,1).getDay();
    const diasNoMes=Object.keys(dadosMes).length;
    let html='', dia=1;
    for(let semana=0;semana<6;semana++){
        html+='<tr>';
        for(let dSem=0;dSem<7;dSem++){
            if(semana===0&&dSem<primeiroDiaSemana){html+='<td class="vazio"></td>';}
            else if(dia>diasNoMes){html+='<td class="vazio"></td>';}
            else{
                const info=dadosMes[dia], dataStr=info.data, tipo=info.tipo, temAula=info.temAula;
                const periodo=info.periodo||''; const isSel=diasSelecionados.has(dataStr);
                let cls='dia-cell tipo-'+tipo;
                if(tipo==='letivo'&&temAula)cls+=' com-aula';
                if(isSel)cls+=' selecionado';
                let title=info.label; if(temAula){title+=' (AULA: '+(info.aulaInfo?.modo_aula||'')+')';}
                let badge='';
                if(tipo==='letivo'){if(temAula)badge='<span class="badge">&#10003;</span>'; else badge='<span class="badge">'+periodo+'oP</span>';}
                html+='<td class="'+cls+'" data-data="'+dataStr+'" data-dia="'+dia+'" title="'+title+'" onclick="clicarDia(event,\''+dataStr+'\','+dia+')">';
                html+='<div class="dia-numero"><span class="num">'+dia+'</span>'+badge+'</div></td>';
                dia++;
            }
        }html+='</tr>'; if(dia>diasNoMes)break;
    }tbody.innerHTML=html; atualizarToolbar();
}

// CLIQUE NO DIA
function clicarDia(event,dataStr,diaNum){
    const info=calendarioDados[mesAtual][diaNum];
    if(!info||info.tipo!=='letivo')return;
    if(event.ctrlKey||event.metaKey){
        if(diasSelecionados.has(dataStr)){diasSelecionados.delete(dataStr);}else{diasSelecionados.add(dataStr);ultimoDiaClicado=diaNum;}
        mostrarMes(mesAtual);
    }else if(event.shiftKey&&ultimoDiaClicado!==null){
        const start=Math.min(ultimoDiaClicado,diaNum), end=Math.max(ultimoDiaClicado,diaNum);
        for(let d=start;d<=end;d++){const di=calendarioDados[mesAtual][d];if(di&&di.tipo==='letivo')diasSelecionados.add(di.data);}
        mostrarMes(mesAtual);
    }else{
        diasSelecionados.clear();
        diasSelecionados.add(dataStr);
        ultimoDiaClicado=diaNum;
        mostrarMes(mesAtual);
        if(podeRegistrar){
            setTimeout(()=>abrirModalUnico(dataStr),50);
        }else{
            mostrarToast('Selecione uma turma e disciplina primeiro para registrar aulas.','erro');
        }
    }
}

function abrirModalUnico(dataStr){
    const [ano,mes,dia]=dataStr.split('-');
    const dataFormatada=dia+'/'+mes+'/'+ano;
    const info=calendarioDados[parseInt(mes)][parseInt(dia)];
    let html='<strong>Data:</strong> '+dataFormatada;
    if(info&&info.temAula&&info.aulaInfo){
        html+=' <span style="color:#27ae60;">(AULA JA CADASTRADA - Editando)</span>';
        document.getElementById('campoQuantidade').value=info.aulaInfo.quantidade||1;
        document.getElementById('campoModo').value=info.aulaInfo.modo_aula||'Aula';
        document.getElementById('campoTipo').value=info.aulaInfo.tipo_aula||'Avulso';
        document.getElementById('campoMetodologia').value=info.aulaInfo.metodologia||'Aula dialogada';
        document.getElementById('campoObjetos').value=info.aulaInfo.objetos_conhecimento||'Aula realizada de acordo com o plano competente.';
        document.getElementById('campoObservacoes').value=info.aulaInfo.observacoes||'';
        setTemposCheckboxes(info.aulaInfo.tempos||'1,2');
    }else{
        document.getElementById('campoQuantidade').value=1;
        document.getElementById('campoModo').value='Aula';
        document.getElementById('campoTipo').value='Avulso';
        document.getElementById('campoMetodologia').value='<?php echo addslashes($modelo['metodologia']??'Aula dialogada'); ?>';
        document.getElementById('campoObjetos').value='<?php echo addslashes($modelo['conteudo']??'Aula realizada de acordo com o plano competente.'); ?>';
        document.getElementById('campoObservacoes').value='<?php echo addslashes($modelo['observacoes']??''); ?>';
        document.getElementById('campoTempos').value='1,2';
        setTemposCheckboxes('1,2');
    }
    document.getElementById('modalDatasSelecionadas').innerHTML=html;
    document.getElementById('modalAula').classList.add('ativo');
}

// === CONTROLE DOS CHECKBOXES DE TEMPOS ===
function setTemposCheckboxes(temposStr) {
    const tempos = (temposStr || '1,2').split(/[,;]/).map(t => parseInt(t.trim(), 10)).filter(n => !isNaN(n) && n >= 1 && n <= 9);
    document.querySelectorAll('.chk-tempo').forEach(chk => {
        chk.checked = tempos.includes(parseInt(chk.value, 10));
    });
    atualizarCampoTemposHidden();
}

function atualizarCampoTemposHidden() {
    const selecionados = Array.from(document.querySelectorAll('.chk-tempo:checked')).map(chk => chk.value).join(',');
    document.getElementById('campoTempos').value = selecionados || '1,2';
}

// Listener nos checkboxes para atualizar o campo hidden (aguarda o modal estar no DOM)
setTimeout(function() {
    document.querySelectorAll('.chk-tempo').forEach(chk => {
        chk.addEventListener('change', atualizarCampoTemposHidden);
    });
}, 500);

function abrirModalMultiplo(){
    if(diasSelecionados.size===0)return;
    const lista=Array.from(diasSelecionados).sort().map(d=>{
        const[ano,mes,dia]=d.split('-');
        return dia+'/'+mes+'/'+ano;
    });
    document.getElementById('modalDatasSelecionadas').innerHTML='<strong>Datas selecionadas:</strong> '+lista.join(', ');
    document.getElementById('campoQuantidade').value=1;
    document.getElementById('campoModo').value='Aula';
    document.getElementById('campoTipo').value='Avulso';
    document.getElementById('campoMetodologia').value='<?php echo addslashes($modelo['metodologia']??'Aula dialogada'); ?>';
    document.getElementById('campoObjetos').value='<?php echo addslashes($modelo['conteudo']??'Aula realizada de acordo com o plano competente.'); ?>';
    document.getElementById('campoObservacoes').value='<?php echo addslashes($modelo['observacoes']??''); ?>';
    document.getElementById('campoTempos').value='1,2';
    setTemposCheckboxes('1,2');
    document.getElementById('modalAula').classList.add('ativo');
}

function fecharModalAula(){document.getElementById('modalAula').classList.remove('ativo');}
document.getElementById('modalAula').addEventListener('click',function(e){if(e.target===this)fecharModalAula();});

// === SALVAR AULAS (sem refresh) ===
async function salvarAulas(){
    if(turmaSelecionada===0||discSelecionada===0){mostrarToast('Selecione turma e disciplina!','erro');return;}
    const datas=Array.from(diasSelecionados).sort(); if(datas.length===0)return;
    const dados={datas:datas, quantidade:document.getElementById('campoQuantidade').value, modo_aula:document.getElementById('campoModo').value, tipo_aula:document.getElementById('campoTipo').value, metodologia:document.getElementById('campoMetodologia').value, objetos_conhecimento:document.getElementById('campoObjetos').value, observacoes:document.getElementById('campoObservacoes').value, tempos:document.getElementById('campoTempos').value, turma_id:turmaSelecionada, disciplina_id:discSelecionada};
    const btn=event.target; btn.disabled=true; btn.textContent='Salvando...';
    try{
        const r=await fetch('salvar-aula.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(dados)});
        const j=await r.json();
        if(j.status==='ok'){
            // Atualiza calendarioDados com as novas aulas retornadas do servidor
            if(j.aulas&&Array.isArray(j.aulas)){
                j.aulas.forEach(function(aula){
                    const dataStr=aula.data;
                    const [aY,aM,aD]=dataStr.split('-');
                    const mNum=parseInt(aM), dNum=parseInt(aD);
                    if(calendarioDados[mNum]&&calendarioDados[mNum][dNum]){
                        calendarioDados[mNum][dNum].temAula=true;
                        calendarioDados[mNum][dNum].aulaInfo=aula;
                    }
                });
            }else{
                // Fallback: marca os dias salvos como com aula
                datas.forEach(function(ds){
                    const [y,m,d]=ds.split('-');
                    const mNum=parseInt(m), dNum=parseInt(d);
                    if(calendarioDados[mNum]&&calendarioDados[mNum][dNum]){
                        calendarioDados[mNum][dNum].temAula=true;
                    }
                });
            }
            fecharModalAula();
            diasSelecionados.clear();
            ultimoDiaClicado=null;
            mostrarMes(mesAtual);
            mostrarToast('Aulas salvas!','sucesso');
            // Recarrega lista de aulas e export automaticamente
            await carregarAulas();
        }else{mostrarToast('Erro: '+(j.erro||'Erro ao salvar'),'erro');}
    }catch(e){mostrarToast('Erro na comunicacao.','erro');console.error(e);}
    finally{btn.disabled=false;btn.innerHTML='&#128190; Salvar';}
}

// === EXCLUIR AULA VIA AJAX ===
async function excluirAula(id, btn){
    if(!confirm('Tem certeza que deseja excluir esta aula?'))return;
    const row=btn.closest('tr');
    const dataStr=row?row.getAttribute('data-data'):null;
    try{
        const r=await fetch('api/excluir-aula.php?id='+id);
        const j=await r.json();
        if(j.status==='ok'||j.success){
            // Anima fadeOut na linha
            row.classList.add('fadeOutRow');
            setTimeout(()=>{if(row.parentNode)row.parentNode.removeChild(row);},300);
            // Atualiza calendarioDados removendo a aula do dia
            if(dataStr){
                const [y,m,d]=dataStr.split('-');
                const mNum=parseInt(m), dNum=parseInt(d);
                if(calendarioDados[mNum]&&calendarioDados[mNum][dNum]){
                    calendarioDados[mNum][dNum].temAula=false;
                    calendarioDados[mNum][dNum].aulaInfo=null;
                }
            }
            mostrarMes(mesAtual);
            mostrarToast('Aula excluida!','sucesso');
            // Recarrega lista de aulas para atualizar contadores e filtros
            await carregarAulas();
        }else{mostrarToast('Erro: '+(j.erro||'Nao foi possivel excluir'),'erro');}
    }catch(e){mostrarToast('Erro na comunicacao.','erro');console.error(e);}
}

// === MODAL ENVIAR EXTENSAO (substituido por modal interativo) ===
// Ver funcoes abaixo: abrirModalEnviarExtensao(), confirmarEnvioAulas(), confirmarEnvioFrequencias()

function limparSelecao(){diasSelecionados.clear();ultimoDiaClicado=null;mostrarMes(mesAtual);}
function atualizarToolbar(){
    const tb=document.getElementById('toolbarSelecao'), ct=document.getElementById('contadorSelecionados');
    if(diasSelecionados.size>0){tb.style.display='flex';ct.textContent=diasSelecionados.size;}
    else{tb.style.display='none';}
}
function mesAnterior(){if(mesAtual>1)mostrarMes(mesAtual-1);}
function mesProximo(){if(mesAtual<12)mostrarMes(mesAtual+1);}
function mostrarExport(tipo,btn){document.querySelectorAll('.export-tab').forEach(b=>b.classList.remove('active'));document.querySelectorAll('.export-content').forEach(c=>c.classList.remove('active'));btn.classList.add('active');document.getElementById('export-'+tipo).classList.add('active');}
function copiarTexto(id){const el=document.getElementById(id);el.select();document.execCommand('copy');if(navigator.clipboard)navigator.clipboard.writeText(el.value);mostrarToast('Copiado! Cole na extensao SIAGE.','sucesso');}

mostrarMes(mesAtual);
// Carrega aulas automaticamente se turma+disciplina ja selecionadas na URL
if(turmaSelecionada>0 && discSelecionada>0){setTimeout(carregarAulas,100);}
</script>

<!-- ============================ -->
<!-- MODAL ENVIAR PARA EXTENSAO   -->
<!-- ============================ -->
<div class="modal-fundo" id="modalEnviarExtensao">
<div class="modal-box" style="max-width:720px; max-height:85vh; display:flex; flex-direction:column;">
    <div class="modal-header" style="flex-shrink:0;">
        <div style="font-size:1.15em;">&#128229; Enviar para Extensao SIAGE</div>
        <button class="modal-fechar" onclick="fecharModalEnviarExtensao()">&#10005;</button>
    </div>

    <div class="modal-body" style="flex:1; overflow-y:auto; padding:20px;">
        <!-- Info Turma/Disciplina -->
        <div id="envioInfoTurma" style="padding:12px 16px; background:rgba(23,162,184,0.08); border-radius:12px; margin-bottom:16px; font-size:0.88em; color:#555;">
            &#127979; <strong id="envioTurmaNome">-</strong> &nbsp;|&nbsp; &#128214; <strong id="envioDiscNome">-</strong>
            <span id="envioResumo" style="margin-left:12px; color:#17a2b8;"></span>
        </div>

        <!-- Filtros -->
        <div style="display:flex; gap:12px; margin-bottom:16px; flex-wrap:wrap; align-items:center;">
            <select id="envioFiltroMes" onchange="filtrarAulasModal()" style="padding:8px 12px; border-radius:10px; border:1px solid rgba(0,0,0,0.12); font-size:0.85em;">
                <option value="">Todos os meses</option>
                <option value="2">Fevereiro</option>
                <option value="3">Marco</option>
                <option value="4">Abril</option>
                <option value="5">Maio</option>
                <option value="6">Junho</option>
                <option value="7">Julho</option>
                <option value="8">Agosto</option>
                <option value="9">Setembro</option>
                <option value="10">Outubro</option>
                <option value="11">Novembro</option>
                <option value="12">Dezembro</option>
            </select>

            <label style="font-size:0.82em; color:#555; cursor:pointer; display:flex; align-items:center; gap:6px;">
                <input type="checkbox" id="envioMostrarEnviadas" onchange="filtrarAulasModal()" checked>
                Mostrar ja enviadas
            </label>

            <div style="margin-left:auto; font-size:0.8em; color:#888;" id="envioContadorModal">0 aulas</div>
        </div>

        <!-- Acoes em massa -->
        <div style="display:flex; gap:10px; margin-bottom:12px; flex-wrap:wrap;">
            <button class="btn btn-verde" onclick="marcarTodasModal(true)" style="padding:6px 14px; font-size:0.8em;">&#9745; Marcar todas visiveis</button>
            <button class="btn btn-cinza" onclick="marcarTodasModal(false)" style="padding:6px 14px; font-size:0.8em;">&#9744; Desmarcar todas</button>
            <button class="btn" onclick="marcarPendentesModal()" style="padding:6px 14px; font-size:0.8em; background:linear-gradient(135deg,#17a2b8,#138496); color:white;">&#9203; Selecionar pendentes</button>
        </div>

        <!-- Lista de aulas -->
        <div id="envioListaAulas" style="border:1px solid rgba(0,0,0,0.08); border-radius:12px; overflow:hidden;">
            <div style="padding:30px; text-align:center; color:#999; font-size:0.9em;">&#9203; Carregando aulas...</div>
        </div>
    </div>

    <!-- PASSO 1: ENVIAR AULAS -->
    <div id="modalFooterPasso1" class="modal-footer" style="flex-shrink:0; border-top:1px solid rgba(0,0,0,0.08); padding:16px 20px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <div style="font-size:0.82em; color:#888;">
            <span style="display:inline-block; background:#e74c3c; color:white; padding:2px 8px; border-radius:6px; font-size:0.75em; font-weight:600; margin-right:6px;">PASSO 1 de 2</span>
            <span id="envioSelecionadasContador">0</span> selecionada(s)
        </div>
        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <button class="btn btn-vermelho" onclick="fecharModalEnviarExtensao()" style="padding:8px 18px; font-size:0.85em;">Cancelar</button>
            <button class="btn btn-verde" onclick="confirmarEnvioAulas()" style="padding:8px 22px; font-size:0.9em;">&#128221; Copiar Aulas</button>
        </div>
    </div>
    <!-- PASSO 2: ENVIAR FREQUENCIAS -->
    <div id="modalFooterPasso2" class="modal-footer" style="flex-shrink:0; border-top:1px solid rgba(0,0,0,0.08); padding:16px 20px; display:none; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <div style="font-size:0.82em; color:#888;">
            <span style="display:inline-block; background:#17a2b8; color:white; padding:2px 8px; border-radius:6px; font-size:0.75em; font-weight:600; margin-right:6px;">PASSO 2 de 2</span>
            Aulas enviadas! Agora as frequencias.
        </div>
        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <button class="btn btn-cinza" onclick="voltarParaPasso1()" style="padding:8px 18px; font-size:0.85em;">&#8630; Voltar</button>
            <button class="btn btn-info" onclick="confirmarEnvioFrequencias()" style="padding:8px 22px; font-size:0.9em; background:linear-gradient(135deg,#17a2b8,#138496); color:white;">&#128203; Copiar Frequencias</button>
        </div>
    </div>
    <!-- PASSO 3: CONCLUIDO -->
    <div id="modalFooterPasso3" class="modal-footer" style="flex-shrink:0; border-top:1px solid rgba(0,0,0,0.08); padding:16px 20px; display:none; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <div style="font-size:0.82em; color:#28a745;">
            <span style="display:inline-block; background:#28a745; color:white; padding:2px 8px; border-radius:6px; font-size:0.75em; font-weight:600; margin-right:6px;">&#10003;</span>
            Envio completo! Aulas e frequencias copiadas.
        </div>
        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <button class="btn btn-verde" onclick="fecharModalEnviarExtensao()" style="padding:8px 22px; font-size:0.9em;">&#10003; Concluir</button>
        </div>
    </div>
</div>
</div>

<style>
/* Modal Enviar Extensao */
#modalEnviarExtensao .aula-item {
    display: flex; align-items: center; padding: 10px 14px;
    border-bottom: 1px solid rgba(0,0,0,0.05); transition: background 0.15s;
}
#modalEnviarExtensao .aula-item:hover { background: rgba(23,162,184,0.04); }
#modalEnviarExtensao .aula-item:last-child { border-bottom: none; }
#modalEnviarExtensao .aula-item input[type="checkbox"] {
    width: 18px; height: 18px; margin-right: 12px; flex-shrink: 0; cursor: pointer;
}
#modalEnviarExtensao .aula-item .aula-data {
    font-weight: 600; font-size: 0.85em; color: #333; min-width: 80px;
}
#modalEnviarExtensao .aula-item .aula-info {
    flex: 1; font-size: 0.8em; color: #666; margin: 0 10px;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
#modalEnviarExtensao .aula-item .aula-status {
    font-size: 0.72em; padding: 3px 10px; border-radius: 20px;
    font-weight: 600; flex-shrink: 0;
}
#modalEnviarExtensao .aula-item .status-enviada {
    background: rgba(40,167,69,0.12); color: #155724;
}
#modalEnviarExtensao .aula-item .status-pendente {
    background: rgba(255,193,7,0.15); color: #856404;
}
#modalEnviarExtensao .aula-item.selecionada {
    background: rgba(23,162,184,0.08);
}
</style>

<script>
// --- Modal Enviar para Extensao ---
let modalAulasCache = [];      // Todas as aulas da turma/disciplina
let modalAulasFiltradas = [];  // Aulas apos filtro
let modalAulasSelecionadas = new Set(); // IDs das aulas selecionadas

function abrirModalEnviarExtensao() {
    if(turmaSelecionada<=0 || discSelecionada<=0){
        mostrarToast('Selecione uma turma e disciplina primeiro!','erro'); return;
    }
    // Pega nomes dos selects
    const turmaSel = document.getElementById('selTurma');
    const discSel = document.getElementById('selDisciplina');
    const turmaNome = turmaSel && turmaSel.selectedIndex > 0 ? turmaSel.options[turmaSel.selectedIndex].text : 'Turma ' + turmaSelecionada;
    const discNome = discSel && discSel.selectedIndex > 0 ? discSel.options[discSel.selectedIndex].text : 'Disciplina ' + discSelecionada;
    document.getElementById('envioTurmaNome').textContent = turmaNome;
    document.getElementById('envioDiscNome').textContent = discNome;
    document.getElementById('modalEnviarExtensao').classList.add('ativo');

    // Resetar filtros ao abrir modal
    document.getElementById('envioFiltroMes').value = '';
    document.getElementById('envioMostrarEnviadas').checked = true;

    // Sempre comecar no passo 1
    mostrarPasso(1);

    modalAulasSelecionadas.clear();
    buscarAulasParaModal();
}
function fecharModalEnviarExtensao() {
    document.getElementById('modalEnviarExtensao').classList.remove('ativo');
}

/**
 * Copia apenas os dados de AULAS para o clipboard (formato 8 colunas)
 */
async function copiarAulasParaExtensao() {
    if(modalAulasSelecionadas.size === 0) {
        mostrarToast('Selecione pelo menos uma aula!','erro'); return;
    }
    const ids = Array.from(modalAulasSelecionadas);
    const aulasParaEnviar = modalAulasCache.filter(a => modalAulasSelecionadas.has(a.id));
    
    let textoAulas = '';
    aulasParaEnviar.forEach(a => {
        textoAulas += `${a.data_formatada}\t${a.dia_semana}\t${a.quantidade}\t${a.modo_aula}\t${a.tipo_aula}\t${a.objetos_conhecimento || 'Aula realizada de acordo com o plano competente.'}\t${a.metodologia}\t${a.observacoes || ''}\n`;
    });
    
    console.log('[COPIAR-AULAS] Texto:', textoAulas);
    mostrarPreviewCopia('Aulas para Extensão', textoAulas.trim(), 'aulas');
}

/**
 * Copia apenas os dados de FREQUENCIAS para o clipboard (formato 2 colunas: data + tempos)
 */
/**
 * Mostra preview do conteudo antes de copiar
 */
function mostrarPreviewCopia(titulo, texto, tipo) {
    const previewId = 'preview-copia-container';
    let container = document.getElementById(previewId);
    if (!container) {
        container = document.createElement('div');
        container.id = previewId;
        container.style.cssText = 'position:fixed; bottom:20px; right:20px; z-index:999999; background:rgba(255,255,255,0.97); border:2px solid #17a2b8; border-radius:16px; padding:20px; box-shadow:0 12px 40px rgba(0,0,0,0.2); max-width:500px; font-family:Segoe UI,Arial; font-size:0.9em;';
        document.body.appendChild(container);
    }
    
    const corHeader = tipo === 'aulas' ? '#007bff' : '#17a2b8';
    const icone = tipo === 'aulas' ? '📝' : '📊';
    
    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
            <strong style="color:${corHeader}; font-size:1.1em;">${icone} ${titulo}</strong>
            <button onclick="document.getElementById('${previewId}').remove()" style="background:none; border:none; font-size:1.2em; cursor:pointer;">✕</button>
        </div>
        <textarea id="preview-texto-copia" style="width:100%; height:120px; font-family:monospace; font-size:0.82em; border:1px solid #ddd; border-radius:8px; padding:10px; resize:vertical;" readonly>${texto}</textarea>
        <div style="margin-top:12px; display:flex; gap:10px;">
            <button onclick="copiarDoPreview('${tipo}')" style="flex:1; padding:10px; background:linear-gradient(135deg, ${corHeader}, #138496); color:white; border:none; border-radius:10px; font-weight:600; cursor:pointer;">📋 Copiar para Clipboard</button>
        </div>
        <div id="preview-status" style="margin-top:8px; font-size:0.8em; color:#888;"></div>
    `;
    
    // Expoe a funcao de copiar globalmente
    window._textoParaCopiar = texto;
    window._tipoCopia = tipo;
}

function copiarDoPreview(tipo) {
    const texto = window._textoParaCopiar || '';
    const statusEl = document.getElementById('preview-status');
    
    navigator.clipboard.writeText(texto).then(() => {
        if (statusEl) statusEl.innerHTML = '<span style="color:#28a745;">✅ Copiado! Agora vá na extensão e clique "Buscar do Painel"</span>';
        setTimeout(() => {
            const container = document.getElementById('preview-copia-container');
            if (container) container.remove();
        }, 3000);
    }).catch(err => {
        console.error('Erro ao copiar:', err);
        if (statusEl) statusEl.innerHTML = '<span style="color:#dc3545;">❌ Erro. Selecione o texto manualmente e copie (Ctrl+C)</span>';
        // Tenta selecionar o texto
        const ta = document.getElementById('preview-texto-copia');
        if (ta) { ta.removeAttribute('readonly'); ta.select(); }
    });
}

async function copiarFrequenciasParaExtensao() {
    if(modalAulasSelecionadas.size === 0) {
        mostrarToast('Selecione pelo menos uma aula!','erro'); return;
    }
    const aulasParaEnviar = modalAulasCache.filter(a => modalAulasSelecionadas.has(a.id));
    
    let textoFreq = '';
    aulasParaEnviar.forEach(a => {
        const tempos = a.tempos || '1,2';
        textoFreq += `${a.data_formatada}\t${tempos}\n`;
    });
    
    console.log('[COPIAR-FREQ] Texto:', textoFreq);
    mostrarPreviewCopia('Frequências para Extensão', textoFreq.trim(), 'frequencias');
}

async function buscarAulasParaModal() {
    // Limpa cache anterior antes do fetch
    modalAulasCache = [];
    modalAulasFiltradas = [];
    console.log(`[MODAL] Buscando aulas para turma=${turmaSelecionada}, disciplina=${discSelecionada}`);

    const listaEl = document.getElementById('envioListaAulas');
    listaEl.innerHTML = '<div style="padding:30px; text-align:center; color:#999;">&#9203; Carregando aulas...</div>';

    try {
        const r = await fetch(`api/carregar-aulas.php?turma=${turmaSelecionada}&disciplina=${discSelecionada}`);
        const j = await r.json();

        console.log(`[MODAL] API retornou:`, j);
        console.log(`[MODAL] ${j.aulas?.length || 0} aulas, turma=${j.turma_nome}, disc=${j.disc_nome}`);

        if(j.status !== 'ok') {
            listaEl.innerHTML = '<div style="padding:30px; text-align:center; color:#e74c3c;">Erro ao carregar aulas.</div>';
            return;
        }

        modalAulasCache = j.aulas || [];

        // Atualiza resumo
        const pendentes = j.total_pendentes || 0;
        const enviadas = j.total_enviadas || 0;
        document.getElementById('envioResumo').innerHTML =
            `(${j.total} total${pendentes>0 ? ' | <span style="color:#e67e22;">'+pendentes+' pendente(s)</span>' : ''}${enviadas>0 ? ' | <span style="color:#27ae60;">'+enviadas+' enviada(s)</span>' : ''})`;

        filtrarAulasModal();
    } catch(e) {
        console.error(e);
        listaEl.innerHTML = '<div style="padding:30px; text-align:center; color:#e74c3c;">Erro de conexao.</div>';
    }
}

function filtrarAulasModal() {
    const mesFiltro = document.getElementById('envioFiltroMes').value;
    const mostrarEnviadas = document.getElementById('envioMostrarEnviadas').checked;

    modalAulasFiltradas = modalAulasCache.filter(a => {
        // Filtro por mes
        if(mesFiltro) {
            const data = new Date(a.data + 'T12:00:00');
            if((data.getMonth()+1) != parseInt(mesFiltro)) return false;
        }
        // Filtro por envio
        if(!mostrarEnviadas && a.enviada) return false;
        return true;
    });

    renderizarListaModal();
}

function renderizarListaModal() {
    const listaEl = document.getElementById('envioListaAulas');
    document.getElementById('envioContadorModal').textContent = modalAulasFiltradas.length + ' aula(s)';

    if(modalAulasFiltradas.length === 0) {
        listaEl.innerHTML = '<div style="padding:30px; text-align:center; color:#999;">Nenhuma aula encontrada com os filtros atuais.</div>';
        atualizarContadorSelecionadas();
        return;
    }

    let html = '';
    const mesesPt = ['','Janeiro','Fevereiro','Marco','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

    modalAulasFiltradas.forEach(a => {
        const dataObj = new Date(a.data + 'T12:00:00');
        const mesStr = mesesPt[dataObj.getMonth()+1];
        const isSel = modalAulasSelecionadas.has(a.id);
        const statusClass = a.enviada ? 'status-enviada' : 'status-pendente';
        const statusText = a.enviada ? '&#9989; Enviada' : '&#9203; Pendente';

        html += `<div class="aula-item ${isSel?'selecionada':''}" data-id="${a.id}">
            <input type="checkbox" ${isSel?'checked':''} onchange="toggleSelecaoModal(${a.id}, this.checked)">
            <div class="aula-data">${a.data_formatada}</div>
            <div class="aula-info">${a.modo_aula} | ${a.tipo_aula} | ${a.metodologia.substring(0,35)}${a.metodologia.length>35?'...':''}</div>
            <div class="aula-status ${statusClass}">${statusText}</div>
        </div>`;
    });

    listaEl.innerHTML = html;
    atualizarContadorSelecionadas();
}

function toggleSelecaoModal(id, checked) {
    if(checked) modalAulasSelecionadas.add(id);
    else modalAulasSelecionadas.delete(id);

    // Atualiza visual
    const item = document.querySelector(`.aula-item[data-id="${id}"]`);
    if(item) item.classList.toggle('selecionada', checked);
    atualizarContadorSelecionadas();
}

function marcarTodasModal(checked) {
    modalAulasFiltradas.forEach(a => {
        if(checked) modalAulasSelecionadas.add(a.id);
        else modalAulasSelecionadas.delete(a.id);
    });
    renderizarListaModal();
}

function marcarPendentesModal() {
    modalAulasFiltradas.forEach(a => {
        if(!a.enviada) modalAulasSelecionadas.add(a.id);
        else modalAulasSelecionadas.delete(a.id);
    });
    renderizarListaModal();
}

function atualizarContadorSelecionadas() {
    document.getElementById('envioSelecionadasContador').textContent = modalAulasSelecionadas.size;
}

// === CONTROLE DE PASSOS DO MODAL ===
function mostrarPasso(n) {
    document.getElementById('modalFooterPasso1').style.display = (n === 1) ? 'flex' : 'none';
    document.getElementById('modalFooterPasso2').style.display = (n === 2) ? 'flex' : 'none';
    document.getElementById('modalFooterPasso3').style.display = (n === 3) ? 'flex' : 'none';
}
function voltarParaPasso1() { mostrarPasso(1); }

async function confirmarEnvioAulas() {
    if(modalAulasSelecionadas.size === 0) {
        mostrarToast('Selecione pelo menos uma aula!','erro'); return;
    }

    const btn = event.target;
    btn.disabled = true;
    btn.innerHTML = '&#9203; Enviando...';

    try {
        const ids = Array.from(modalAulasSelecionadas);
        const aulasParaEnviar = modalAulasCache.filter(a => modalAulasSelecionadas.has(a.id));

        // Formato AULAS: 8 colunas (data, dia_semana, quantidade, modo_aula, tipo_aula, objetos_conhecimento, metodologia, observacoes)
        let textoAulas = '';
        aulasParaEnviar.forEach(a => {
            textoAulas += `${a.data_formatada}\t${a.dia_semana}\t${a.quantidade}\t${a.modo_aula}\t${a.tipo_aula}\t${a.objetos_conhecimento || 'Aula realizada de acordo com o plano competente.'}\t${a.metodologia}\t${a.observacoes || ''}\n`;
        });

        // Copia para clipboard
        await navigator.clipboard.writeText(textoAulas.trim());

        // Marca como enviadas no servidor
        await fetch('api/marcar-enviadas.php', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({aulas_ids: ids})
        });

        mostrarToast(`${aulasParaEnviar.length} aula(s) copiadas! Cole na aba Aulas da extensao SIAGE.`,'sucesso');

        // Atualiza status local
        modalAulasCache.forEach(a => {
            if(modalAulasSelecionadas.has(a.id)) a.enviada = 1;
        });
        modalAulasSelecionadas.clear();

        // Atualiza lista e recarrega aulas da pagina
        filtrarAulasModal();
        carregarAulas();

        // Avanca para o passo 2 (frequencias)
        mostrarPasso(2);
        mostrarToast('Aulas copiadas! Agora cole na aba Aulas da extensao SIAGE, depois volte aqui e clique "Copiar Frequencias".','sucesso');

    } catch(e) {
        console.error(e);
        mostrarToast('Erro ao enviar aulas. Tente novamente.','erro');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '&#128221; Copiar Aulas';
    }
}

async function confirmarEnvioFrequencias() {
    if(modalAulasSelecionadas.size === 0) {
        mostrarToast('Selecione pelo menos uma aula!','erro'); return;
    }

    const btn = event.target;
    btn.disabled = true;
    btn.innerHTML = '&#9203; Enviando...';

    try {
        const ids = Array.from(modalAulasSelecionadas);
        const aulasParaEnviar = modalAulasCache.filter(a => modalAulasSelecionadas.has(a.id));

        // Formato FREQUENCIAS: 2 colunas (data, tempos)
        let textoFreq = '';
        aulasParaEnviar.forEach(a => {
            textoFreq += `${a.data_formatada}\t${a.tempos || '1,2'}\n`;
        });

        // Copia para clipboard
        await navigator.clipboard.writeText(textoFreq.trim());

        // Marca como enviadas no servidor
        await fetch('api/marcar-enviadas.php', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({aulas_ids: ids})
        });

        mostrarToast(`${aulasParaEnviar.length} frequencia(s) copiadas! Cole na aba Frequencias da extensao SIAGE.`,'sucesso');

        // Atualiza status local
        modalAulasCache.forEach(a => {
            if(modalAulasSelecionadas.has(a.id)) a.enviada = 1;
        });
        modalAulasSelecionadas.clear();

        // Atualiza lista e recarrega aulas da pagina
        filtrarAulasModal();
        carregarAulas();

        // Avanca para o passo 3 (concluido)
        mostrarPasso(3);
        mostrarToast('Frequencias copiadas! Cole na aba Frequencias da extensao SIAGE.','sucesso');

    } catch(e) {
        console.error(e);
        mostrarToast('Erro ao enviar frequencias. Tente novamente.','erro');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '&#128203; Copiar Frequencias';
    }
}
</script>

</body></html>