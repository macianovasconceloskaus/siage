<?php
// config.php - SIAGE Auto
// Hospedagem: macianovasconcelos.online

// Output buffering
if (!ob_get_level()) { ob_start(); }

// MOSTRAR erros em desenvolvimento (mude para '0' em producao)
ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);

// BANCO DE DADOS
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'joaom981_siage');
define('DB_USER', 'joaom981_joao');
define('DB_PASS', 'Ad51d4d5dd55');

// URL DO SISTEMA
define('SITE_URL', 'https://macianovasconcelos.online/siage');
define('BASE_URL', SITE_URL);

date_default_timezone_set('America/Sao_Paulo');

// Sessao
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Conexao PDO
try {
    $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    while (ob_get_level()) { ob_end_clean(); }
    die("Erro de conexao com o banco de dados.");
}

// === FUNCOES HELPERS ===

/**
 * Verifica se uma tabela existe no banco de dados
 */
if (!function_exists('tabelaExiste')) {
    function tabelaExiste($pdo, $tabela) {
        try {
            $stmt = $pdo->query("SHOW TABLES LIKE '" . $tabela . "'");
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            return false;
        }
    }
}

/**
 * Executa uma query com seguranca, retorna resultado ou valor padrao em caso de erro
 */
if (!function_exists('querySegura')) {
    function querySegura($pdo, $sql, $params = [], $default = null) {
        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            error_log("[SIAGE] Query erro: " . $e->getMessage());
            return $default;
        }
    }
}

/**
 * Retorna um valor unico com seguranca
 */
if (!function_exists('fetchColumnSeguro')) {
    function fetchColumnSeguro($pdo, $sql, $params = [], $default = 0) {
        $stmt = querySegura($pdo, $sql, $params);
        if ($stmt === null) return $default;
        try {
            $val = $stmt->fetchColumn();
            return ($val !== false && $val !== null) ? $val : $default;
        } catch (PDOException $e) {
            return $default;
        }
    }
}

/**
 * Retorna fetchAll com seguranca
 */
if (!function_exists('fetchAllSeguro')) {
    function fetchAllSeguro($pdo, $sql, $params = [], $default = []) {
        $stmt = querySegura($pdo, $sql, $params);
        if ($stmt === null) return $default;
        try {
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            return $default;
        }
    }
}

if (!function_exists('redirect')) {
    function redirect($url) {
        while (ob_get_level()) { ob_end_clean(); }
        header("Location: " . $url);
        exit;
    }
}

// CORS - Permite a extensao chamar a API (somente para arquivos em /api/)
$isApi = strpos($_SERVER['SCRIPT_NAME'], '/api/') !== false;
if ($isApi && !headers_sent()) {
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: Content-Type, X-API-Key, Authorization");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    header("Content-Type: application/json; charset=utf-8");
    
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit;
    }
}
