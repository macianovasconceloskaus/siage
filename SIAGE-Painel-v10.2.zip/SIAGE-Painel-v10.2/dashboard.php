<?php
require_once 'config.php';
if (!isset($_SESSION['usuario_id'])) { header('Location: index.php'); exit; }
$usuarioId = $_SESSION['usuario_id'];
$usuarioNome = $_SESSION['usuario_nome'] ?? 'Professor';

$stmt = querySegura($pdo, "SELECT api_key FROM usuarios WHERE id = ?", [$usuarioId]);
$usuario = ($stmt !== null) ? $stmt->fetch(PDO::FETCH_ASSOC) : null;
$apiKey = $usuario['api_key'] ?? '';

$totalTurmas = tabelaExiste($pdo, 'turmas') ? fetchColumnSeguro($pdo, "SELECT COUNT(*) FROM turmas WHERE usuario_id = ?", [$usuarioId], 0) : 0;
$totalDisc = tabelaExiste($pdo, 'disciplinas') ? fetchColumnSeguro($pdo, "SELECT COUNT(*) FROM disciplinas WHERE usuario_id = ?", [$usuarioId], 0) : 0;
$totalAulas = tabelaExiste($pdo, 'aulas_professor') ? fetchColumnSeguro($pdo, "SELECT COUNT(*) FROM aulas_professor WHERE usuario_id = ?", [$usuarioId], 0) : 0;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SIAGE Auto - Painel</title><link rel="stylesheet" href="assets/painel.css"></head>
<body>
<div class="container">
<div class="card">
    <div class="header">
        <div><h1>SIAGE Auto</h1><span>Painel de Controle</span></div>
        <a href="logout.php" class="btn btn-vermelho" style="padding:8px 16px;font-size:0.82em;">&#10005; Sair</a>
    </div>
    <div class="card-body">
        <h2 style="color:#333;margin-bottom:20px;font-size:1.15em;">Ola, <?php echo htmlspecialchars($usuarioNome); ?>! &#128075;</h2>

        <div class="cards-dash">
            <div class="card-stat"><div class="numero" style="color:#17a2b8;"><?php echo $totalTurmas; ?></div><div class="label">Turmas</div></div>
            <div class="card-stat"><div class="numero" style="color:#fd7e14;"><?php echo $totalDisc; ?></div><div class="label">Disciplinas</div></div>
            <div class="card-stat"><div class="numero" style="color:#28a745;"><?php echo $totalAulas; ?></div><div class="label">Aulas Cad.</div></div>
        </div>

        <div class="menu">
            <a href="gerenciar-turmas.php" class="btn btn-ciano" style="flex:1;justify-content:center;font-size:1em;padding:14px;">&#128218; Turmas e Disciplinas</a>
            <a href="calendario.php" class="btn btn-ciano" style="flex:1;justify-content:center;font-size:1em;padding:14px;">&#128197; Calendario Letivo</a>
        </div>

        <div style="margin-top:24px;padding:22px;background:linear-gradient(135deg,rgba(23,162,184,0.08),rgba(102,126,234,0.08));backdrop-filter:blur(15px);border-radius:18px;border:1px solid rgba(23,162,184,0.2);">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">
                <span style="font-size:1.6em;">&#128229;</span>
                <div>
                    <strong style="font-size:0.95em;color:#333;">Integracao com a Extensao Chrome</strong>
                    <div style="font-size:0.8em;color:#666;">A extensao pode buscar aulas automaticamente do painel</div>
                </div>
            </div>

            <div style="background:rgba(255,255,255,0.7);border-radius:14px;padding:16px;border:1px solid rgba(0,0,0,0.06);">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;flex-wrap:wrap;gap:8px;">
                    <strong style="font-size:0.85em;color:#555;">&#128273; Sua API Key:</strong>
                    <span style="font-size:0.72em;color:#888;">Mantenha em segredo!</span>
                </div>
                <div id="apiKeyBox" style="background:rgba(255,255,255,0.9);border:1px solid rgba(0,0,0,0.08);border-radius:10px;padding:12px 16px;font-family:'SF Mono','Fira Code',monospace;font-size:0.82em;color:#333;word-break:break-all;margin-bottom:12px;box-shadow:inset 0 1px 3px rgba(0,0,0,0.04);"><?php echo htmlspecialchars($apiKey); ?></div>
                <div style="display:flex;gap:10px;flex-wrap:wrap;">
                    <button class="btn btn-verde" onclick="copiarApiKey()" style="padding:8px 20px;font-size:0.85em;">&#128203; Copiar API Key</button>
                    <button class="btn btn-ciano" onclick="mostrarInstrucoes()" style="padding:8px 20px;font-size:0.85em;">&#128161; Como Configurar</button>
                </div>
            </div>

            <div id="instrucoesExtensao" style="display:none;margin-top:16px;padding:16px;background:rgba(255,255,255,0.6);border-radius:12px;font-size:0.85em;color:#555;line-height:1.8;">
                <strong style="color:#333;">Configurando a extensao:</strong>
                <ol style="margin:8px 0 0 18px;padding:0;">
                    <li>Clique em <strong>"Copiar API Key"</strong> acima</li>
                    <li>Abra a <strong>extensao SIAGE</strong> no Chrome (clique no icone)</li>
                    <li>Vá na aba <strong>"Configuracao"</strong></li>
                    <li>Cole a API Key no campo indicado</li>
                    <li>Clique em <strong>"Salvar Configuracao"</strong></li>
                    <li>Pronto! Agora voce pode <strong>buscar aulas diretamente do painel</strong> sem copiar e colar!</li>
                </ol>
            </div>
        </div>

        <div class="info-box" style="margin-top:20px;">
            <strong>&#128161; Como usar o Painel:</strong>
            <ol style="margin:10px 0 0 20px;padding:0;line-height:1.8;">
                <li><strong>Cadastre suas turmas</strong> e disciplinas</li>
                <li><strong>Vincule</strong> disciplinas as turmas</li>
                <li>Acesse o <strong>Calendario Letivo</strong></li>
                <li>Selecione <strong>turma + disciplina</strong></li>
                <li><strong>Clique nos dias letivos</strong> do calendario (use Ctrl ou Shift para multi-selecao)</li>
                <li>Preencha os dados da aula e <strong>salve</strong></li>
                <li>Na extensao, clique em <strong>"Buscar do Painel"</strong> para carregar automaticamente!</li>
            </ol>
        </div>
    </div>
    <div class="rodape">Desenvolvido por <strong style="color:#17a2b8;">Maciano Vasconcelos</strong></div>
</div>
</div>
<script>
function copiarApiKey(){
    const k=document.getElementById('apiKeyBox').textContent.trim();
    navigator.clipboard.writeText(k).then(()=>{
        const btn = event.target;
        const txtOriginal = btn.innerHTML;
        btn.innerHTML = '&#9989; Copiado!';
        btn.style.background = 'linear-gradient(135deg, #28a745, #20c997)';
        setTimeout(()=>{ btn.innerHTML = txtOriginal; btn.style.background = ''; }, 2000);
    }).catch(()=>{
        const r=document.createRange();r.selectNode(document.getElementById('apiKeyBox'));window.getSelection().removeAllRanges();window.getSelection().addRange(r);document.execCommand('copy');
        alert('Copiado!');
    });
}
function mostrarInstrucoes(){
    const el=document.getElementById('instrucoesExtensao');
    el.style.display=el.style.display==='none'?'block':'none';
}
</script>
</body></html>
