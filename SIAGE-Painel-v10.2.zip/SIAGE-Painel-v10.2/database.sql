-- SIAGE Auto v4 - Turmas, Disciplinas, Calendario Interativo

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    nome VARCHAR(255) NOT NULL,
    api_key VARCHAR(64) UNIQUE NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS configuracoes_calendario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    p1_inicio DATE NOT NULL DEFAULT '2026-02-10',
    p1_fim DATE NOT NULL DEFAULT '2026-04-23',
    p2_inicio DATE NOT NULL DEFAULT '2026-04-24',
    p2_fim DATE NOT NULL DEFAULT '2026-07-23',
    p3_inicio DATE NOT NULL DEFAULT '2026-07-24',
    p3_fim DATE NOT NULL DEFAULT '2026-10-05',
    p4_inicio DATE NOT NULL DEFAULT '2026-10-06',
    p4_fim DATE NOT NULL DEFAULT '2026-12-17',
    dias_semana VARCHAR(20) NOT NULL DEFAULT '1,2,3,4,5',
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    UNIQUE KEY uk_config_usuario (usuario_id)
);

-- TURMAS que o professor leciona
CREATE TABLE IF NOT EXISTS turmas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    nome VARCHAR(255) NOT NULL,
    serie VARCHAR(50) DEFAULT NULL,
    turno VARCHAR(50) DEFAULT NULL,
    sala VARCHAR(50) DEFAULT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- DISCIPLINAS que o professor leciona
CREATE TABLE IF NOT EXISTS disciplinas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    nome VARCHAR(255) NOT NULL,
    abreviacao VARCHAR(50) DEFAULT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- VINCULO: qual disciplina em qual turma
CREATE TABLE IF NOT EXISTS turma_disciplina (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    turma_id INT NOT NULL,
    disciplina_id INT NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (turma_id) REFERENCES turmas(id) ON DELETE CASCADE,
    FOREIGN KEY (disciplina_id) REFERENCES disciplinas(id) ON DELETE CASCADE,
    UNIQUE KEY uk_turma_disc (usuario_id, turma_id, disciplina_id)
);

-- FERIADOS
CREATE TABLE IF NOT EXISTS feriados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    data DATE NOT NULL,
    tipo ENUM('feriado','recesso','recuperacao') NOT NULL DEFAULT 'feriado',
    descricao VARCHAR(255) DEFAULT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- AULAS vinculadas a turma + disciplina
CREATE TABLE IF NOT EXISTS aulas_professor (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    turma_id INT NOT NULL,
    disciplina_id INT NOT NULL,
    data DATE NOT NULL,
    dia_semana VARCHAR(20) NOT NULL,
    quantidade INT NOT NULL DEFAULT 1,
    modo_aula VARCHAR(50) NOT NULL DEFAULT 'Aula',
    tipo_aula VARCHAR(50) NOT NULL DEFAULT 'Avulso',
    objetos_conhecimento TEXT,
    metodologia VARCHAR(200) NOT NULL DEFAULT 'Aula dialogada',
    observacoes TEXT,
    frequencia_registrada TINYINT(1) NOT NULL DEFAULT 0,
    tempos VARCHAR(20) DEFAULT '1,2',
    periodo INT NOT NULL DEFAULT 1,
    enviada_extensao TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0=nao enviada, 1=enviada para extensao',
    data_envio_extensao DATETIME DEFAULT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (turma_id) REFERENCES turmas(id) ON DELETE CASCADE,
    FOREIGN KEY (disciplina_id) REFERENCES disciplinas(id) ON DELETE CASCADE,
    UNIQUE KEY uk_aula (usuario_id, turma_id, disciplina_id, data)
);
