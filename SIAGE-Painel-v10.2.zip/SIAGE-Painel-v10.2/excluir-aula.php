<?php
require_once 'config.php';
if (!isset($_SESSION['usuario_id'])) { header('Location: index.php'); exit; }
$id = (int)($_GET['id'] ?? 0);
$turma = (int)($_GET['turma'] ?? 0);
$disc = (int)($_GET['disciplina'] ?? 0);
if ($id && tabelaExiste($pdo, 'aulas_professor')) {
    $pdo->prepare("DELETE FROM aulas_professor WHERE id = ? AND usuario_id = ?")->execute([$id, $_SESSION['usuario_id']]);
}
$url = 'calendario.php';
if ($turma) $url .= '?turma=' . $turma;
if ($disc) $url .= ($turma ? '&' : '?') . 'disciplina=' . $disc;
header('Location: ' . $url);
exit;
