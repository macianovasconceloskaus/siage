<?php
// gerar-datas.php - Gera datas automaticamente baseado na configuracao
require_once 'config.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: calendario.php');
    exit;
}

$usuarioId = $_SESSION['usuario_id'];
$periodoFiltro = $_POST['periodo'] ?? 'todos';
$formato = $_POST['formato'] ?? 'frequencia';

// Busca configuracao do usuario
$stmt = $pdo->prepare("SELECT * FROM configuracoes_calendario WHERE usuario_id = ?");
$stmt->execute([$usuarioId]);
$config = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$config) {
    header('Location: calendario.php');
    exit;
}

// Busca feriados
$stmt = $pdo->prepare("SELECT data, tipo FROM feriados WHERE usuario_id = ?");
$stmt->execute([$usuarioId]);
$feriadosRaw = $stmt->fetchAll();
$feriadosMap = [];
foreach ($feriadosRaw as $f) {
    $feriadosMap[$f['data']] = $f['tipo'];
}

// Dias da semana permitidos
$diasSemana = explode(',', $config['dias_semana'] ?? '2,3,4,5');

// Define periodos
$periodos = [
    1 => ['inicio' => $config['p1_inicio'], 'fim' => $config['p1_fim']],
    2 => ['inicio' => $config['p2_inicio'], 'fim' => $config['p2_fim']],
    3 => ['inicio' => $config['p3_inicio'], 'fim' => $config['p3_fim']],
    4 => ['inicio' => $config['p4_inicio'], 'fim' => $config['p4_fim']],
];

// Limpa datas antigas do usuario
$stmt = $pdo->prepare("DELETE FROM datas_geradas WHERE usuario_id = ?");
$stmt->execute([$usuarioId]);

// Gera datas
$periodosParaGerar = ($periodoFiltro === 'todos') ? [1, 2, 3, 4] : [(int)$periodoFiltro];

foreach ($periodosParaGerar as $pNum) {
    if (!isset($periodos[$pNum])) continue;
    
    $inicio = new DateTime($periodos[$pNum]['inicio']);
    $fim = new DateTime($periodos[$pNum]['fim']);
    $intervalo = new DateInterval('P1D');
    
    $periodo = new DatePeriod($inicio, $intervalo, $fim->modify('+1 day'));
    
    foreach ($periodo as $data) {
        $dataStr = $data->format('Y-m-d');
        $diaSemana = $data->format('w'); // 0=dom, 6=sab
        
        // Pula fim de semana
        if ($diaSemana == 0 || $diaSemana == 6) continue;
        
        // Pula se nao esta nos dias da semana selecionados
        if (!in_array((string)$diaSemana, $diasSemana)) continue;
        
        // Pula feriados e recessos
        if (isset($feriadosMap[$dataStr])) {
            $tipoFeriado = $feriadosMap[$dataStr];
            if ($tipoFeriado === 'feriado' || $tipoFeriado === 'recesso') continue;
        }
        
        // Insere data gerada
        $tempos = ($formato === 'frequencia') ? '1,2' : '1';
        $stmt = $pdo->prepare("INSERT INTO datas_geradas (usuario_id, data, periodo, tempos, formato) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$usuarioId, $dataStr, $pNum, $tempos, $formato]);
    }
}

header('Location: calendario.php');
exit;
