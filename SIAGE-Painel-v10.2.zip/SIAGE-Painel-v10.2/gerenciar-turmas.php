<?php
// gerenciar-turmas.php - Cadastro de Turmas, Disciplinas e Vinculos
require_once 'config.php';

if (!isset($_SESSION['usuario_id'])) { header('Location: index.php'); exit; }

$usuarioId = $_SESSION['usuario_id'];
$erro = ''; $ok = '';

// --- CADASTRAR TURMA ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'turma') {
    $nome = trim($_POST['nome'] ?? '');
    $serie = trim($_POST['serie'] ?? '');
    $turno = trim($_POST['turno'] ?? '');
    $sala = trim($_POST['sala'] ?? '');
    if ($nome && tabelaExiste($pdo, 'turmas')) {
        $stmt = $pdo->prepare("INSERT INTO turmas (usuario_id, nome, serie, turno, sala) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$usuarioId, $nome, $serie, $turno, $sala]);
        $ok = 'Turma cadastrada!'; 
    }
}

// --- CADASTRAR DISCIPLINA ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'disciplina') {
    $nome = trim($_POST['nome'] ?? '');
    $abrev = trim($_POST['abreviacao'] ?? '');
    if ($nome && tabelaExiste($pdo, 'disciplinas')) {
        $stmt = $pdo->prepare("INSERT INTO disciplinas (usuario_id, nome, abreviacao) VALUES (?, ?, ?)");
        $stmt->execute([$usuarioId, $nome, $abrev]);
        $ok = 'Disciplina cadastrada!';
    }
}

// --- VINCULAR TURMA + DISCIPLINA ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'vincular') {
    $turmaId = (int)($_POST['turma_id'] ?? 0);
    $discId = (int)($_POST['disciplina_id'] ?? 0);
    if ($turmaId && $discId && tabelaExiste($pdo, 'turma_disciplina')) {
        try {
            $stmt = $pdo->prepare("INSERT INTO turma_disciplina (usuario_id, turma_id, disciplina_id) VALUES (?, ?, ?)");
            $stmt->execute([$usuarioId, $turmaId, $discId]);
            $ok = 'Vinculo criado!';
        } catch (PDOException $e) { $erro = 'Ja vinculado ou erro.'; }
    }
}

// --- EXCLUIR ---
if (isset($_GET['excluir']) && isset($_GET['tipo'])) {
    $tipo = $_GET['tipo'];
    $id = (int)$_GET['excluir'];
    if ($tipo === 'turma' && tabelaExiste($pdo, 'turmas')) {
        $pdo->prepare("DELETE FROM turmas WHERE id = ? AND usuario_id = ?")->execute([$id, $usuarioId]);
    } elseif ($tipo === 'disciplina' && tabelaExiste($pdo, 'disciplinas')) {
        $pdo->prepare("DELETE FROM disciplinas WHERE id = ? AND usuario_id = ?")->execute([$id, $usuarioId]);
    } elseif ($tipo === 'vinculo' && tabelaExiste($pdo, 'turma_disciplina')) {
        $pdo->prepare("DELETE FROM turma_disciplina WHERE id = ? AND usuario_id = ?")->execute([$id, $usuarioId]);
    }
    header('Location: gerenciar-turmas.php'); exit;
}

// --- LISTAR ---
$turmas = tabelaExiste($pdo, 'turmas') ? fetchAllSeguro($pdo, "SELECT * FROM turmas WHERE usuario_id = ? ORDER BY nome", [$usuarioId]) : [];
$disciplinas = tabelaExiste($pdo, 'disciplinas') ? fetchAllSeguro($pdo, "SELECT * FROM disciplinas WHERE usuario_id = ? ORDER BY nome", [$usuarioId]) : [];
$vinculos = [];
if (tabelaExiste($pdo, 'turma_disciplina')) {
    $vinculos = fetchAllSeguro($pdo,
        "SELECT td.*, t.nome as turma_nome, t.serie, d.nome as disc_nome, d.abreviacao 
         FROM turma_disciplina td 
         JOIN turmas t ON td.turma_id = t.id 
         JOIN disciplinas d ON td.disciplina_id = d.id 
         WHERE td.usuario_id = ? ORDER BY t.nome, d.nome", [$usuarioId]);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SIAGE Auto - Turmas e Disciplinas</title>
<link rel="stylesheet" href="assets/painel.css">
<style>
.glass-box { background: rgba(255,255,255,0.65); backdrop-filter: blur(20px); border-radius: 20px; border: 1px solid rgba(255,255,255,0.4); box-shadow: 0 8px 32px rgba(0,0,0,0.1); padding: 24px; margin: 16px 0; animation: glassIn 0.5s ease-out; }
.glass-box h3 { color: #333; font-size: 1em; margin-bottom: 16px; }
.glass-box h3 span { color: #17a2b8; }
.grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.form-mini { display: flex; gap: 10px; flex-wrap: wrap; align-items: flex-end; }
.form-mini input, .form-mini select { flex: 1; min-width: 120px; padding: 10px 12px; border: 1px solid rgba(0,0,0,0.1); border-radius: 10px; font-size: 0.88em; background: rgba(255,255,255,0.8); font-family: 'Segoe UI', sans-serif; }
.form-mini input:focus, .form-mini select:focus { outline: none; border-color: rgba(23,162,184,0.5); box-shadow: 0 0 0 3px rgba(23,162,184,0.1); }
.form-mini .btn { padding: 10px 18px; font-size: 0.85em; }
.item-lista { display: flex; justify-content: space-between; align-items: center; padding: 10px 14px; background: rgba(255,255,255,0.5); border-radius: 10px; margin-bottom: 6px; border: 1px solid rgba(0,0,0,0.05); transition: all 0.2s; }
.item-lista:hover { background: rgba(255,255,255,0.8); transform: translateX(4px); }
.item-lista .nome { font-weight: 500; color: #333; font-size: 0.9em; }
.item-lista .info { font-size: 0.78em; color: #888; }
.item-lista .acoes { display: flex; gap: 6px; }
.vinculo-card { background: rgba(23,162,184,0.08); border: 1px solid rgba(23,162,184,0.15); border-radius: 12px; padding: 12px 16px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center; }
.vinculo-card .turma { font-weight: 600; color: #333; font-size: 0.9em; }
.vinculo-card .disc { color: #17a2b8; font-size: 0.85em; }
@media (max-width: 768px) { .grid-2 { grid-template-columns: 1fr; } }
</style>
</head>
<body>
<div class="container" style="max-width: 800px;">
<div class="card">
    <div class="header">
        <div><h1>SIAGE Auto</h1><span>Turmas e Disciplinas</span></div>
        <a href="calendario.php" class="btn btn-cinza" style="padding:8px 16px;font-size:0.82em;">&#8592; Calendario</a>
    </div>
    <div class="card-body">

<?php if ($ok): ?><div class="alerta alerta-sucesso"><?php echo $ok; ?></div><?php endif; ?>
<?php if ($erro): ?><div class="alerta alerta-erro"><?php echo $erro; ?></div><?php endif; ?>

<div class="grid-2">
    <!-- CADASTRAR TURMA -->
    <div class="glass-box">
        <h3>&#127979; Nova Turma</h3>
        <form method="POST" class="form-mini">
            <input type="hidden" name="acao" value="turma">
            <input type="text" name="nome" placeholder="Nome (ex: 1a SERIE C)" required>
            <input type="text" name="serie" placeholder="Serie (ex: 1o ano)">
            <input type="text" name="turno" placeholder="Turno (ex: Integral)">
            <input type="text" name="sala" placeholder="Sala (ex: SALA 03)">
            <button type="submit" class="btn btn-verde">+ Turma</button>
        </form>

        <?php if (!empty($turmas)): ?>
        <div style="margin-top: 16px; max-height: 200px; overflow-y: auto;">
            <?php foreach ($turmas as $t): ?>
            <div class="item-lista">
                <div>
                    <div class="nome"><?php echo htmlspecialchars($t['nome']); ?></div>
                    <div class="info"><?php echo $t['serie']; ?> <?php echo $t['turno']; ?> <?php echo $t['sala']; ?></div>
                </div>
                <a href="?excluir=<?php echo $t['id']; ?>&tipo=turma" class="btn btn-vermelho" style="padding:4px 10px;font-size:0.72em;" onclick="return confirm('Excluir turma?')">&#10005;</a>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- CADASTRAR DISCIPLINA -->
    <div class="glass-box">
        <h3>&#128214; Nova Disciplina</h3>
        <form method="POST" class="form-mini">
            <input type="hidden" name="acao" value="disciplina">
            <input type="text" name="nome" placeholder="Nome (ex: Arquitetura de Hardware)" required>
            <input type="text" name="abreviacao" placeholder="Abrev. (ex: ARQ)">
            <button type="submit" class="btn btn-verde">+ Disc.</button>
        </form>

        <?php if (!empty($disciplinas)): ?>
        <div style="margin-top: 16px; max-height: 200px; overflow-y: auto;">
            <?php foreach ($disciplinas as $d): ?>
            <div class="item-lista">
                <div>
                    <div class="nome"><?php echo htmlspecialchars($d['nome']); ?></div>
                    <?php if ($d['abreviacao']): ?><div class="info"><?php echo $d['abreviacao']; ?></div><?php endif; ?>
                </div>
                <a href="?excluir=<?php echo $d['id']; ?>&tipo=disciplina" class="btn btn-vermelho" style="padding:4px 10px;font-size:0.72em;" onclick="return confirm('Excluir disciplina?')">&#10005;</a>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- VINCULAR -->
<div class="glass-box">
    <h3>&#128279; Vincular Turma + Disciplina</h3>
    <?php if (empty($turmas) || empty($disciplinas)): ?>
        <p style="color: #888; font-size: 0.88em;">Cadastre turmas e disciplinas primeiro.</p>
    <?php else: ?>
    <form method="POST" class="form-mini">
        <input type="hidden" name="acao" value="vincular">
        <select name="turma_id" required>
            <option value="">-- Turma --</option>
            <?php foreach ($turmas as $t): ?><option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['nome']); ?></option><?php endforeach; ?>
        </select>
        <select name="disciplina_id" required>
            <option value="">-- Disciplina --</option>
            <?php foreach ($disciplinas as $d): ?><option value="<?php echo $d['id']; ?>"><?php echo htmlspecialchars($d['nome']); ?></option><?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-ciano">&#128279; Vincular</button>
    </form>
    <?php endif; ?>

    <?php if (!empty($vinculos)): ?>
    <div style="margin-top: 16px;">
        <h4 style="font-size: 0.88em; color: #555; margin-bottom: 10px;">Vinculos criados:</h4>
        <?php foreach ($vinculos as $v): ?>
        <div class="vinculo-card">
            <div>
                <div class="turma"><?php echo htmlspecialchars($v['turma_nome']); ?> <?php echo $v['serie']; ?></div>
                <div class="disc">&#128214; <?php echo htmlspecialchars($v['disc_nome']); ?> <?php echo $v['abreviacao'] ? '('.$v['abreviacao'].')' : ''; ?></div>
            </div>
            <a href="?excluir=<?php echo $v['id']; ?>&tipo=vinculo" class="btn btn-vermelho" style="padding:4px 10px;font-size:0.72em;" onclick="return confirm('Remover vinculo?')">&#128465;</a>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<div style="text-align: center; margin-top: 20px;">
    <a href="calendario.php" class="btn btn-ciano" style="font-size: 1em; padding: 14px 28px;">&#128197; Ir para o Calendario</a>
</div>

    </div>
    <div class="rodape">Desenvolvido por <strong style="color:#17a2b8;">Maciano Vasconcelos</strong></div>
</div>
</div>
</body></html>
