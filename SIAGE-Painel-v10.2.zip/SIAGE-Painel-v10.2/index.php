<?php
// index.php - Login SIAGE Auto
require_once 'config.php';

// Se ja estiver logado, vai pro painel
if (isset($_SESSION['usuario_id'])) {
    header('Location: dashboard.php');
    exit;
}

// Processar login
$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';
    
    $stmt = $pdo->prepare("SELECT id, nome, email, senha FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($usuario && password_verify($senha, $usuario['senha'])) {
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['usuario_nome'] = $usuario['nome'];
        header('Location: dashboard.php');
        exit;
    } else {
        $erro = 'Email ou senha incorretos.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIAGE Auto - Login</title>
    <link rel="stylesheet" href="assets/painel.css">
</head>
<body>

<div class="container" style="max-width: 480px;">

    <div class="card">
        <!-- HEADER -->
        <div class="header">
            <div>
                <h1>SIAGE Auto</h1>
                <span>Sistema de Automacao</span>
            </div>
        </div>

        <div class="card-body">
            
            <?php if ($erro): ?>
            <div class="alerta alerta-erro"><?php echo htmlspecialchars($erro); ?></div>
            <?php endif; ?>

            <!-- INFO BOX -->
            <div class="info-box">
                <strong>Bem-vindo!</strong><br>
                Faca login para acessar seu painel de controle.
                <ul>
                    <li>Configure suas turmas</li>
                    <li>Cadastre datas de aulas e frequencias</li>
                    <li>Obtenha sua API Key para a extensao</li>
                </ul>
            </div>

            <!-- FORMULARIO DE LOGIN -->
            <form method="POST" action="">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="professor@email.com" required>
                </div>

                <div class="form-group">
                    <label for="senha">Senha</label>
                    <div class="senha-wrapper">
                        <input type="password" id="senha" name="senha" placeholder="Sua senha" required>
                        <button type="button" class="btn-icone" onclick="toggleSenha()" title="Mostrar/Ocultar">👁</button>
                    </div>
                </div>

                <button type="submit" class="btn btn-ciano" style="width: 100%;">
                    ▶ Entrar
                </button>
            </form>

            <div style="text-align: center; margin-top: 16px; font-size: 0.82em; color: #888;">
                Acesso restrito. <a href="cadastro.php" style="color: #17a2b8; text-decoration: none;">Cadastro com convite</a>
            </div>

        </div>

        <!-- RODAPE -->
        <div class="rodape">
            Desenvolvido por <strong style="color: #17a2b8;">Maciano Vasconcelos</strong>
        </div>
    </div>

</div>

<script>
function toggleSenha() {
    const input = document.getElementById('senha');
    input.type = input.type === 'password' ? 'text' : 'password';
}
</script>

</body>
</html>
