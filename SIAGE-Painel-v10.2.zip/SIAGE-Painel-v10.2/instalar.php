<?php
require_once 'config.php';
$erro = ''; $ok = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    if (empty($nome) || empty($email) || empty($senha)) { $erro = 'Preencha todos os campos.'; }
    elseif (strlen($senha) < 4) { $erro = 'Senha muito curta.'; }
    else {
        // Verifica se ja existe usuario
        $stmt = querySegura($pdo, "SELECT COUNT(*) FROM usuarios");
        if ($stmt && $stmt->fetchColumn() > 0) { $erro = 'Ja existe usuario.'; }
        else {
            try {
                $apiKey = bin2hex(random_bytes(32));
                $hash = password_hash($senha, PASSWORD_DEFAULT);

                // Cria usuario
                $pdo->prepare("INSERT INTO usuarios (nome, email, senha, api_key) VALUES (?, ?, ?, ?)")
                    ->execute([$nome, $email, $hash, $apiKey]);
                $usuarioId = $pdo->lastInsertId();

                // Config padrao
                if (tabelaExiste($pdo, 'configuracoes_calendario')) {
                    $pdo->prepare("INSERT INTO configuracoes_calendario 
                        (usuario_id, p1_inicio, p1_fim, p2_inicio, p2_fim, p3_inicio, p3_fim, p4_inicio, p4_fim, dias_semana)
                        VALUES (?, '2026-02-10', '2026-04-23', '2026-04-24', '2026-07-23', '2026-07-24', '2026-10-05', '2026-10-06', '2026-12-17', '1,2,3,4,5')")
                        ->execute([$usuarioId]);
                }

                // Feriados Paraiba 2026
                if (tabelaExiste($pdo, 'feriados')) {
                    // Feriados e Recessos - Calendario Escolar PB 2026 (PDF oficial)
                    $feriadosPB = [
                        // === FERIADOS (F) ===
                        ['2026-01-01', 'feriado', 'Confraternizacao Universal'],
                        ['2026-01-06', 'feriado', 'Santos Reis (PB)'],
                        ['2026-02-16', 'feriado', 'Carnaval - Segunda'],
                        ['2026-02-17', 'feriado', 'Carnaval'],
                        ['2026-02-18', 'feriado', 'Quarta-feira de Cinzas'],
                        ['2026-04-03', 'feriado', 'Sexta-feira Santa'],
                        ['2026-04-21', 'feriado', 'Tiradentes'],
                        ['2026-05-01', 'feriado', 'Dia do Trabalho'],
                        ['2026-06-04', 'feriado', 'Corpus Christi (ponto facultativo)'],
                        ['2026-06-24', 'feriado', 'Sao Joao (PB)'],
                        ['2026-07-09', 'feriado', 'Revolucao Constitucionalista'],
                        ['2026-09-07', 'feriado', 'Independencia do Brasil'],
                        ['2026-10-12', 'feriado', 'Nossa Senhora Aparecida'],
                        ['2026-10-15', 'feriado', 'Dia dos Professores (ponto facultativo)'],
                        ['2026-10-28', 'feriado', 'Dia do Servidor Publico'],
                        ['2026-11-02', 'feriado', 'Finados'],
                        ['2026-11-20', 'feriado', 'Dia da Consciencia Negra'],
                        ['2026-12-25', 'feriado', 'Natal'],
                        // === RECESSOS ESCOLARES (RE) - Junho 2026 ===
                        ['2026-06-15', 'recesso', 'Recesso Escolar'],
                        ['2026-06-16', 'recesso', 'Recesso Escolar'],
                        ['2026-06-17', 'recesso', 'Recesso Escolar'],
                        ['2026-06-18', 'recesso', 'Recesso Escolar'],
                        ['2026-06-19', 'recesso', 'Recesso Escolar'],
                        ['2026-06-22', 'recesso', 'Recesso Escolar'],
                        ['2026-06-23', 'recesso', 'Recesso Escolar'],
                        ['2026-06-24', 'recesso', 'Recesso Escolar'],
                        ['2026-06-25', 'recesso', 'Recesso Escolar'],
                        ['2026-06-26', 'recesso', 'Recesso Escolar'],
                    ];
                    $stmtF = $pdo->prepare("INSERT INTO feriados (usuario_id, data, tipo, descricao) VALUES (?, ?, ?, ?)");
                    foreach ($feriadosPB as $f) {
                        try { $stmtF->execute([$usuarioId, $f[0], $f[1], $f[2]]); } catch (PDOException $e) {}
                    }
                }

                $ok = "<h3 style='color:green;'>Usuario criado!</h3>
                <p><b>Email:</b> " . htmlspecialchars($email) . "<br><b>API Key:</b> <code style='background:#eee;padding:4px;'>" . $apiKey . "</code></p>
                <p><a href='index.php' style='color:blue;'>Ir para Login</a></p>
                <p style='color:red;font-weight:bold;'>IMPORTANTE: Delete o arquivo instalar.php!</p>";
            } catch (PDOException $e) { $erro = 'Erro: ' . $e->getMessage(); }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="UTF-8"><title>SIAGE Auto - Instalar</title></head>
<body style="font-family:Arial;background:linear-gradient(135deg,#667eea,#764ba2);display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;">
<div style="background:white;padding:40px;border-radius:16px;max-width:420px;width:90%;box-shadow:0 8px 32px rgba(0,0,0,0.3);">
<h2 style="color:#333;margin:0 0 20px;text-align:center;">SIAGE Auto - Instalacao</h2>
<?php if ($erro): ?><div style="background:#f8d7da;color:#721c24;padding:10px;border-radius:6px;margin-bottom:15px;"><?php echo $erro; ?></div><?php endif; ?>
<?php if ($ok) { echo $ok; } else { ?>
<form method="POST">
<p style="margin-bottom:15px;color:#555;">Crie seu primeiro usuario.</p>
<div style="margin-bottom:12px;"><label style="display:block;margin-bottom:4px;font-size:0.85em;color:#555;">Nome</label><input type="text" name="nome" required style="width:100%;padding:10px;border:1px solid #ccc;border-radius:8px;"></div>
<div style="margin-bottom:12px;"><label style="display:block;margin-bottom:4px;font-size:0.85em;color:#555;">Email</label><input type="email" name="email" required style="width:100%;padding:10px;border:1px solid #ccc;border-radius:8px;"></div>
<div style="margin-bottom:16px;"><label style="display:block;margin-bottom:4px;font-size:0.85em;color:#555;">Senha</label><input type="password" name="senha" required style="width:100%;padding:10px;border:1px solid #ccc;border-radius:8px;"></div>
<button type="submit" style="width:100%;padding:12px;background:linear-gradient(135deg,#667eea,#764ba2);color:white;border:none;border-radius:8px;font-size:1em;font-weight:600;cursor:pointer;">Criar Usuario</button>
</form>
<?php } ?>
</div></body></html>
