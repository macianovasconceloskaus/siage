<?php
// logout.php - Encerra sessao
require_once 'config.php';

session_destroy();
header('Location: index.php');
exit;
?>
