<?php
// migrar-enviada.php - Adiciona coluna enviada_extensao na tabela existente
// Execute este arquivo uma vez apos atualizar o sistema
require_once 'config.php';
header('Content-Type: text/plain; charset=utf-8');

echo "=== Migracao: Adicionando coluna enviada_extensao ===\n\n";

try {
    // Verifica se a coluna ja existe
    $stmt = $pdo->query("SHOW COLUMNS FROM aulas_professor LIKE 'enviada_extensao'");
    if ($stmt->rowCount() > 0) {
        echo "[OK] Coluna 'enviada_extensao' ja existe. Nenhuma acao necessaria.\n";
    } else {
        // Adiciona a coluna
        $pdo->exec("ALTER TABLE aulas_professor 
            ADD COLUMN enviada_extensao TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0=nao enviada, 1=enviada para extensao' AFTER periodo,
            ADD COLUMN data_envio_extensao DATETIME DEFAULT NULL AFTER enviada_extensao");
        echo "[OK] Coluna 'enviada_extensao' adicionada com sucesso!\n";
        echo "[OK] Coluna 'data_envio_extensao' adicionada com sucesso!\n";
    }
    
    echo "\n=== Migracao concluida! ===\n";
    echo "Agora o sistema filtra aulas por status de envio.\n";
    
} catch (PDOException $e) {
    echo "[ERRO] " . $e->getMessage() . "\n";
}
