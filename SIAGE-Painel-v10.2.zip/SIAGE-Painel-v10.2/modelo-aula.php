<?php
// modelo-aula.php - Configurar modelo padrao de aula
require_once 'config.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

$usuarioId = $_SESSION['usuario_id'];
$msg = '';

// Salvar modelo
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conteudo = trim($_POST['conteudo'] ?? '');
    $metodologia = trim($_POST['metodologia'] ?? '');
    $tipo = trim($_POST['tipo_aula'] ?? '');
    $obs = trim($_POST['observacoes'] ?? '');
    
    // Verifica se ja tem modelo
    $stmt = $pdo->prepare("SELECT id FROM modelos_aula WHERE usuario_id = ?");
    $stmt->execute([$usuarioId]);
    $existe = $stmt->fetch();
    
    if ($existe) {
        $stmt = $pdo->prepare("UPDATE modelos_aula SET conteudo=?, metodologia=?, tipo_aula=?, observacoes=? WHERE usuario_id=?");
        $stmt->execute([$conteudo, $metodologia, $tipo, $obs, $usuarioId]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO modelos_aula (usuario_id, conteudo, metodologia, tipo_aula, observacoes) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$usuarioId, $conteudo, $metodologia, $tipo, $obs]);
    }
    $msg = 'Modelo salvo com sucesso!';
}

// Busca modelo atual
$stmt = $pdo->prepare("SELECT * FROM modelos_aula WHERE usuario_id = ?");
$stmt->execute([$usuarioId]);
$modelo = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>SIAGE Auto - Modelo de Aula</title>
    <link rel="stylesheet" href="assets/painel.css">
</head>
<body>

<div class="container" style="max-width: 600px;">
    <div class="card">
        <div class="header">
            <div>
                <h1>SIAGE Auto</h1>
                <span>Modelo Padrao de Aula</span>
            </div>
            <a href="dashboard.php" class="btn btn-cinza" style="padding: 6px 14px; font-size: 0.8em;">← Voltar</a>
        </div>

        <div class="card-body">
            
            <?php if ($msg): ?>
            <div class="alerta alerta-sucesso"><?php echo htmlspecialchars($msg); ?></div>
            <?php endif; ?>

            <div class="info-box">
                Estas informacoes serao usadas para preencher automaticamente 
                o <strong>conteudo</strong>, <strong>metodologia</strong> e <strong>tipo</strong> 
                de todas as aulas no SIAGE.
            </div>

            <form method="POST" action="">
                <div class="form-group">
                    <label>Conteudo / Objetos de Conhecimento</label>
                    <textarea name="conteudo" placeholder="Aula realizada de acordo com o plano competente."><?php echo htmlspecialchars($modelo['conteudo'] ?? ''); ?></textarea>
                </div>

                <div class="form-group">
                    <label>Metodologia</label>
                    <select name="metodologia" style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid #ccc;">
                        <option value="Aula dialogada" <?php echo ($modelo['metodologia'] ?? '') === 'Aula dialogada' ? 'selected' : ''; ?>>Aula dialogada</option>
                        <option value="Aula expositiva" <?php echo ($modelo['metodologia'] ?? '') === 'Aula expositiva' ? 'selected' : ''; ?>>Aula expositiva</option>
                        <option value="Aula pratica" <?php echo ($modelo['metodologia'] ?? '') === 'Aula pratica' ? 'selected' : ''; ?>>Aula pratica</option>
                        <option value="Atividade em grupo" <?php echo ($modelo['metodologia'] ?? '') === 'Atividade em grupo' ? 'selected' : ''; ?>>Atividade em grupo</option>
                        <option value="Debate" <?php echo ($modelo['metodologia'] ?? '') === 'Debate' ? 'selected' : ''; ?>>Debate</option>
                        <option value="Pesquisa" <?php echo ($modelo['metodologia'] ?? '') === 'Pesquisa' ? 'selected' : ''; ?>>Pesquisa</option>
                        <option value="Recuperacao" <?php echo ($modelo['metodologia'] ?? '') === 'Recuperacao' ? 'selected' : ''; ?>>Recuperacao</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Tipo de Aula</label>
                    <select name="tipo_aula" style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid #ccc;">
                        <option value="Avulso" <?php echo ($modelo['tipo_aula'] ?? '') === 'Avulso' ? 'selected' : ''; ?>>Avulso</option>
                        <option value="Reposicao" <?php echo ($modelo['tipo_aula'] ?? '') === 'Reposicao' ? 'selected' : ''; ?>>Reposicao</option>
                        <option value="Recuperacao" <?php echo ($modelo['tipo_aula'] ?? '') === 'Recuperacao' ? 'selected' : ''; ?>>Recuperacao</option>
                        <option value="Reforco" <?php echo ($modelo['tipo_aula'] ?? '') === 'Reforco' ? 'selected' : ''; ?>>Reforco</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Observacoes (opcional)</label>
                    <textarea name="observacoes" placeholder="Observacoes gerais..." style="min-height: 60px;"><?php echo htmlspecialchars($modelo['observacoes'] ?? ''); ?></textarea>
                </div>

                <button type="submit" class="btn btn-verde" style="width: 100%;">
                    💾 Salvar Modelo
                </button>
            </form>

        </div>

        <div class="rodape">
            Desenvolvido por <strong style="color: #17a2b8;">Maciano Vasconcelos</strong>
        </div>
    </div>
</div>

</body>
</html>
