<?php
// remover-feriado.php - Remove feriado
require_once 'config.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

$id = $_GET['id'] ?? 0;
$usuarioId = $_SESSION['usuario_id'];

if ($id) {
    $stmt = $pdo->prepare("DELETE FROM feriados WHERE id = ? AND usuario_id = ?");
    $stmt->execute([$id, $usuarioId]);
}

header('Location: calendario.php');
exit;
