<?php
// salvar-aula.php - Salva aulas com turma + disciplina
require_once 'config.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario_id'])) { echo json_encode(['status'=>'erro','erro'=>'Nao autenticado']); exit; }
$usuarioId = $_SESSION['usuario_id'];

$input = json_decode(file_get_contents('php://input'), true);
if (!$input || empty($input['datas'])) { echo json_encode(['status'=>'erro','erro'=>'Nenhuma data']); exit; }
if (empty($input['turma_id']) || empty($input['disciplina_id'])) { echo json_encode(['status'=>'erro','erro'=>'Turma e disciplina obrigatorias']); exit; }

if (!tabelaExiste($pdo, 'aulas_professor')) { echo json_encode(['status'=>'erro','erro'=>'Tabela nao existe']); exit; }

$datas = $input['datas'];
$turmaId = (int)$input['turma_id'];
$discId = (int)$input['disciplina_id'];
$quantidade = (int)($input['quantidade'] ?? 1);
$modoAula = trim($input['modo_aula'] ?? 'Aula');
$tipoAula = trim($input['tipo_aula'] ?? 'Avulso');
$metodologia = trim($input['metodologia'] ?? 'Aula dialogada');
$objetos = trim($input['objetos_conhecimento'] ?? 'Aula realizada de acordo com o plano competente.');
$observacoes = trim($input['observacoes'] ?? '');
$tempos = trim($input['tempos'] ?? '1,2');

// Busca config para periodo
$stmt = querySegura($pdo, "SELECT * FROM configuracoes_calendario WHERE usuario_id = ?", [$usuarioId]);
$config = ($stmt !== null) ? $stmt->fetch(PDO::FETCH_ASSOC) : null;

$salvas = 0;
foreach ($datas as $dataStr) {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dataStr)) continue;
    $dataObj = new DateTime($dataStr);
    $diaSemanaNum = (int)$dataObj->format('w');
    $diasNomes = ['Domingo','Segunda-feira','Terca-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sabado'];
    $periodo = 1;
    if ($config) {
        $ts = $dataObj->getTimestamp();
        if ($ts >= (new DateTime($config['p1_inicio']))->getTimestamp() && $ts <= (new DateTime($config['p1_fim']))->getTimestamp()) $periodo = 1;
        elseif ($ts >= (new DateTime($config['p2_inicio']))->getTimestamp() && $ts <= (new DateTime($config['p2_fim']))->getTimestamp()) $periodo = 2;
        elseif ($ts >= (new DateTime($config['p3_inicio']))->getTimestamp() && $ts <= (new DateTime($config['p3_fim']))->getTimestamp()) $periodo = 3;
        elseif ($ts >= (new DateTime($config['p4_inicio']))->getTimestamp() && $ts <= (new DateTime($config['p4_fim']))->getTimestamp()) $periodo = 4;
    }
    try {
        $stmt = $pdo->prepare("INSERT INTO aulas_professor 
            (usuario_id, turma_id, disciplina_id, data, dia_semana, quantidade, modo_aula, tipo_aula, objetos_conhecimento, metodologia, observacoes, tempos, periodo)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
            dia_semana=VALUES(dia_semana), quantidade=VALUES(quantidade), modo_aula=VALUES(modo_aula),
            tipo_aula=VALUES(tipo_aula), objetos_conhecimento=VALUES(objetos_conhecimento),
            metodologia=VALUES(metodologia), observacoes=VALUES(observacoes), tempos=VALUES(tempos), periodo=VALUES(periodo)");
        $stmt->execute([$usuarioId, $turmaId, $discId, $dataStr, $diasNomes[$diaSemanaNum], $quantidade, $modoAula, $tipoAula, $objetos, $metodologia, $observacoes, $tempos, $periodo]);
        $salvas++;
    } catch (PDOException $e) { error_log($e->getMessage()); }
}

if ($salvas > 0) {
    echo json_encode(['status'=>'ok','mensagem'=>"$salvas aula(s) salva(s)!",'salvas'=>$salvas]);
} else {
    echo json_encode(['status'=>'erro','erro'=>'Nenhuma aula foi salva']);
}
