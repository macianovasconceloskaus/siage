<?php
// salvar-config.php - Salva configuracoes do calendario
require_once 'config.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: calendario.php');
    exit;
}

$usuarioId = $_SESSION['usuario_id'];

$p1_inicio = $_POST['p1_inicio'] ?? '2026-02-10';
$p1_fim = $_POST['p1_fim'] ?? '2026-04-23';
$p2_inicio = $_POST['p2_inicio'] ?? '2026-04-24';
$p2_fim = $_POST['p2_fim'] ?? '2026-07-23';
$p3_inicio = $_POST['p3_inicio'] ?? '2026-07-24';
$p3_fim = $_POST['p3_fim'] ?? '2026-10-05';
$p4_inicio = $_POST['p4_inicio'] ?? '2026-10-06';
$p4_fim = $_POST['p4_fim'] ?? '2026-12-17';

// Dias da semana: 1=Seg, 2=Ter, 3=Qua, 4=Qui, 5=Sex, 6=Sab
$diasSemana = $_POST['dias_semana'] ?? ['1', '2', '3', '4', '5']; // Seg-Sex por padrao
$diasSemanaStr = implode(',', $diasSemana);

// Verifica se tabela existe
if (!tabelaExiste($pdo, 'configuracoes_calendario')) {
    header('Location: calendario.php');
    exit;
}

// Verifica se ja existe config
$stmt = querySegura($pdo, "SELECT id FROM configuracoes_calendario WHERE usuario_id = ?", [$usuarioId]);
$existe = ($stmt !== null) ? $stmt->fetch() : false;

if ($existe) {
    $stmt = $pdo->prepare("UPDATE configuracoes_calendario SET 
        p1_inicio = ?, p1_fim = ?, p2_inicio = ?, p2_fim = ?, 
        p3_inicio = ?, p3_fim = ?, p4_inicio = ?, p4_fim = ?, dias_semana = ?
        WHERE usuario_id = ?");
    $stmt->execute([$p1_inicio, $p1_fim, $p2_inicio, $p2_fim, $p3_inicio, $p3_fim, $p4_inicio, $p4_fim, $diasSemanaStr, $usuarioId]);
} else {
    $stmt = $pdo->prepare("INSERT INTO configuracoes_calendario 
        (usuario_id, p1_inicio, p1_fim, p2_inicio, p2_fim, p3_inicio, p3_fim, p4_inicio, p4_fim, dias_semana)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$usuarioId, $p1_inicio, $p1_fim, $p2_inicio, $p2_fim, $p3_inicio, $p3_fim, $p4_inicio, $p4_fim, $diasSemanaStr]);
}

header('Location: calendario.php');
exit;
