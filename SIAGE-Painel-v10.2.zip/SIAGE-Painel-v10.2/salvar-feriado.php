<?php
// salvar-feriado.php - Adiciona feriado
require_once 'config.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuarioId = $_SESSION['usuario_id'];
    $data = $_POST['data'] ?? '';
    $tipo = $_POST['tipo'] ?? 'feriado';
    $descricao = $_POST['descricao'] ?? '';
    
    if ($data) {
        $stmt = $pdo->prepare("INSERT INTO feriados (usuario_id, data, tipo, descricao) VALUES (?, ?, ?, ?)");
        $stmt->execute([$usuarioId, $data, $tipo, $descricao]);
    }
}

header('Location: calendario.php');
exit;
