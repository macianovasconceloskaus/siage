<?php
// turmas-padrao.php - Cadastra turmas e disciplinas padrao do ensino medio
require_once 'config.php';

if (!isset($_SESSION['usuario_id'])) { header('Location: index.php'); exit; }

$usuarioId = $_SESSION['usuario_id'];
$criadas = [];

// === TURMAS PRE-DEFINIDAS ===
$turmasPredefinidas = [
    // 1a Serie A-F
    ['nome' => '1ª SERIE A', 'serie' => '1º Ano', 'turno' => 'Integral'],
    ['nome' => '1ª SERIE B', 'serie' => '1º Ano', 'turno' => 'Integral'],
    ['nome' => '1ª SERIE C', 'serie' => '1º Ano', 'turno' => 'Integral'],
    ['nome' => '1ª SERIE D', 'serie' => '1º Ano', 'turno' => 'Integral'],
    ['nome' => '1ª SERIE E', 'serie' => '1º Ano', 'turno' => 'Integral'],
    ['nome' => '1ª SERIE F', 'serie' => '1º Ano', 'turno' => 'Integral'],
    // 2a Serie A-D
    ['nome' => '2ª SERIE A', 'serie' => '2º Ano', 'turno' => 'Integral'],
    ['nome' => '2ª SERIE B', 'serie' => '2º Ano', 'turno' => 'Integral'],
    ['nome' => '2ª SERIE C', 'serie' => '2º Ano', 'turno' => 'Integral'],
    ['nome' => '2ª SERIE D', 'serie' => '2º Ano', 'turno' => 'Integral'],
    // 3o Ano A-D
    ['nome' => '3º ANO A', 'serie' => '3º Ano', 'turno' => 'Integral'],
    ['nome' => '3º ANO B', 'serie' => '3º Ano', 'turno' => 'Integral'],
    ['nome' => '3º ANO C', 'serie' => '3º Ano', 'turno' => 'Integral'],
    ['nome' => '3º ANO D', 'serie' => '3º Ano', 'turno' => 'Integral'],
    // EJA
    ['nome' => 'EJA - FASE I', 'serie' => 'EJA', 'turno' => 'Noturno'],
    ['nome' => 'EJA - FASE II', 'serie' => 'EJA', 'turno' => 'Noturno'],
    ['nome' => 'EJA - FASE III', 'serie' => 'EJA', 'turno' => 'Noturno'],
    ['nome' => 'EJA - FASE IV', 'serie' => 'EJA', 'turno' => 'Noturno'],
];

// === DISCIPLINAS PRE-DEFINIDAS ===
$disciplinasPredefinidas = [
    ['nome' => 'Lingua Portuguesa', 'abreviacao' => 'LP'],
    ['nome' => 'Literatura', 'abreviacao' => 'LIT'],
    ['nome' => 'Matematica', 'abreviacao' => 'MAT'],
    ['nome' => 'Fisica', 'abreviacao' => 'FIS'],
    ['nome' => 'Quimica', 'abreviacao' => 'QUI'],
    ['nome' => 'Biologia', 'abreviacao' => 'BIO'],
    ['nome' => 'Historia', 'abreviacao' => 'HIS'],
    ['nome' => 'Geografia', 'abreviacao' => 'GEO'],
    ['nome' => 'Filosofia', 'abreviacao' => 'FIL'],
    ['nome' => 'Sociologia', 'abreviacao' => 'SOC'],
    ['nome' => 'Arte', 'abreviacao' => 'ART'],
    ['nome' => 'Educacao Fisica', 'abreviacao' => 'EF'],
    ['nome' => 'Lingua Estrangeira - Ingles', 'abreviacao' => 'ING'],
    ['nome' => 'Lingua Estrangeira - Espanhol', 'abreviacao' => 'ESP'],
    ['nome' => 'Arquitetura de Hardware', 'abreviacao' => 'ARQ'],
    ['nome' => 'Programacao', 'abreviacao' => 'PROG'],
    ['nome' => 'Redes de Computadores', 'abreviacao' => 'RED'],
    ['nome' => 'Banco de Dados', 'abreviacao' => 'BD'],
    ['nome' => 'Empreendedorismo', 'abreviacao' => 'EMP'],
];

// Verifica se ja tem turmas
$temTurmas = false;
if (tabelaExiste($pdo, 'turmas')) {
    $stmt = querySegura($pdo, "SELECT COUNT(*) FROM turmas WHERE usuario_id = ?", [$usuarioId]);
    if ($stmt) $temTurmas = $stmt->fetchColumn() > 0;
}

// Verifica se ja tem disciplinas
$temDisc = false;
if (tabelaExiste($pdo, 'disciplinas')) {
    $stmt = querySegura($pdo, "SELECT COUNT(*) FROM disciplinas WHERE usuario_id = ?", [$usuarioId]);
    if ($stmt) $temDisc = $stmt->fetchColumn() > 0;
}

// Cadastra turmas se nao tem
if (!$temTurmas && tabelaExiste($pdo, 'turmas')) {
    $stmt = $pdo->prepare("INSERT INTO turmas (usuario_id, nome, serie, turno) VALUES (?, ?, ?, ?)");
    foreach ($turmasPredefinidas as $t) {
        try {
            $stmt->execute([$usuarioId, $t['nome'], $t['serie'], $t['turno']]);
            $criadas[] = '🏫 ' . $t['nome'] . ' - ' . $t['serie'] . ' (' . $t['turno'] . ')';
        } catch (PDOException $e) {}
    }
}

// Cadastra disciplinas se nao tem
if (!$temDisc && tabelaExiste($pdo, 'disciplinas')) {
    $stmt = $pdo->prepare("INSERT INTO disciplinas (usuario_id, nome, abreviacao) VALUES (?, ?, ?)");
    foreach ($disciplinasPredefinidas as $d) {
        try {
            $stmt->execute([$usuarioId, $d['nome'], $d['abreviacao']]);
            $criadas[] = '📖 ' . $d['nome'] . ' (' . $d['abreviacao'] . ')';
        } catch (PDOException $e) {}
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>SIAGE Auto - Turmas Padrao</title>
    <link rel="stylesheet" href="assets/painel.css">
    <style>
        .status-box { background: rgba(212, 237, 218, 0.8); border: 1px solid rgba(195, 230, 203, 0.6); border-radius: 16px; padding: 24px; margin: 20px 0; text-align: center; animation: glassIn 0.5s ease-out; }
        .status-box h3 { color: #155724; margin-bottom: 10px; }
        .status-box p { color: #155724; font-size: 0.9em; }
        .lista-criadas { text-align: left; max-height: 400px; overflow-y: auto; margin-top: 16px; padding: 16px; background: rgba(255,255,255,0.6); border-radius: 12px; }
        .lista-criadas div { padding: 6px 0; border-bottom: 1px solid rgba(0,0,0,0.05); font-size: 0.88em; color: #333; }
        .ja-existe { background: rgba(255, 243, 205, 0.8); border-color: rgba(255, 234, 167, 0.6); }
        .ja-existe h3, .ja-existe p { color: #856404; }
    </style>
</head>
<body>
<div class="container" style="max-width: 600px;">
<div class="card">
    <div class="header"><div><h1>SIAGE Auto</h1><span>Turmas e Disciplinas Padrao</span></div></div>
    <div class="card-body">

<?php if ($temTurmas || $temDisc): ?>
    <div class="status-box ja-existe">
        <h3>&#9888; Voce ja possui turmas ou disciplinas cadastradas</h3>
        <p>As turmas padrao so sao criadas quando esta tudo vazio.</p>
        <p>Va para <a href="gerenciar-turmas.php" style="color: #17a2b8; font-weight: 600;">Gerenciar Turmas</a> para editar.</p>
    </div>
<?php elseif (empty($criadas)): ?>
    <div class="alerta alerta-erro">Erro ao criar turmas. Verifique se as tabelas existem.</div>
<?php else: ?>
    <div class="status-box">
        <h3>&#127881; <?php echo count($criadas); ?> itens criados com sucesso!</h3>
        <p>Turmas e disciplinas padrao foram cadastradas.</p>
    </div>
    <div class="lista-criadas">
        <?php foreach ($criadas as $c): ?><div><?php echo $c; ?></div><?php endforeach; ?>
    </div>
<?php endif; ?>

        <div style="text-align: center; margin-top: 24px;">
            <a href="gerenciar-turmas.php" class="btn btn-ciano" style="font-size: 1em; padding: 12px 24px;">&#128218; Gerenciar Turmas</a>
            <a href="calendario.php" class="btn btn-verde" style="font-size: 1em; padding: 12px 24px;">&#128197; Ir ao Calendario</a>
        </div>

    </div>
    <div class="rodape">Desenvolvido por <strong style="color: #17a2b8;">Maciano Vasconcelos</strong></div>
</div>
</div>
</body>
</html>
