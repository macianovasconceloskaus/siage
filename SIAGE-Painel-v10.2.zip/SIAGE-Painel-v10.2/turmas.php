<?php
// turmas.php - Gerenciar turmas
require_once 'config.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

$usuarioId = $_SESSION['usuario_id'];
$msg = '';

// Cadastrar nova turma
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $uuidSiage = trim($_POST['uuid_siage'] ?? '');
    $componente = trim($_POST['componente'] ?? '');
    
    if (!empty($nome) && !empty($uuidSiage)) {
        $stmt = $pdo->prepare("INSERT INTO turmas (usuario_id, nome, uuid_siage, componente) VALUES (?, ?, ?, ?)");
        $stmt->execute([$usuarioId, $nome, $uuidSiage, $componente]);
        $msg = 'Turma cadastrada com sucesso!';
    }
}

// Buscar turmas do usuario
$stmt = $pdo->prepare("SELECT * FROM turmas WHERE usuario_id = ? ORDER BY nome ASC");
$stmt->execute([$usuarioId]);
$turmas = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>SIAGE Auto - Turmas</title>
    <link rel="stylesheet" href="assets/painel.css">
</head>
<body>

<div class="container">
    <div class="card">
        <div class="header">
            <div>
                <h1>SIAGE Auto</h1>
                <span>Minhas Turmas</span>
            </div>
            <a href="dashboard.php" class="btn btn-cinza" style="padding: 6px 14px; font-size: 0.8em;">← Voltar</a>
        </div>

        <div class="card-body">
            
            <?php if ($msg): ?>
            <div class="alerta alerta-sucesso"><?php echo htmlspecialchars($msg); ?></div>
            <?php endif; ?>

            <!-- FORM CADASTRAR -->
            <div class="info-box">
                <strong>Como encontrar o UUID da turma:</strong>
                <ul>
                    <li>Acesse a turma no SIAGE</li>
                    <li>Olhe a URL: <code>.../turma/<strong>17ce8e88-...</strong></code></li>
                    <li>Copie a parte depois de <code>/turma/</code></li>
                </ul>
            </div>

            <form method="POST" action="">
                <div class="grid-2">
                    <div class="form-group">
                        <label>Nome da Turma</label>
                        <input type="text" name="nome" placeholder="Ex: 3o Ano A" required>
                    </div>
                    <div class="form-group">
                        <label>UUID do SIAGE</label>
                        <input type="text" name="uuid_siage" placeholder="17ce8e88-..." required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Componente / Disciplina</label>
                    <input type="text" name="componente" placeholder="Ex: Arquitetura de Hardware">
                </div>
                <button type="submit" class="btn btn-ciano">+ Cadastrar Turma</button>
            </form>

            <!-- LISTA -->
            <h3 style="margin: 24px 0 12px; color: #333;">Turmas Cadastradas</h3>
            
            <?php if (empty($turmas)): ?>
            <div class="alerta alerta-info">Nenhuma turma cadastrada. Adicione acima.</div>
            <?php else: ?>
            <div style="overflow-x: auto;">
                <table class="tabela">
                    <thead>
                        <tr><th>Nome</th><th>Componente</th><th>UUID</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($turmas as $t): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($t['nome']); ?></td>
                            <td><?php echo htmlspecialchars($t['componente'] ?? '-'); ?></td>
                            <td><code style="font-size:0.8em;"><?php echo substr($t['uuid_siage'], 0, 20); ?>...</code></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>

        </div>

        <div class="rodape">
            Desenvolvido por <strong style="color: #17a2b8;">Maciano Vasconcelos</strong>
        </div>
    </div>
</div>

</body>
</html>
